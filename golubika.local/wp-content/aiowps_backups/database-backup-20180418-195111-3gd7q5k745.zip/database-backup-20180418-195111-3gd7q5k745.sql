-- All In One WP Security & Firewall 4.3.2
-- MySQL dump
-- 2018-04-18 16:51:11

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `gol_UPCP_Catalogue_Items`;

CREATE TABLE `gol_UPCP_Catalogue_Items` (
  `Catalogue_Item_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Catalogue_ID` mediumint(9) DEFAULT '0',
  `Item_ID` mediumint(9) DEFAULT '0',
  `Category_ID` mediumint(9) DEFAULT '0',
  `SubCategory_ID` mediumint(9) DEFAULT '0',
  `Position` mediumint(9) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`Catalogue_Item_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `gol_UPCP_Catalogues`;

CREATE TABLE `gol_UPCP_Catalogues` (
  `Catalogue_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Catalogue_Name` text NOT NULL,
  `Catalogue_Description` text NOT NULL,
  `Catalogue_Layout_Format` text NOT NULL,
  `Catalogue_Custom_CSS` text NOT NULL,
  `Catalogue_Item_Count` mediumint(9) NOT NULL DEFAULT '0',
  `Catalogue_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  UNIQUE KEY `id` (`Catalogue_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `gol_UPCP_Catalogues` VALUES("1","Sample Catalogue","This is where your description of this catalogue would go.","","","0","0000-00-00 00:00:00");


DROP TABLE IF EXISTS `gol_UPCP_Categories`;

CREATE TABLE `gol_UPCP_Categories` (
  `Category_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Category_Name` text NOT NULL,
  `Category_Description` text NOT NULL,
  `Category_Image` text NOT NULL,
  `Category_Item_Count` mediumint(9) DEFAULT '0',
  `Category_Sidebar_Order` mediumint(9) DEFAULT '9999',
  `Category_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Category_WC_ID` mediumint(9) DEFAULT '0',
  UNIQUE KEY `id` (`Category_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `gol_UPCP_Categories` VALUES("1","Sample Category","This is where your description of this category would go.","","1","9999","0000-00-00 00:00:00","0");


DROP TABLE IF EXISTS `gol_UPCP_Custom_Fields`;

CREATE TABLE `gol_UPCP_Custom_Fields` (
  `Field_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Field_Name` text NOT NULL,
  `Field_Slug` text NOT NULL,
  `Field_Type` text NOT NULL,
  `Field_Description` text NOT NULL,
  `Field_Values` text NOT NULL,
  `Field_Displays` text NOT NULL,
  `Field_Searchable` text NOT NULL,
  `Field_Sidebar_Order` mediumint(9) DEFAULT '9999',
  `Field_Display_Tabbed` text NOT NULL,
  `Field_Control_Type` text NOT NULL,
  `Field_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Field_WC_ID` mediumint(9) DEFAULT '0',
  UNIQUE KEY `id` (`Field_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `gol_UPCP_Fields_Meta`;

CREATE TABLE `gol_UPCP_Fields_Meta` (
  `Meta_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Field_ID` mediumint(9) DEFAULT '0',
  `Item_ID` mediumint(9) DEFAULT '0',
  `Meta_Value` text NOT NULL,
  UNIQUE KEY `id` (`Meta_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `gol_UPCP_Item_Images`;

CREATE TABLE `gol_UPCP_Item_Images` (
  `Item_Image_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Item_ID` mediumint(9) NOT NULL DEFAULT '0',
  `Item_Image_URL` text,
  `Item_Image_Description` text,
  `Item_Image_Order` mediumint(9) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`Item_Image_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `gol_UPCP_Items`;

CREATE TABLE `gol_UPCP_Items` (
  `Item_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Item_Name` text NOT NULL,
  `Item_Slug` text NOT NULL,
  `Item_Description` text,
  `Item_Price` text NOT NULL,
  `Item_Sale_Price` text NOT NULL,
  `Item_Sale_Mode` text NOT NULL,
  `Item_Link` text,
  `Item_Photo_URL` text,
  `Category_ID` mediumint(9) DEFAULT '0',
  `Category_Name` text,
  `Global_Item_ID` mediumint(9) DEFAULT '0',
  `Item_Special_Attr` text,
  `SubCategory_ID` mediumint(9) DEFAULT '0',
  `SubCategory_Name` text,
  `Item_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Item_Views` mediumint(9) DEFAULT '0',
  `Item_Display_Status` text,
  `Item_Related_Products` text,
  `Item_Next_Previous` text,
  `Item_SEO_Description` text,
  `Item_Category_Product_Order` mediumint(9) DEFAULT '9999',
  `Item_WC_ID` mediumint(9) DEFAULT '0',
  UNIQUE KEY `id` (`Item_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `gol_UPCP_Items` VALUES("1","Sample Item","","This is where your description of this product would go.","9.99","","","","http://golubika.local/wp-content/plugins/ultimate-product-catalogue/images/sample_image.jpg","1","Sample Category","0","","0","","0000-00-00 00:00:00","0","","","","","9999","0");


DROP TABLE IF EXISTS `gol_UPCP_SubCategories`;

CREATE TABLE `gol_UPCP_SubCategories` (
  `SubCategory_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Category_ID` mediumint(9) NOT NULL DEFAULT '0',
  `Category_Name` text NOT NULL,
  `SubCategory_Name` text NOT NULL,
  `SubCategory_Description` text NOT NULL,
  `SubCategory_Image` text NOT NULL,
  `SubCategory_Item_Count` mediumint(9) NOT NULL DEFAULT '0',
  `SubCategory_Sidebar_Order` mediumint(9) DEFAULT '9999',
  `SubCategory_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `SubCategory_WC_ID` mediumint(9) DEFAULT '0',
  UNIQUE KEY `id` (`SubCategory_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `gol_UPCP_Tag_Groups`;

CREATE TABLE `gol_UPCP_Tag_Groups` (
  `Tag_Group_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Tag_Group_Name` text NOT NULL,
  `Tag_Group_Description` text NOT NULL,
  `Display_Tag_Group` text NOT NULL,
  `Tag_Group_Order` mediumint(9) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`Tag_Group_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `gol_UPCP_Tagged_Items`;

CREATE TABLE `gol_UPCP_Tagged_Items` (
  `Tagged_Item_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Tag_ID` mediumint(9) NOT NULL DEFAULT '0',
  `Item_ID` mediumint(9) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`Tagged_Item_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `gol_UPCP_Tags`;

CREATE TABLE `gol_UPCP_Tags` (
  `Tag_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Tag_Name` text NOT NULL,
  `Tag_Description` text NOT NULL,
  `Tag_Item_Count` text NOT NULL,
  `Tag_Group_ID` mediumint(9) NOT NULL DEFAULT '0',
  `Tag_Sidebar_Order` mediumint(9) DEFAULT '9999',
  `Tag_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Tag_WC_ID` mediumint(9) DEFAULT '0',
  UNIQUE KEY `id` (`Tag_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `gol_UPCP_Videos`;

CREATE TABLE `gol_UPCP_Videos` (
  `Item_Video_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Item_ID` mediumint(9) NOT NULL DEFAULT '0',
  `Item_Video_URL` text,
  `Item_Video_Type` text,
  `Item_Video_Order` mediumint(9) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`Item_Video_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `gol_aiowps_events`;

CREATE TABLE `gol_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `gol_aiowps_failed_logins`;

CREATE TABLE `gol_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `gol_aiowps_failed_logins` VALUES("1","0","admin","2018-04-18 19:21:32","127.0.0.1");


DROP TABLE IF EXISTS `gol_aiowps_global_meta`;

CREATE TABLE `gol_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `gol_aiowps_login_activity`;

CREATE TABLE `gol_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `gol_aiowps_login_activity` VALUES("1","1","admin","2018-02-11 16:38:23","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("2","1","admin","2018-02-19 18:31:48","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("3","1","admin","2018-02-24 16:32:10","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("4","1","admin","2018-02-24 20:43:31","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("5","1","admin","2018-02-24 20:43:31","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("6","1","admin","2018-02-25 12:39:48","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("7","1","admin","2018-03-02 12:42:55","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("8","1","admin","2018-03-02 13:30:24","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("9","1","admin","2018-03-06 14:56:38","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("10","1","admin","2018-03-07 12:02:06","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("11","1","admin","2018-03-14 13:32:26","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("12","1","admin","2018-03-15 14:02:45","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("13","1","admin","2018-03-17 13:37:27","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("14","1","admin","2018-03-18 14:02:27","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("15","1","admin","2018-03-18 17:47:09","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("16","1","admin","2018-03-18 18:03:38","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("17","1","admin","2018-03-21 15:11:08","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("18","1","admin","2018-03-22 11:54:04","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("19","1","admin","2018-03-24 17:02:03","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("20","1","admin","2018-03-25 11:51:23","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("21","1","admin","2018-03-25 14:26:04","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("22","1","admin","2018-03-25 14:55:56","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("23","1","admin","2018-03-25 18:44:30","2018-03-25 20:10:31","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("24","1","admin","2018-03-26 12:42:40","2018-04-17 17:23:18","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("25","1","admin","2018-03-27 12:32:34","2018-04-17 17:23:18","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("26","1","admin","2018-04-01 14:13:27","2018-04-17 17:23:18","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("27","1","admin","2018-04-01 18:26:11","2018-04-17 17:23:18","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("28","1","admin","2018-04-16 20:40:09","2018-04-17 17:23:18","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("29","1","admin","2018-04-17 15:27:47","2018-04-17 17:23:18","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("30","1","admin","2018-04-18 18:10:37","2018-04-18 18:40:51","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("31","2","dk","2018-04-18 18:41:41","2018-04-18 19:21:26","127.0.0.1","","");
INSERT INTO `gol_aiowps_login_activity` VALUES("32","3","sergdidyk_golbags","2018-04-18 19:22:02","0000-00-00 00:00:00","127.0.0.1","","");


DROP TABLE IF EXISTS `gol_aiowps_login_lockdown`;

CREATE TABLE `gol_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `gol_aiowps_permanent_block`;

CREATE TABLE `gol_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `gol_commentmeta`;

CREATE TABLE `gol_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `gol_comments`;

CREATE TABLE `gol_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `gol_links`;

CREATE TABLE `gol_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `gol_options`;

CREATE TABLE `gol_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2382 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `gol_options` VALUES("1","siteurl","http://golubika.local","yes");
INSERT INTO `gol_options` VALUES("2","home","http://golubika.local","yes");
INSERT INTO `gol_options` VALUES("3","blogname","Golubika","yes");
INSERT INTO `gol_options` VALUES("4","blogdescription","Felt bags&amp;accessories","yes");
INSERT INTO `gol_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `gol_options` VALUES("6","admin_email","serg.didyk@gmail.com","yes");
INSERT INTO `gol_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `gol_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `gol_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `gol_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `gol_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `gol_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `gol_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `gol_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `gol_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `gol_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `gol_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `gol_options` VALUES("18","default_category","1","yes");
INSERT INTO `gol_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `gol_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `gol_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `gol_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `gol_options` VALUES("23","date_format","d.m.Y","yes");
INSERT INTO `gol_options` VALUES("24","time_format","H:i","yes");
INSERT INTO `gol_options` VALUES("25","links_updated_date_format","d.m.Y H:i","yes");
INSERT INTO `gol_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `gol_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `gol_options` VALUES("28","permalink_structure","/%postname%/","yes");
INSERT INTO `gol_options` VALUES("30","hack_file","0","yes");
INSERT INTO `gol_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `gol_options` VALUES("32","moderation_keys","","no");
INSERT INTO `gol_options` VALUES("33","active_plugins","a:3:{i:0;s:21:\"polylang/polylang.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:22:\"cyr3lat/cyr-to-lat.php\";}","yes");
INSERT INTO `gol_options` VALUES("34","category_base","","yes");
INSERT INTO `gol_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `gol_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `gol_options` VALUES("37","gmt_offset","","yes");
INSERT INTO `gol_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `gol_options` VALUES("39","recently_edited","a:2:{i:0;s:85:\"C:\\Open_Server\\OpenServer\\domains\\golubika.local/wp-content/themes/Golubika/style.css\";i:1;s:0:\"\";}","no");
INSERT INTO `gol_options` VALUES("40","template","Golubika","yes");
INSERT INTO `gol_options` VALUES("41","stylesheet","Golubika","yes");
INSERT INTO `gol_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `gol_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `gol_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `gol_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `gol_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `gol_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `gol_options` VALUES("48","db_version","38590","yes");
INSERT INTO `gol_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `gol_options` VALUES("50","upload_path","","yes");
INSERT INTO `gol_options` VALUES("51","blog_public","0","yes");
INSERT INTO `gol_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `gol_options` VALUES("53","show_on_front","posts","yes");
INSERT INTO `gol_options` VALUES("54","tag_base","","yes");
INSERT INTO `gol_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `gol_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `gol_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `gol_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `gol_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `gol_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `gol_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `gol_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `gol_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `gol_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `gol_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `gol_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `gol_options` VALUES("67","image_default_size","","yes");
INSERT INTO `gol_options` VALUES("68","image_default_align","","yes");
INSERT INTO `gol_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `gol_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `gol_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `gol_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `gol_options` VALUES("73","page_comments","0","yes");
INSERT INTO `gol_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `gol_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `gol_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `gol_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `gol_options` VALUES("78","widget_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("79","widget_text","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("81","uninstall_plugins","a:0:{}","no");
INSERT INTO `gol_options` VALUES("82","timezone_string","Europe/Kiev","yes");
INSERT INTO `gol_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `gol_options` VALUES("84","page_on_front","0","yes");
INSERT INTO `gol_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `gol_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `gol_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `gol_options` VALUES("88","site_icon","0","yes");
INSERT INTO `gol_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `gol_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `gol_options` VALUES("91","initial_db_version","38590","yes");
INSERT INTO `gol_options` VALUES("92","gol_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `gol_options` VALUES("93","fresh_site","0","yes");
INSERT INTO `gol_options` VALUES("94","WPLANG","ru_RU","yes");
INSERT INTO `gol_options` VALUES("95","widget_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("96","widget_recent-posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("97","widget_recent-comments","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("98","widget_archives","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("99","widget_meta","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("100","sidebars_widgets","a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:8:\"logo_nav\";a:1:{i:0;s:13:\"custom_html-4\";}s:10:\"logo_about\";a:1:{i:0;s:13:\"custom_html-5\";}s:11:\"logo_footer\";a:1:{i:0;s:13:\"custom_html-6\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `gol_options` VALUES("101","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("102","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("103","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("104","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("105","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("106","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("107","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("108","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("109","widget_custom_html","a:4:{i:4;a:2:{s:5:\"title\";s:17:\"Лого меню\";s:7:\"content\";s:12027:\"<svg class=\"logo_nav\"
	        xmlns=\"http://www.w3.org/2000/svg\"
	 				viewbox=\"0 0 3133.6245 931.25458\"
	 				id=\"svg4485\"
	 				version=\"1.1\">
	 				<path
						id=\"path4495\"
						d=\"m 629.30122,842.7541 v -88.5 h 66 66 v 9 9 h -57 -57 v 26.5 26.5 h 35 35 v 9 9 h -35 -35 v 44 44 h -9 -9 z m 211.65975,87.52067 c -34.47599,-6.27297 -61.7046,-31.47756 -70.78222,-65.52067 -3.05474,-11.45594 -3.0869,-30.63469 -0.0718,-42.80135 8.12584,-32.78951 32.23466,-56.92548 65.19425,-65.26768 10.60111,-2.68319 28.61274,-2.47821 39.5,0.44952 16.38958,4.40738 29.65943,12.31595 41.5329,24.75279 11.794,12.35361 17.93771,23.7875 22.12701,41.17996 2.54057,10.54752 2.78654,27.3125 0.55317,37.70328 -7.08298,32.95362 -30.77549,58.39031 -62.88671,67.51628 -8.27874,2.35281 -27.26305,3.42594 -35.16662,1.98787 z m 30.47728,-19.55037 c 23.03887,-5.94895 42.76883,-26.14244 48.87705,-50.02536 2.41886,-9.45766 2.63029,-25.08622 0.4637,-34.27658 -2.02121,-8.57371 -7.19606,-19.37624 -12.86636,-26.8586 -20.76794,-27.40477 -58.43637,-34.73226 -88.35297,-17.18694 -3.16715,1.85745 -9.13825,6.75218 -13.26912,10.87718 -15.25585,15.2342 -22.58907,36.73121 -19.89473,58.32056 2.09163,16.75991 8.00647,28.72546 20.4054,41.27955 6.56501,6.64716 9.70669,8.94417 17.51467,12.8057 15.22329,7.52886 31.00831,9.22535 47.12236,5.06449 z m 110.10757,-67.7203 0.2554,-88.25 h 53.99998 54 l 7.8663,2.78197 c 18.3397,6.48598 28.9164,19.00064 31.877,37.71803 3.5016,22.13717 -10.9925,45.27 -33.5707,53.57957 -3.3949,1.24945 -6.0631,2.74616 -5.9293,3.32601 0.1338,0.57986 11.1009,18.05082 24.3713,38.82436 13.2704,20.77353 24.3465,38.33256 24.6137,39.02006 0.3696,0.95137 -2.0173,1.25 -9.9912,1.25 h -10.4768 l -25.2351,-39.5 -25.2351,-39.5 h -33.895 -33.8951 v 39.5 39.5 h -9.50538 -9.5055 z m 109.32728,-11.42139 c 6.7739,-2.29738 16.4593,-11.98282 18.7567,-18.75675 4.3048,-12.69281 0.8926,-26.4589 -8.2111,-33.12678 -9.3365,-6.83832 -8.9232,-6.78639 -57.3675,-7.21035 l -43.75,-0.38288 v 30.57408 30.57407 h 42.8219 c 37.383,0 43.4477,-0.21228 47.75,-1.67139 z m 186.4281,11.11706 v -88.55433 l 55.25,0.33131 c 53.883,0.32312 55.4126,0.38595 61.8221,2.53957 32.8507,11.03794 42.7686,46.25641 20.6676,73.39049 l -4.5506,5.58691 5.9625,4.20488 c 24.2118,17.07465 26.0959,53.09112 3.9277,75.0822 -3.6186,3.58969 -9.2793,7.9393 -12.5793,9.66581 -11.9617,6.25819 -12.5432,6.30749 -74.3943,6.30749 h -56.1057 z m 120.0125,67.34404 c 7.4446,-3.66016 13.6594,-9.99596 17.2401,-17.57573 2.4441,-5.1736 2.9696,-7.57262 2.9696,-13.55633 0,-13.00668 -5.7326,-21.72251 -18.1022,-27.52248 l -5.62,-2.63517 -49.25,-0.29407 -49.25,-0.29407 v 32.58893 32.58892 l 48.25,-0.29485 48.25,-0.29486 z m -7.8925,-82.92488 c 12.424,-5.8255 18.8958,-15.19817 18.858,-27.31117 -0.038,-12.06431 -5.6201,-19.88527 -17.5972,-24.65309 -5.8052,-2.31094 -6.4562,-2.34557 -50.6308,-2.69356 l -44.75,-0.35252 v 29.13812 29.13813 l 44.25,-0.31537 44.25,-0.31537 z m 88.88,15.62823 v -88.50694 l 68.25,0.25694 68.25,0.25694 0.2889,8.75 0.289,8.75 h -59.539 -59.5389 v 26.5 26.5 h 34 34 v 9 9 h -34 -34 v 35 35 h 59.5 59.5 v 9 9 h -68.5 -68.5 z m 176,0.007 v -88.5 h 9 9 v 79.5 79.5 h 56.5 56.5 v 9 9 h -65.5 -65.5 z m 206.6597,87.52067 c -40.6013,-7.38749 -69.2764,-39.34307 -73.1521,-81.52067 -0.8242,-8.96916 0.8654,-22.39373 4.1295,-32.81167 8.4218,-26.87906 28.9199,-47.9344 55.2005,-56.70092 18.7746,-6.26273 35.653,-6.23866 54.513,0.0777 25.5622,8.56102 45.823,29.12558 54.512,55.32939 16.0956,48.54016 -10.9221,99.6801 -60.0362,113.63827 -8.2788,2.35281 -27.2631,3.42594 -35.1667,1.98787 z m 25.8403,-18.51184 c 25.0727,-4.45459 46.934,-25.33602 53.5315,-51.13213 2.6544,-10.37845 2.6529,-25.38084 0,-35.76728 -8.5763,-33.53307 -40.5094,-55.75313 -74.0758,-51.54426 -15.8282,1.98469 -28.1141,8.12743 -39.9714,19.98495 -13.4625,13.46277 -19.9808,29.74149 -19.9808,49.89969 0,13.03651 1.5762,19.62446 7.6627,32.02841 6.5477,13.34361 16.9396,23.75154 30.3737,30.42059 14.3197,7.10869 26.7642,8.8993 42.4636,6.11003 z m 280.5,-69.00889 v -88.5 h 68 68 v 9 9 h -59 -59 v 26.5 26.5 h 33.5 33.5 v 9 9 h -33.5 -33.5 v 35 35 h 59 59 v 9 9 h -68 -68 z m 171,-0.0754 v -88.57544 l 42.75,0.39029 c 39.6891,0.36235 43.2937,0.54095 50.3434,2.49448 40.9455,11.3463 68.0273,48.83229 65.5741,90.76611 -1.2744,21.78433 -9.6336,41.15337 -24.5071,56.78542 -12.7536,13.40405 -30.6584,22.75483 -49.1604,25.67395 -3.6241,0.57178 -23.8662,1.02886 -45.75,1.03308 l -39.25,0.008 v -88.57544 z m 92.5,67.22277 c 18.6951,-6.53035 32.2899,-18.31088 40.5601,-35.14733 5.6081,-11.41693 7.3357,-18.95299 7.3357,-32 0,-20.32672 -6.1511,-35.28046 -20.4149,-49.62977 -7.2538,-7.29732 -10.0376,-9.33032 -18.0296,-13.16695 -5.1982,-2.49544 -11.7013,-5.07161 -14.4513,-5.72483 -3.0427,-0.72273 -17.6246,-1.38252 -37.25,-1.68545 l -32.25,-0.49781 v 70.68426 70.68426 l 33.25,-0.36096 33.25,-0.36096 z m -419.7527,-67.14884 c -24.061,-48.12583 -43.7473,-87.72583 -43.7473,-88 0,-0.27417 4.3901,-0.49849 9.7559,-0.49849 h 9.7559 l 33.9882,68 c 18.6935,37.4 34.2159,67.99979 34.4941,67.99953 0.2783,-2.5e-4 15.8059,-30.48775 34.5059,-67.75 l 34,-67.74953 9.75,-0.28621 c 5.3625,-0.15742 9.75,-0.0456 9.75,0.24849 0,1.00865 -87.4943,175.53768 -88,175.53768 -0.2779,0 -20.1916,-39.37568 -44.2527,-87.50151 z M 283.80122,626.15401 C 190.30382,618.48508 106.14663,568.84201 53.408914,490.24901 25.294784,448.3516 8.0728705,401.5317 1.7237915,349.73663 -0.55815853,331.12074 -0.57757653,295.75602 1.6839925,277.2541 c 7.288285,-59.62553 30.2179095,-115.08049 66.5705915,-161 9.80603,-12.38666 36.979346,-39.750343 49.046636,-49.390233 46.10469,-36.830497 103.73334,-60.13958 162.5,-65.726433 17.40461,-1.654628 54.43455,-0.59276 71.73659,2.057114 39.24618,6.010704 76.54032,19.42445 111.01341,39.928685 l 7.75,4.609614 v 27.26063 c 0,14.99334 -0.17813,27.260623 -0.39585,27.260623 -0.21772,0 -4.68567,-2.696203 -9.92878,-5.991563 -35.64742,-22.40485 -82.67362,-40.01442 -123.17537,-46.12463 -25.8293,-3.89668 -57.27056,-2.52074 -85.5,3.74168 -36.0596,7.99946 -75.75914,27.31223 -105.60496,51.374013 -11.55788,9.31799 -32.75994,31.03263 -41.5078,42.51129 -30.042046,39.42018 -47.807126,81.91376 -54.552966,130.48921 -2.61517,18.83129 -2.35724,54.86022 0.52778,73.723 4.52303,29.57235 12.0274,53.87008 24.63917,79.777 12.92168,26.54355 27.205226,46.88287 47.998776,68.34876 22.24315,22.96236 42.62812,37.93879 71.15449,52.27578 34.04231,17.10923 66.4153,25.21665 105.84551,26.50772 27.31239,0.89429 50.64318,-2.01173 77.98585,-9.71372 l 11.51415,-3.24335 V 439.5917 313.2541 h 24 24 v 142.36989 142.3699 l -15.25,6.04867 c -8.3875,3.32677 -19.75,7.4705 -25.25,9.20828 -35.63555,11.25945 -76.354,15.90898 -113,12.90317 z m 528.5,0.44109 c -61.55586,-4.23488 -116.66567,-24.45112 -164.49055,-60.341 -39.90613,-29.94731 -70.64413,-67.11625 -93.03534,-112.5 -10.67508,-21.63685 -16.81941,-37.99888 -22.46554,-59.82454 -8.08761,-31.26344 -10.45363,-52.67338 -9.73253,-88.06926 0.73798,-36.22483 4.68225,-59.47753 15.70844,-92.6062 15.43445,-46.37346 38.83257,-85.10347 72.28542,-119.651263 49.14854,-50.757207 109.5119,-81.252209 181.2301,-91.555738 5.77541,-0.829735 19.39035,-1.279402 38,-1.255044 24.95696,0.03267 30.9829,0.34896 43.223,2.268716 80.435,12.615562 151.00658,54.915966 199.85098,119.790129 30.5686,40.60072 51.3856,89.5552 59.394,139.67472 5.9473,37.22054 5.2119,77.55367 -2.0731,113.70179 -21.8186,108.263 -99.0925,198.03572 -200.972,233.47864 -38.34384,13.33946 -80.34099,19.40578 -116.92288,16.88905 z m 53,-49.81839 c 117.1819,-17.60456 207.46848,-112.23595 221.49618,-232.15514 1.9166,-16.38404 1.9303,-46.23364 0.029,-62.48947 C 1076.2408,191.64051 1021.1676,113.06315 940.80122,73.786687 920.34224,63.788027 902.34077,57.488047 882.2526,53.296427 765.09086,28.849305 648.38949,87.538157 595.94211,197.28131 c -33.59144,70.28818 -35.06183,152.62085 -3.99767,223.84567 24.27657,55.66204 66.58383,101.3414 119.54258,129.07074 28.77564,15.06699 60.76034,24.66613 93.3142,28.00512 12.62529,1.29496 47.9265,0.46282 60.5,-1.42613 z m 346.66668,49.81072 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 289.500003 289.5 h 90.5 90.5 v 24 24 h -113.8333 c -62.6084,0 -114.1334,-0.3 -114.5,-0.66667 z m 419.9228,-0.43324 c -45.3584,-4.7814 -86.6078,-28.49326 -114.4401,-65.78502 -13.9989,-18.75669 -25.1058,-44.96228 -29.1953,-68.88367 -1.9016,-11.12305 -1.9541,-17.87554 -1.9541,-251.33077 V 0.254097 h 23.4801 23.4801 l 0.3026,239.750003 c 0.2807,222.45253 0.4263,240.25411 2.0173,246.73716 5.9717,24.33382 15.8836,42.62139 31.7199,58.52356 32.0114,32.14457 79.6172,42.51235 122.1164,26.59498 40.2071,-15.05895 69.0021,-52.14101 73.8514,-95.1057 0.6589,-5.83817 1.0187,-91.1198 1.024,-242.75 l 0.01,-233.750003 h 24.0331 24.033 l -0.3446,240.250003 -0.3447,240.25 -2.1564,11.16964 c -6.3773,33.03181 -21.6776,62.79398 -44.0473,85.68092 -35.0332,35.84331 -84.2913,53.74562 -133.5836,48.54953 z m 617.0772,0.43324 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 313.500003 313.5 h -23.3333 c -12.8334,0 -23.6334,-0.3 -24,-0.66667 z M 2405.3012,313.7541 V 0.254097 h 24 24 v 313.500003 313.5 h -24 -24 z m 324.3796,276.75 c 2.4308,-128.43371 14.0844,-225.18511 37.0098,-307.26529 24.3126,-87.0469 57.8679,-152.16089 116.457,-225.984713 13.8125,-17.403997 47.2531,-57 48.1392,-57 1.2031,0 37.89,43.652953 54.2073,64.5 64.8551,82.859253 102.0762,165.810333 124.2931,277.000003 14.0907,70.51984 21.3293,148.19289 23.1621,248.5385 l 0.6751,36.9615 h -24.0006 -24.0006 l -0.6451,-40.25 c -0.8728,-54.45747 -3.2294,-97.37808 -7.7552,-141.25 -2.0157,-19.53876 -5.5649,-48.26034 -6.4568,-52.25 l -0.503,-2.25 h -138.9015 -138.9015 l -0.5737,2.75 c -1.3048,6.25497 -5.6037,42.23877 -7.4966,62.75 -4.1897,45.40108 -5.8724,78.08226 -6.758,131.25 l -0.6537,39.25 h -23.9965 -23.9964 z m 329.9901,-257.5 c -16.2344,-75.39296 -44.3576,-142.31154 -84.8247,-201.83821 -14.6478,-21.54687 -41.7256,-56.911793 -43.5754,-56.911793 -0.9462,0 -17.0989,20.3312 -30.1903,38.000003 -41.3759,55.84305 -70.8145,117.14692 -89.7989,187 -4.4541,16.38903 -9.9804,40.25799 -9.9804,43.1072 0,1.84739 3.1285,1.8928 130.3961,1.8928 h 130.3961 z M 1909.3012,313.12705 V 0 l 28.75,0.545379 c 17.9216,0.339968 32.5164,1.11895 38.75,2.068238 49.7522,7.576561 85.9285,24.147722 113.9522,52.19778 12.4706,12.48242 21.7636,25.36226 29.5404,40.9427 21.2693,42.611433 24.3464,94.029103 8.5077,142.162463 -6.3556,19.31469 -11.5913,29.57928 -25.0003,49.0135 -0.7465,1.08188 -0.3662,1.95829 1.5,3.45676 14.1948,11.39799 25.2886,24.1977 34.6589,39.98836 24.0771,40.57424 32.4157,95.7704 21.7183,143.7621 -16.6222,74.57234 -71.742,126.3476 -153.8772,144.54032 -23.5242,5.21055 -47.5765,7.55118 -77.75,7.56618 l -20.75,0.0103 z m 67.0296,262.68603 c 76.2213,-10.14858 125.4273,-50.12555 139.1595,-113.05898 2.8851,-13.22248 3.5837,-41.39321 1.3952,-56.26475 -7.6001,-51.6453 -39.0273,-90.16381 -87.8883,-107.71956 l -8.8039,-3.16327 4.3039,-1.92621 c 8.6623,-3.87675 22.4588,-13.8852 30.7894,-22.33564 20.7256,-21.02389 32.3393,-47.80952 35.1972,-81.17828 2.6177,-30.56363 -3.3016,-57.78392 -17.8905,-82.27023 -6.1953,-10.398453 -22.0413,-26.645363 -32.7921,-33.621833 -20.4272,-13.25571 -46.3837,-21.8786 -74.75,-24.83229 l -7.75,-0.80699 V 312.94458 577.2541 l 4.25,-0.0195 c 2.3375,-0.0107 8.9883,-0.65041 14.7796,-1.4215 z m 709.8989,48.91102 c -54.2863,-8.46314 -107.5748,-44.21736 -148.5323,-99.65857 -36.799,-49.81226 -57.332,-112.54974 -57.3859,-175.33969 l -0.01,-12.02826 10.0146,-5.3032 c 5.508,-2.91675 13.9455,-7.89048 18.75,-11.05272 53.4162,-35.15792 97.2057,-103.2045 120.2758,-186.90192 10.4228,-37.814683 17.9593,-90.590529 17.9593,-125.765195 V 0.254097 h 24 24 l -0.014,6.25 c -0.024,10.561015 -1.8792,39.47964 -3.5126,54.75 -8.8899,83.111443 -36.952,162.700163 -78.2523,221.937063 -21.4625,30.78363 -50.9331,60.30689 -77.4119,77.55035 l -7.6586,4.98741 0.4809,5.01259 c 3.2211,33.5697 12.0172,63.4558 27.5226,93.51259 32.7718,63.52705 89.9499,109.46939 141.5954,113.77113 l 8.7506,0.72887 0.2681,23.75 0.2681,23.75 -6.2681,-0.0969 c -3.4475,-0.0533 -10.1253,-0.69818 -14.8396,-1.43314 z\"/>
				</svg>\";}i:5;a:2:{s:5:\"title\";s:18:\"Лого О НАС\";s:7:\"content\";s:12058:\"<svg class=\"logo_about\"
				        xmlns=\"http://www.w3.org/2000/svg\"
				 				viewbox=\"0 0 3133.6245 931.25458\"
				 				id=\"svg4485\"
				 				version=\"1.1\">
				 				<path
				   				id=\"path4495\"
				   				d=\"m 629.30122,842.7541 v -88.5 h 66 66 v 9 9 h -57 -57 v 26.5 26.5 h 35 35 v 9 9 h -35 -35 v 44 44 h -9 -9 z m 211.65975,87.52067 c -34.47599,-6.27297 -61.7046,-31.47756 -70.78222,-65.52067 -3.05474,-11.45594 -3.0869,-30.63469 -0.0718,-42.80135 8.12584,-32.78951 32.23466,-56.92548 65.19425,-65.26768 10.60111,-2.68319 28.61274,-2.47821 39.5,0.44952 16.38958,4.40738 29.65943,12.31595 41.5329,24.75279 11.794,12.35361 17.93771,23.7875 22.12701,41.17996 2.54057,10.54752 2.78654,27.3125 0.55317,37.70328 -7.08298,32.95362 -30.77549,58.39031 -62.88671,67.51628 -8.27874,2.35281 -27.26305,3.42594 -35.16662,1.98787 z m 30.47728,-19.55037 c 23.03887,-5.94895 42.76883,-26.14244 48.87705,-50.02536 2.41886,-9.45766 2.63029,-25.08622 0.4637,-34.27658 -2.02121,-8.57371 -7.19606,-19.37624 -12.86636,-26.8586 -20.76794,-27.40477 -58.43637,-34.73226 -88.35297,-17.18694 -3.16715,1.85745 -9.13825,6.75218 -13.26912,10.87718 -15.25585,15.2342 -22.58907,36.73121 -19.89473,58.32056 2.09163,16.75991 8.00647,28.72546 20.4054,41.27955 6.56501,6.64716 9.70669,8.94417 17.51467,12.8057 15.22329,7.52886 31.00831,9.22535 47.12236,5.06449 z m 110.10757,-67.7203 0.2554,-88.25 h 53.99998 54 l 7.8663,2.78197 c 18.3397,6.48598 28.9164,19.00064 31.877,37.71803 3.5016,22.13717 -10.9925,45.27 -33.5707,53.57957 -3.3949,1.24945 -6.0631,2.74616 -5.9293,3.32601 0.1338,0.57986 11.1009,18.05082 24.3713,38.82436 13.2704,20.77353 24.3465,38.33256 24.6137,39.02006 0.3696,0.95137 -2.0173,1.25 -9.9912,1.25 h -10.4768 l -25.2351,-39.5 -25.2351,-39.5 h -33.895 -33.8951 v 39.5 39.5 h -9.50538 -9.5055 z m 109.32728,-11.42139 c 6.7739,-2.29738 16.4593,-11.98282 18.7567,-18.75675 4.3048,-12.69281 0.8926,-26.4589 -8.2111,-33.12678 -9.3365,-6.83832 -8.9232,-6.78639 -57.3675,-7.21035 l -43.75,-0.38288 v 30.57408 30.57407 h 42.8219 c 37.383,0 43.4477,-0.21228 47.75,-1.67139 z m 186.4281,11.11706 v -88.55433 l 55.25,0.33131 c 53.883,0.32312 55.4126,0.38595 61.8221,2.53957 32.8507,11.03794 42.7686,46.25641 20.6676,73.39049 l -4.5506,5.58691 5.9625,4.20488 c 24.2118,17.07465 26.0959,53.09112 3.9277,75.0822 -3.6186,3.58969 -9.2793,7.9393 -12.5793,9.66581 -11.9617,6.25819 -12.5432,6.30749 -74.3943,6.30749 h -56.1057 z m 120.0125,67.34404 c 7.4446,-3.66016 13.6594,-9.99596 17.2401,-17.57573 2.4441,-5.1736 2.9696,-7.57262 2.9696,-13.55633 0,-13.00668 -5.7326,-21.72251 -18.1022,-27.52248 l -5.62,-2.63517 -49.25,-0.29407 -49.25,-0.29407 v 32.58893 32.58892 l 48.25,-0.29485 48.25,-0.29486 z m -7.8925,-82.92488 c 12.424,-5.8255 18.8958,-15.19817 18.858,-27.31117 -0.038,-12.06431 -5.6201,-19.88527 -17.5972,-24.65309 -5.8052,-2.31094 -6.4562,-2.34557 -50.6308,-2.69356 l -44.75,-0.35252 v 29.13812 29.13813 l 44.25,-0.31537 44.25,-0.31537 z m 88.88,15.62823 v -88.50694 l 68.25,0.25694 68.25,0.25694 0.2889,8.75 0.289,8.75 h -59.539 -59.5389 v 26.5 26.5 h 34 34 v 9 9 h -34 -34 v 35 35 h 59.5 59.5 v 9 9 h -68.5 -68.5 z m 176,0.007 v -88.5 h 9 9 v 79.5 79.5 h 56.5 56.5 v 9 9 h -65.5 -65.5 z m 206.6597,87.52067 c -40.6013,-7.38749 -69.2764,-39.34307 -73.1521,-81.52067 -0.8242,-8.96916 0.8654,-22.39373 4.1295,-32.81167 8.4218,-26.87906 28.9199,-47.9344 55.2005,-56.70092 18.7746,-6.26273 35.653,-6.23866 54.513,0.0777 25.5622,8.56102 45.823,29.12558 54.512,55.32939 16.0956,48.54016 -10.9221,99.6801 -60.0362,113.63827 -8.2788,2.35281 -27.2631,3.42594 -35.1667,1.98787 z m 25.8403,-18.51184 c 25.0727,-4.45459 46.934,-25.33602 53.5315,-51.13213 2.6544,-10.37845 2.6529,-25.38084 0,-35.76728 -8.5763,-33.53307 -40.5094,-55.75313 -74.0758,-51.54426 -15.8282,1.98469 -28.1141,8.12743 -39.9714,19.98495 -13.4625,13.46277 -19.9808,29.74149 -19.9808,49.89969 0,13.03651 1.5762,19.62446 7.6627,32.02841 6.5477,13.34361 16.9396,23.75154 30.3737,30.42059 14.3197,7.10869 26.7642,8.8993 42.4636,6.11003 z m 280.5,-69.00889 v -88.5 h 68 68 v 9 9 h -59 -59 v 26.5 26.5 h 33.5 33.5 v 9 9 h -33.5 -33.5 v 35 35 h 59 59 v 9 9 h -68 -68 z m 171,-0.0754 v -88.57544 l 42.75,0.39029 c 39.6891,0.36235 43.2937,0.54095 50.3434,2.49448 40.9455,11.3463 68.0273,48.83229 65.5741,90.76611 -1.2744,21.78433 -9.6336,41.15337 -24.5071,56.78542 -12.7536,13.40405 -30.6584,22.75483 -49.1604,25.67395 -3.6241,0.57178 -23.8662,1.02886 -45.75,1.03308 l -39.25,0.008 v -88.57544 z m 92.5,67.22277 c 18.6951,-6.53035 32.2899,-18.31088 40.5601,-35.14733 5.6081,-11.41693 7.3357,-18.95299 7.3357,-32 0,-20.32672 -6.1511,-35.28046 -20.4149,-49.62977 -7.2538,-7.29732 -10.0376,-9.33032 -18.0296,-13.16695 -5.1982,-2.49544 -11.7013,-5.07161 -14.4513,-5.72483 -3.0427,-0.72273 -17.6246,-1.38252 -37.25,-1.68545 l -32.25,-0.49781 v 70.68426 70.68426 l 33.25,-0.36096 33.25,-0.36096 z m -419.7527,-67.14884 c -24.061,-48.12583 -43.7473,-87.72583 -43.7473,-88 0,-0.27417 4.3901,-0.49849 9.7559,-0.49849 h 9.7559 l 33.9882,68 c 18.6935,37.4 34.2159,67.99979 34.4941,67.99953 0.2783,-2.5e-4 15.8059,-30.48775 34.5059,-67.75 l 34,-67.74953 9.75,-0.28621 c 5.3625,-0.15742 9.75,-0.0456 9.75,0.24849 0,1.00865 -87.4943,175.53768 -88,175.53768 -0.2779,0 -20.1916,-39.37568 -44.2527,-87.50151 z M 283.80122,626.15401 C 190.30382,618.48508 106.14663,568.84201 53.408914,490.24901 25.294784,448.3516 8.0728705,401.5317 1.7237915,349.73663 -0.55815853,331.12074 -0.57757653,295.75602 1.6839925,277.2541 c 7.288285,-59.62553 30.2179095,-115.08049 66.5705915,-161 9.80603,-12.38666 36.979346,-39.750343 49.046636,-49.390233 46.10469,-36.830497 103.73334,-60.13958 162.5,-65.726433 17.40461,-1.654628 54.43455,-0.59276 71.73659,2.057114 39.24618,6.010704 76.54032,19.42445 111.01341,39.928685 l 7.75,4.609614 v 27.26063 c 0,14.99334 -0.17813,27.260623 -0.39585,27.260623 -0.21772,0 -4.68567,-2.696203 -9.92878,-5.991563 -35.64742,-22.40485 -82.67362,-40.01442 -123.17537,-46.12463 -25.8293,-3.89668 -57.27056,-2.52074 -85.5,3.74168 -36.0596,7.99946 -75.75914,27.31223 -105.60496,51.374013 -11.55788,9.31799 -32.75994,31.03263 -41.5078,42.51129 -30.042046,39.42018 -47.807126,81.91376 -54.552966,130.48921 -2.61517,18.83129 -2.35724,54.86022 0.52778,73.723 4.52303,29.57235 12.0274,53.87008 24.63917,79.777 12.92168,26.54355 27.205226,46.88287 47.998776,68.34876 22.24315,22.96236 42.62812,37.93879 71.15449,52.27578 34.04231,17.10923 66.4153,25.21665 105.84551,26.50772 27.31239,0.89429 50.64318,-2.01173 77.98585,-9.71372 l 11.51415,-3.24335 V 439.5917 313.2541 h 24 24 v 142.36989 142.3699 l -15.25,6.04867 c -8.3875,3.32677 -19.75,7.4705 -25.25,9.20828 -35.63555,11.25945 -76.354,15.90898 -113,12.90317 z m 528.5,0.44109 c -61.55586,-4.23488 -116.66567,-24.45112 -164.49055,-60.341 -39.90613,-29.94731 -70.64413,-67.11625 -93.03534,-112.5 -10.67508,-21.63685 -16.81941,-37.99888 -22.46554,-59.82454 -8.08761,-31.26344 -10.45363,-52.67338 -9.73253,-88.06926 0.73798,-36.22483 4.68225,-59.47753 15.70844,-92.6062 15.43445,-46.37346 38.83257,-85.10347 72.28542,-119.651263 49.14854,-50.757207 109.5119,-81.252209 181.2301,-91.555738 5.77541,-0.829735 19.39035,-1.279402 38,-1.255044 24.95696,0.03267 30.9829,0.34896 43.223,2.268716 80.435,12.615562 151.00658,54.915966 199.85098,119.790129 30.5686,40.60072 51.3856,89.5552 59.394,139.67472 5.9473,37.22054 5.2119,77.55367 -2.0731,113.70179 -21.8186,108.263 -99.0925,198.03572 -200.972,233.47864 -38.34384,13.33946 -80.34099,19.40578 -116.92288,16.88905 z m 53,-49.81839 c 117.1819,-17.60456 207.46848,-112.23595 221.49618,-232.15514 1.9166,-16.38404 1.9303,-46.23364 0.029,-62.48947 C 1076.2408,191.64051 1021.1676,113.06315 940.80122,73.786687 920.34224,63.788027 902.34077,57.488047 882.2526,53.296427 765.09086,28.849305 648.38949,87.538157 595.94211,197.28131 c -33.59144,70.28818 -35.06183,152.62085 -3.99767,223.84567 24.27657,55.66204 66.58383,101.3414 119.54258,129.07074 28.77564,15.06699 60.76034,24.66613 93.3142,28.00512 12.62529,1.29496 47.9265,0.46282 60.5,-1.42613 z m 346.66668,49.81072 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 289.500003 289.5 h 90.5 90.5 v 24 24 h -113.8333 c -62.6084,0 -114.1334,-0.3 -114.5,-0.66667 z m 419.9228,-0.43324 c -45.3584,-4.7814 -86.6078,-28.49326 -114.4401,-65.78502 -13.9989,-18.75669 -25.1058,-44.96228 -29.1953,-68.88367 -1.9016,-11.12305 -1.9541,-17.87554 -1.9541,-251.33077 V 0.254097 h 23.4801 23.4801 l 0.3026,239.750003 c 0.2807,222.45253 0.4263,240.25411 2.0173,246.73716 5.9717,24.33382 15.8836,42.62139 31.7199,58.52356 32.0114,32.14457 79.6172,42.51235 122.1164,26.59498 40.2071,-15.05895 69.0021,-52.14101 73.8514,-95.1057 0.6589,-5.83817 1.0187,-91.1198 1.024,-242.75 l 0.01,-233.750003 h 24.0331 24.033 l -0.3446,240.250003 -0.3447,240.25 -2.1564,11.16964 c -6.3773,33.03181 -21.6776,62.79398 -44.0473,85.68092 -35.0332,35.84331 -84.2913,53.74562 -133.5836,48.54953 z m 617.0772,0.43324 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 313.500003 313.5 h -23.3333 c -12.8334,0 -23.6334,-0.3 -24,-0.66667 z M 2405.3012,313.7541 V 0.254097 h 24 24 v 313.500003 313.5 h -24 -24 z m 324.3796,276.75 c 2.4308,-128.43371 14.0844,-225.18511 37.0098,-307.26529 24.3126,-87.0469 57.8679,-152.16089 116.457,-225.984713 13.8125,-17.403997 47.2531,-57 48.1392,-57 1.2031,0 37.89,43.652953 54.2073,64.5 64.8551,82.859253 102.0762,165.810333 124.2931,277.000003 14.0907,70.51984 21.3293,148.19289 23.1621,248.5385 l 0.6751,36.9615 h -24.0006 -24.0006 l -0.6451,-40.25 c -0.8728,-54.45747 -3.2294,-97.37808 -7.7552,-141.25 -2.0157,-19.53876 -5.5649,-48.26034 -6.4568,-52.25 l -0.503,-2.25 h -138.9015 -138.9015 l -0.5737,2.75 c -1.3048,6.25497 -5.6037,42.23877 -7.4966,62.75 -4.1897,45.40108 -5.8724,78.08226 -6.758,131.25 l -0.6537,39.25 h -23.9965 -23.9964 z m 329.9901,-257.5 c -16.2344,-75.39296 -44.3576,-142.31154 -84.8247,-201.83821 -14.6478,-21.54687 -41.7256,-56.911793 -43.5754,-56.911793 -0.9462,0 -17.0989,20.3312 -30.1903,38.000003 -41.3759,55.84305 -70.8145,117.14692 -89.7989,187 -4.4541,16.38903 -9.9804,40.25799 -9.9804,43.1072 0,1.84739 3.1285,1.8928 130.3961,1.8928 h 130.3961 z M 1909.3012,313.12705 V 0 l 28.75,0.545379 c 17.9216,0.339968 32.5164,1.11895 38.75,2.068238 49.7522,7.576561 85.9285,24.147722 113.9522,52.19778 12.4706,12.48242 21.7636,25.36226 29.5404,40.9427 21.2693,42.611433 24.3464,94.029103 8.5077,142.162463 -6.3556,19.31469 -11.5913,29.57928 -25.0003,49.0135 -0.7465,1.08188 -0.3662,1.95829 1.5,3.45676 14.1948,11.39799 25.2886,24.1977 34.6589,39.98836 24.0771,40.57424 32.4157,95.7704 21.7183,143.7621 -16.6222,74.57234 -71.742,126.3476 -153.8772,144.54032 -23.5242,5.21055 -47.5765,7.55118 -77.75,7.56618 l -20.75,0.0103 z m 67.0296,262.68603 c 76.2213,-10.14858 125.4273,-50.12555 139.1595,-113.05898 2.8851,-13.22248 3.5837,-41.39321 1.3952,-56.26475 -7.6001,-51.6453 -39.0273,-90.16381 -87.8883,-107.71956 l -8.8039,-3.16327 4.3039,-1.92621 c 8.6623,-3.87675 22.4588,-13.8852 30.7894,-22.33564 20.7256,-21.02389 32.3393,-47.80952 35.1972,-81.17828 2.6177,-30.56363 -3.3016,-57.78392 -17.8905,-82.27023 -6.1953,-10.398453 -22.0413,-26.645363 -32.7921,-33.621833 -20.4272,-13.25571 -46.3837,-21.8786 -74.75,-24.83229 l -7.75,-0.80699 V 312.94458 577.2541 l 4.25,-0.0195 c 2.3375,-0.0107 8.9883,-0.65041 14.7796,-1.4215 z m 709.8989,48.91102 c -54.2863,-8.46314 -107.5748,-44.21736 -148.5323,-99.65857 -36.799,-49.81226 -57.332,-112.54974 -57.3859,-175.33969 l -0.01,-12.02826 10.0146,-5.3032 c 5.508,-2.91675 13.9455,-7.89048 18.75,-11.05272 53.4162,-35.15792 97.2057,-103.2045 120.2758,-186.90192 10.4228,-37.814683 17.9593,-90.590529 17.9593,-125.765195 V 0.254097 h 24 24 l -0.014,6.25 c -0.024,10.561015 -1.8792,39.47964 -3.5126,54.75 -8.8899,83.111443 -36.952,162.700163 -78.2523,221.937063 -21.4625,30.78363 -50.9331,60.30689 -77.4119,77.55035 l -7.6586,4.98741 0.4809,5.01259 c 3.2211,33.5697 12.0172,63.4558 27.5226,93.51259 32.7718,63.52705 89.9499,109.46939 141.5954,113.77113 l 8.7506,0.72887 0.2681,23.75 0.2681,23.75 -6.2681,-0.0969 c -3.4475,-0.0533 -10.1253,-0.69818 -14.8396,-1.43314 z\"/>
							</svg> \";}i:6;a:2:{s:5:\"title\";s:19:\"Лого футер\";s:7:\"content\";s:12050:\"<svg class=\"footer_logo\"
			        xmlns=\"http://www.w3.org/2000/svg\"
			 				viewbox=\"0 0 3133.6245 931.25458\"
			 				id=\"svg4485\"
			 				version=\"1.1\">
			 				<path
			   				id=\"path4495\"
			   				d=\"m 629.30122,842.7541 v -88.5 h 66 66 v 9 9 h -57 -57 v 26.5 26.5 h 35 35 v 9 9 h -35 -35 v 44 44 h -9 -9 z m 211.65975,87.52067 c -34.47599,-6.27297 -61.7046,-31.47756 -70.78222,-65.52067 -3.05474,-11.45594 -3.0869,-30.63469 -0.0718,-42.80135 8.12584,-32.78951 32.23466,-56.92548 65.19425,-65.26768 10.60111,-2.68319 28.61274,-2.47821 39.5,0.44952 16.38958,4.40738 29.65943,12.31595 41.5329,24.75279 11.794,12.35361 17.93771,23.7875 22.12701,41.17996 2.54057,10.54752 2.78654,27.3125 0.55317,37.70328 -7.08298,32.95362 -30.77549,58.39031 -62.88671,67.51628 -8.27874,2.35281 -27.26305,3.42594 -35.16662,1.98787 z m 30.47728,-19.55037 c 23.03887,-5.94895 42.76883,-26.14244 48.87705,-50.02536 2.41886,-9.45766 2.63029,-25.08622 0.4637,-34.27658 -2.02121,-8.57371 -7.19606,-19.37624 -12.86636,-26.8586 -20.76794,-27.40477 -58.43637,-34.73226 -88.35297,-17.18694 -3.16715,1.85745 -9.13825,6.75218 -13.26912,10.87718 -15.25585,15.2342 -22.58907,36.73121 -19.89473,58.32056 2.09163,16.75991 8.00647,28.72546 20.4054,41.27955 6.56501,6.64716 9.70669,8.94417 17.51467,12.8057 15.22329,7.52886 31.00831,9.22535 47.12236,5.06449 z m 110.10757,-67.7203 0.2554,-88.25 h 53.99998 54 l 7.8663,2.78197 c 18.3397,6.48598 28.9164,19.00064 31.877,37.71803 3.5016,22.13717 -10.9925,45.27 -33.5707,53.57957 -3.3949,1.24945 -6.0631,2.74616 -5.9293,3.32601 0.1338,0.57986 11.1009,18.05082 24.3713,38.82436 13.2704,20.77353 24.3465,38.33256 24.6137,39.02006 0.3696,0.95137 -2.0173,1.25 -9.9912,1.25 h -10.4768 l -25.2351,-39.5 -25.2351,-39.5 h -33.895 -33.8951 v 39.5 39.5 h -9.50538 -9.5055 z m 109.32728,-11.42139 c 6.7739,-2.29738 16.4593,-11.98282 18.7567,-18.75675 4.3048,-12.69281 0.8926,-26.4589 -8.2111,-33.12678 -9.3365,-6.83832 -8.9232,-6.78639 -57.3675,-7.21035 l -43.75,-0.38288 v 30.57408 30.57407 h 42.8219 c 37.383,0 43.4477,-0.21228 47.75,-1.67139 z m 186.4281,11.11706 v -88.55433 l 55.25,0.33131 c 53.883,0.32312 55.4126,0.38595 61.8221,2.53957 32.8507,11.03794 42.7686,46.25641 20.6676,73.39049 l -4.5506,5.58691 5.9625,4.20488 c 24.2118,17.07465 26.0959,53.09112 3.9277,75.0822 -3.6186,3.58969 -9.2793,7.9393 -12.5793,9.66581 -11.9617,6.25819 -12.5432,6.30749 -74.3943,6.30749 h -56.1057 z m 120.0125,67.34404 c 7.4446,-3.66016 13.6594,-9.99596 17.2401,-17.57573 2.4441,-5.1736 2.9696,-7.57262 2.9696,-13.55633 0,-13.00668 -5.7326,-21.72251 -18.1022,-27.52248 l -5.62,-2.63517 -49.25,-0.29407 -49.25,-0.29407 v 32.58893 32.58892 l 48.25,-0.29485 48.25,-0.29486 z m -7.8925,-82.92488 c 12.424,-5.8255 18.8958,-15.19817 18.858,-27.31117 -0.038,-12.06431 -5.6201,-19.88527 -17.5972,-24.65309 -5.8052,-2.31094 -6.4562,-2.34557 -50.6308,-2.69356 l -44.75,-0.35252 v 29.13812 29.13813 l 44.25,-0.31537 44.25,-0.31537 z m 88.88,15.62823 v -88.50694 l 68.25,0.25694 68.25,0.25694 0.2889,8.75 0.289,8.75 h -59.539 -59.5389 v 26.5 26.5 h 34 34 v 9 9 h -34 -34 v 35 35 h 59.5 59.5 v 9 9 h -68.5 -68.5 z m 176,0.007 v -88.5 h 9 9 v 79.5 79.5 h 56.5 56.5 v 9 9 h -65.5 -65.5 z m 206.6597,87.52067 c -40.6013,-7.38749 -69.2764,-39.34307 -73.1521,-81.52067 -0.8242,-8.96916 0.8654,-22.39373 4.1295,-32.81167 8.4218,-26.87906 28.9199,-47.9344 55.2005,-56.70092 18.7746,-6.26273 35.653,-6.23866 54.513,0.0777 25.5622,8.56102 45.823,29.12558 54.512,55.32939 16.0956,48.54016 -10.9221,99.6801 -60.0362,113.63827 -8.2788,2.35281 -27.2631,3.42594 -35.1667,1.98787 z m 25.8403,-18.51184 c 25.0727,-4.45459 46.934,-25.33602 53.5315,-51.13213 2.6544,-10.37845 2.6529,-25.38084 0,-35.76728 -8.5763,-33.53307 -40.5094,-55.75313 -74.0758,-51.54426 -15.8282,1.98469 -28.1141,8.12743 -39.9714,19.98495 -13.4625,13.46277 -19.9808,29.74149 -19.9808,49.89969 0,13.03651 1.5762,19.62446 7.6627,32.02841 6.5477,13.34361 16.9396,23.75154 30.3737,30.42059 14.3197,7.10869 26.7642,8.8993 42.4636,6.11003 z m 280.5,-69.00889 v -88.5 h 68 68 v 9 9 h -59 -59 v 26.5 26.5 h 33.5 33.5 v 9 9 h -33.5 -33.5 v 35 35 h 59 59 v 9 9 h -68 -68 z m 171,-0.0754 v -88.57544 l 42.75,0.39029 c 39.6891,0.36235 43.2937,0.54095 50.3434,2.49448 40.9455,11.3463 68.0273,48.83229 65.5741,90.76611 -1.2744,21.78433 -9.6336,41.15337 -24.5071,56.78542 -12.7536,13.40405 -30.6584,22.75483 -49.1604,25.67395 -3.6241,0.57178 -23.8662,1.02886 -45.75,1.03308 l -39.25,0.008 v -88.57544 z m 92.5,67.22277 c 18.6951,-6.53035 32.2899,-18.31088 40.5601,-35.14733 5.6081,-11.41693 7.3357,-18.95299 7.3357,-32 0,-20.32672 -6.1511,-35.28046 -20.4149,-49.62977 -7.2538,-7.29732 -10.0376,-9.33032 -18.0296,-13.16695 -5.1982,-2.49544 -11.7013,-5.07161 -14.4513,-5.72483 -3.0427,-0.72273 -17.6246,-1.38252 -37.25,-1.68545 l -32.25,-0.49781 v 70.68426 70.68426 l 33.25,-0.36096 33.25,-0.36096 z m -419.7527,-67.14884 c -24.061,-48.12583 -43.7473,-87.72583 -43.7473,-88 0,-0.27417 4.3901,-0.49849 9.7559,-0.49849 h 9.7559 l 33.9882,68 c 18.6935,37.4 34.2159,67.99979 34.4941,67.99953 0.2783,-2.5e-4 15.8059,-30.48775 34.5059,-67.75 l 34,-67.74953 9.75,-0.28621 c 5.3625,-0.15742 9.75,-0.0456 9.75,0.24849 0,1.00865 -87.4943,175.53768 -88,175.53768 -0.2779,0 -20.1916,-39.37568 -44.2527,-87.50151 z M 283.80122,626.15401 C 190.30382,618.48508 106.14663,568.84201 53.408914,490.24901 25.294784,448.3516 8.0728705,401.5317 1.7237915,349.73663 -0.55815853,331.12074 -0.57757653,295.75602 1.6839925,277.2541 c 7.288285,-59.62553 30.2179095,-115.08049 66.5705915,-161 9.80603,-12.38666 36.979346,-39.750343 49.046636,-49.390233 46.10469,-36.830497 103.73334,-60.13958 162.5,-65.726433 17.40461,-1.654628 54.43455,-0.59276 71.73659,2.057114 39.24618,6.010704 76.54032,19.42445 111.01341,39.928685 l 7.75,4.609614 v 27.26063 c 0,14.99334 -0.17813,27.260623 -0.39585,27.260623 -0.21772,0 -4.68567,-2.696203 -9.92878,-5.991563 -35.64742,-22.40485 -82.67362,-40.01442 -123.17537,-46.12463 -25.8293,-3.89668 -57.27056,-2.52074 -85.5,3.74168 -36.0596,7.99946 -75.75914,27.31223 -105.60496,51.374013 -11.55788,9.31799 -32.75994,31.03263 -41.5078,42.51129 -30.042046,39.42018 -47.807126,81.91376 -54.552966,130.48921 -2.61517,18.83129 -2.35724,54.86022 0.52778,73.723 4.52303,29.57235 12.0274,53.87008 24.63917,79.777 12.92168,26.54355 27.205226,46.88287 47.998776,68.34876 22.24315,22.96236 42.62812,37.93879 71.15449,52.27578 34.04231,17.10923 66.4153,25.21665 105.84551,26.50772 27.31239,0.89429 50.64318,-2.01173 77.98585,-9.71372 l 11.51415,-3.24335 V 439.5917 313.2541 h 24 24 v 142.36989 142.3699 l -15.25,6.04867 c -8.3875,3.32677 -19.75,7.4705 -25.25,9.20828 -35.63555,11.25945 -76.354,15.90898 -113,12.90317 z m 528.5,0.44109 c -61.55586,-4.23488 -116.66567,-24.45112 -164.49055,-60.341 -39.90613,-29.94731 -70.64413,-67.11625 -93.03534,-112.5 -10.67508,-21.63685 -16.81941,-37.99888 -22.46554,-59.82454 -8.08761,-31.26344 -10.45363,-52.67338 -9.73253,-88.06926 0.73798,-36.22483 4.68225,-59.47753 15.70844,-92.6062 15.43445,-46.37346 38.83257,-85.10347 72.28542,-119.651263 49.14854,-50.757207 109.5119,-81.252209 181.2301,-91.555738 5.77541,-0.829735 19.39035,-1.279402 38,-1.255044 24.95696,0.03267 30.9829,0.34896 43.223,2.268716 80.435,12.615562 151.00658,54.915966 199.85098,119.790129 30.5686,40.60072 51.3856,89.5552 59.394,139.67472 5.9473,37.22054 5.2119,77.55367 -2.0731,113.70179 -21.8186,108.263 -99.0925,198.03572 -200.972,233.47864 -38.34384,13.33946 -80.34099,19.40578 -116.92288,16.88905 z m 53,-49.81839 c 117.1819,-17.60456 207.46848,-112.23595 221.49618,-232.15514 1.9166,-16.38404 1.9303,-46.23364 0.029,-62.48947 C 1076.2408,191.64051 1021.1676,113.06315 940.80122,73.786687 920.34224,63.788027 902.34077,57.488047 882.2526,53.296427 765.09086,28.849305 648.38949,87.538157 595.94211,197.28131 c -33.59144,70.28818 -35.06183,152.62085 -3.99767,223.84567 24.27657,55.66204 66.58383,101.3414 119.54258,129.07074 28.77564,15.06699 60.76034,24.66613 93.3142,28.00512 12.62529,1.29496 47.9265,0.46282 60.5,-1.42613 z m 346.66668,49.81072 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 289.500003 289.5 h 90.5 90.5 v 24 24 h -113.8333 c -62.6084,0 -114.1334,-0.3 -114.5,-0.66667 z m 419.9228,-0.43324 c -45.3584,-4.7814 -86.6078,-28.49326 -114.4401,-65.78502 -13.9989,-18.75669 -25.1058,-44.96228 -29.1953,-68.88367 -1.9016,-11.12305 -1.9541,-17.87554 -1.9541,-251.33077 V 0.254097 h 23.4801 23.4801 l 0.3026,239.750003 c 0.2807,222.45253 0.4263,240.25411 2.0173,246.73716 5.9717,24.33382 15.8836,42.62139 31.7199,58.52356 32.0114,32.14457 79.6172,42.51235 122.1164,26.59498 40.2071,-15.05895 69.0021,-52.14101 73.8514,-95.1057 0.6589,-5.83817 1.0187,-91.1198 1.024,-242.75 l 0.01,-233.750003 h 24.0331 24.033 l -0.3446,240.250003 -0.3447,240.25 -2.1564,11.16964 c -6.3773,33.03181 -21.6776,62.79398 -44.0473,85.68092 -35.0332,35.84331 -84.2913,53.74562 -133.5836,48.54953 z m 617.0772,0.43324 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 313.500003 313.5 h -23.3333 c -12.8334,0 -23.6334,-0.3 -24,-0.66667 z M 2405.3012,313.7541 V 0.254097 h 24 24 v 313.500003 313.5 h -24 -24 z m 324.3796,276.75 c 2.4308,-128.43371 14.0844,-225.18511 37.0098,-307.26529 24.3126,-87.0469 57.8679,-152.16089 116.457,-225.984713 13.8125,-17.403997 47.2531,-57 48.1392,-57 1.2031,0 37.89,43.652953 54.2073,64.5 64.8551,82.859253 102.0762,165.810333 124.2931,277.000003 14.0907,70.51984 21.3293,148.19289 23.1621,248.5385 l 0.6751,36.9615 h -24.0006 -24.0006 l -0.6451,-40.25 c -0.8728,-54.45747 -3.2294,-97.37808 -7.7552,-141.25 -2.0157,-19.53876 -5.5649,-48.26034 -6.4568,-52.25 l -0.503,-2.25 h -138.9015 -138.9015 l -0.5737,2.75 c -1.3048,6.25497 -5.6037,42.23877 -7.4966,62.75 -4.1897,45.40108 -5.8724,78.08226 -6.758,131.25 l -0.6537,39.25 h -23.9965 -23.9964 z m 329.9901,-257.5 c -16.2344,-75.39296 -44.3576,-142.31154 -84.8247,-201.83821 -14.6478,-21.54687 -41.7256,-56.911793 -43.5754,-56.911793 -0.9462,0 -17.0989,20.3312 -30.1903,38.000003 -41.3759,55.84305 -70.8145,117.14692 -89.7989,187 -4.4541,16.38903 -9.9804,40.25799 -9.9804,43.1072 0,1.84739 3.1285,1.8928 130.3961,1.8928 h 130.3961 z M 1909.3012,313.12705 V 0 l 28.75,0.545379 c 17.9216,0.339968 32.5164,1.11895 38.75,2.068238 49.7522,7.576561 85.9285,24.147722 113.9522,52.19778 12.4706,12.48242 21.7636,25.36226 29.5404,40.9427 21.2693,42.611433 24.3464,94.029103 8.5077,142.162463 -6.3556,19.31469 -11.5913,29.57928 -25.0003,49.0135 -0.7465,1.08188 -0.3662,1.95829 1.5,3.45676 14.1948,11.39799 25.2886,24.1977 34.6589,39.98836 24.0771,40.57424 32.4157,95.7704 21.7183,143.7621 -16.6222,74.57234 -71.742,126.3476 -153.8772,144.54032 -23.5242,5.21055 -47.5765,7.55118 -77.75,7.56618 l -20.75,0.0103 z m 67.0296,262.68603 c 76.2213,-10.14858 125.4273,-50.12555 139.1595,-113.05898 2.8851,-13.22248 3.5837,-41.39321 1.3952,-56.26475 -7.6001,-51.6453 -39.0273,-90.16381 -87.8883,-107.71956 l -8.8039,-3.16327 4.3039,-1.92621 c 8.6623,-3.87675 22.4588,-13.8852 30.7894,-22.33564 20.7256,-21.02389 32.3393,-47.80952 35.1972,-81.17828 2.6177,-30.56363 -3.3016,-57.78392 -17.8905,-82.27023 -6.1953,-10.398453 -22.0413,-26.645363 -32.7921,-33.621833 -20.4272,-13.25571 -46.3837,-21.8786 -74.75,-24.83229 l -7.75,-0.80699 V 312.94458 577.2541 l 4.25,-0.0195 c 2.3375,-0.0107 8.9883,-0.65041 14.7796,-1.4215 z m 709.8989,48.91102 c -54.2863,-8.46314 -107.5748,-44.21736 -148.5323,-99.65857 -36.799,-49.81226 -57.332,-112.54974 -57.3859,-175.33969 l -0.01,-12.02826 10.0146,-5.3032 c 5.508,-2.91675 13.9455,-7.89048 18.75,-11.05272 53.4162,-35.15792 97.2057,-103.2045 120.2758,-186.90192 10.4228,-37.814683 17.9593,-90.590529 17.9593,-125.765195 V 0.254097 h 24 24 l -0.014,6.25 c -0.024,10.561015 -1.8792,39.47964 -3.5126,54.75 -8.8899,83.111443 -36.952,162.700163 -78.2523,221.937063 -21.4625,30.78363 -50.9331,60.30689 -77.4119,77.55035 l -7.6586,4.98741 0.4809,5.01259 c 3.2211,33.5697 12.0172,63.4558 27.5226,93.51259 32.7718,63.52705 89.9499,109.46939 141.5954,113.77113 l 8.7506,0.72887 0.2681,23.75 0.2681,23.75 -6.2681,-0.0969 c -3.4475,-0.0533 -10.1253,-0.69818 -14.8396,-1.43314 z\"/>
						</svg>\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("110","cron","a:5:{i:1524070290;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1524070359;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1524070980;a:2:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1524139269;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `gol_options` VALUES("111","theme_mods_twentyseventeen","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1516563638;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `gol_options` VALUES("125","can_compress_scripts","1","no");
INSERT INTO `gol_options` VALUES("139","recently_activated","a:2:{s:66:\"reorder-post-within-categories/reorder-posts-within-categories.php\";i:1522597506;s:37:\"post-types-order/post-types-order.php\";i:1522596880;}","yes");
INSERT INTO `gol_options` VALUES("163","polylang","a:15:{s:7:\"browser\";b:0;s:7:\"rewrite\";i:1;s:12:\"hide_default\";i:1;s:10:\"force_lang\";i:1;s:13:\"redirect_lang\";i:0;s:13:\"media_support\";i:1;s:9:\"uninstall\";i:0;s:4:\"sync\";a:11:{i:0;s:10:\"taxonomies\";i:1;s:9:\"post_meta\";i:2;s:14:\"comment_status\";i:3;s:11:\"ping_status\";i:4;s:12:\"sticky_posts\";i:5;s:9:\"post_date\";i:6;s:11:\"post_format\";i:7;s:11:\"post_parent\";i:8;s:17:\"_wp_page_template\";i:9;s:10:\"menu_order\";i:10;s:13:\"_thumbnail_id\";}s:10:\"post_types\";a:0:{}s:10:\"taxonomies\";a:1:{i:0;s:7:\"catalog\";}s:7:\"domains\";a:0:{}s:7:\"version\";s:5:\"2.3.4\";s:16:\"previous_version\";s:5:\"2.3.3\";s:12:\"default_lang\";s:2:\"uk\";s:9:\"nav_menus\";a:1:{s:8:\"Golubika\";a:5:{s:11:\"header_menu\";a:1:{s:2:\"en\";i:0;}s:11:\"footer_menu\";a:2:{s:2:\"en\";i:0;s:2:\"uk\";i:0;}s:3:\"top\";a:1:{s:2:\"uk\";i:0;}s:6:\"bottom\";a:1:{s:2:\"uk\";i:0;}s:4:\"menu\";a:1:{s:2:\"uk\";i:0;}}}}","yes");
INSERT INTO `gol_options` VALUES("164","polylang_wpml_strings","a:0:{}","yes");
INSERT INTO `gol_options` VALUES("165","widget_polylang","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("166","UPCP_Currency_Symbol_Location","Before","yes");
INSERT INTO `gol_options` VALUES("167","UPCP_Price_Filter","No","yes");
INSERT INTO `gol_options` VALUES("168","UPCP_Sale_Mode","Individual","yes");
INSERT INTO `gol_options` VALUES("169","UPCP_Product_Sort","a:2:{i:0;s:4:\"Name\";i:1;s:5:\"Price\";}","yes");
INSERT INTO `gol_options` VALUES("170","UPCP_Product_Search","name","yes");
INSERT INTO `gol_options` VALUES("171","UPCP_Custom_Product_Page","No","yes");
INSERT INTO `gol_options` VALUES("172","UPCP_Sidebar_Order","Normal","yes");
INSERT INTO `gol_options` VALUES("173","UPCP_Apply_Contents_Filter","Yes","yes");
INSERT INTO `gol_options` VALUES("174","UPCP_Maintain_Filtering","Yes","yes");
INSERT INTO `gol_options` VALUES("175","UPCP_Thumbnail_Support","No","yes");
INSERT INTO `gol_options` VALUES("176","UPCP_Show_Category_Descriptions","No","yes");
INSERT INTO `gol_options` VALUES("177","UPCP_Show_Catalogue_Information","None","yes");
INSERT INTO `gol_options` VALUES("178","UPCP_Display_Category_Image","No","yes");
INSERT INTO `gol_options` VALUES("179","UPCP_Display_SubCategory_Image","No","yes");
INSERT INTO `gol_options` VALUES("180","UPCP_Overview_Mode","None","yes");
INSERT INTO `gol_options` VALUES("181","UPCP_Inner_Filter","No","yes");
INSERT INTO `gol_options` VALUES("182","UPCP_Breadcrumbs","None","yes");
INSERT INTO `gol_options` VALUES("183","UPCP_Product_Comparison","No","yes");
INSERT INTO `gol_options` VALUES("184","UPCP_Product_Inquiry_Form","No","yes");
INSERT INTO `gol_options` VALUES("185","UPCP_Product_Inquiry_Cart","No","yes");
INSERT INTO `gol_options` VALUES("186","UPCP_Inquiry_Form_Email","0","yes");
INSERT INTO `gol_options` VALUES("187","UPCP_Product_Reviews","No","yes");
INSERT INTO `gol_options` VALUES("188","UPCP_Catalog_Display_Reviews","No","yes");
INSERT INTO `gol_options` VALUES("189","UPCP_Lightbox","No","yes");
INSERT INTO `gol_options` VALUES("190","UPCP_Lightbox_Mode","No","yes");
INSERT INTO `gol_options` VALUES("191","UPCP_Hidden_Drop_Down_Sidebar_On_Mobile","No","yes");
INSERT INTO `gol_options` VALUES("192","UPCP_Infinite_Scroll","No","yes");
INSERT INTO `gol_options` VALUES("193","UPCP_Products_Per_Page","1000000","yes");
INSERT INTO `gol_options` VALUES("194","UPCP_Pagination_Location","Top","yes");
INSERT INTO `gol_options` VALUES("195","UPCP_CF_Conversion","No","yes");
INSERT INTO `gol_options` VALUES("196","UPCP_Access_Role","administrator","yes");
INSERT INTO `gol_options` VALUES("197","UPCP_PP_Grid_Width","90","yes");
INSERT INTO `gol_options` VALUES("198","UPCP_PP_Grid_Height","35","yes");
INSERT INTO `gol_options` VALUES("199","UPCP_Top_Bottom_Padding","10","yes");
INSERT INTO `gol_options` VALUES("200","UPCP_Left_Right_Padding","10","yes");
INSERT INTO `gol_options` VALUES("201","UPCP_WooCommerce_Sync","No","yes");
INSERT INTO `gol_options` VALUES("202","UPCP_WooCommerce_Show_Cart_Count","No","yes");
INSERT INTO `gol_options` VALUES("203","UPCP_WooCommerce_Checkout","No","yes");
INSERT INTO `gol_options` VALUES("204","UPCP_WooCommerce_Cart_Page","Checkout","yes");
INSERT INTO `gol_options` VALUES("205","UPCP_WooCommerce_Product_Page","No","yes");
INSERT INTO `gol_options` VALUES("206","UPCP_WooCommerce_Back_Link","No","yes");
INSERT INTO `gol_options` VALUES("207","UPCP_SEO_Option","None","yes");
INSERT INTO `gol_options` VALUES("208","UPCP_SEO_Integration","Add","yes");
INSERT INTO `gol_options` VALUES("209","UPCP_SEO_Title","[page-title] | [product-name]","yes");
INSERT INTO `gol_options` VALUES("210","UPCP_Update_Breadcrumbs","No","yes");
INSERT INTO `gol_options` VALUES("211","UPCP_List_View_Click_Action","Expand","yes");
INSERT INTO `gol_options` VALUES("212","UPCP_Details_Icon_Type","Default","yes");
INSERT INTO `gol_options` VALUES("213","UPCP_Pagination_Background","None","yes");
INSERT INTO `gol_options` VALUES("214","UPCP_Pagination_Border","none","yes");
INSERT INTO `gol_options` VALUES("215","UPCP_Pagination_Shadow","shadow-none","yes");
INSERT INTO `gol_options` VALUES("216","UPCP_Pagination_Gradient","gradient-none","yes");
INSERT INTO `gol_options` VALUES("217","UPCP_Pagination_Font","none","yes");
INSERT INTO `gol_options` VALUES("218","UPCP_Sidebar_Title_Collapse","no","yes");
INSERT INTO `gol_options` VALUES("219","UPCP_Sidebar_Start_Collapsed","no","yes");
INSERT INTO `gol_options` VALUES("220","UPCP_Sidebar_Title_Hover","none","yes");
INSERT INTO `gol_options` VALUES("221","UPCP_Sidebar_Checkbox_Style","none","yes");
INSERT INTO `gol_options` VALUES("222","UPCP_Categories_Control_Type","Checkbox","yes");
INSERT INTO `gol_options` VALUES("223","UPCP_SubCategories_Control_Type","Checkbox","yes");
INSERT INTO `gol_options` VALUES("224","UPCP_Tags_Control_Type","Checkbox","yes");
INSERT INTO `gol_options` VALUES("225","UPCP_Installed_Skins","a:0:{}","yes");
INSERT INTO `gol_options` VALUES("227","UPCP_Full_Version","No","yes");
INSERT INTO `gol_options` VALUES("228","UPCP_Color_Scheme","Blue","yes");
INSERT INTO `gol_options` VALUES("229","UPCP_Product_Links","Same","yes");
INSERT INTO `gol_options` VALUES("230","UPCP_Tag_Logic","AND","yes");
INSERT INTO `gol_options` VALUES("231","UPCP_Read_More","Yes","yes");
INSERT INTO `gol_options` VALUES("232","UPCP_Pretty_Links","No","yes");
INSERT INTO `gol_options` VALUES("233","UPCP_Mobile_SS","No","yes");
INSERT INTO `gol_options` VALUES("234","UPCP_Install_Flag","No","yes");
INSERT INTO `gol_options` VALUES("235","UPCP_First_Install_Version","3.6","yes");
INSERT INTO `gol_options` VALUES("236","UPCP_Desc_Chars","240","yes");
INSERT INTO `gol_options` VALUES("237","UPCP_Case_Insensitive_Search","Yes","yes");
INSERT INTO `gol_options` VALUES("238","UPCP_Run_Tutorial","Yes","yes");
INSERT INTO `gol_options` VALUES("239","plugin_error","","yes");
INSERT INTO `gol_options` VALUES("240","UPCP_Product_Import","None","yes");
INSERT INTO `gol_options` VALUES("241","widget_upcp_product_list_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("242","widget_upcp_random_products_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("243","widget_upcp_recent_products_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("244","widget_upcp_popular_products_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("245","widget_upcp_search_bar_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("246","UPCP_Blog_Content","<h3>Filter WooCommerce Products by Attribute!</h3>
<p>Want visitors to easily search WooCommerce products by attributes, price, tags and more?</p>
<p><a target=\'_blank\' href=\'http://www.etoilewebdesign.com/product-catalog-woocommerce-sync-tips/\'>Read our tips on making your products filterable with the Ultimate Product Catalog plugin!</a></p>","yes");
INSERT INTO `gol_options` VALUES("247","UPCP_Dash_Cache","1517753705","yes");
INSERT INTO `gol_options` VALUES("248","UPCP_Hide_Dash_Review_Ask","No","yes");
INSERT INTO `gol_options` VALUES("249","UPCP_Changelog_Content","
<h3>4.3.3</h3>
<br />- New product page style (Shop Style)
<br />- New sidebar style (Contemporary)
<br />- Removed references to JS and CSS files that are no longer used and that were appearing in the console

<h3>4.3.2</h3>
<br />- Added in an option to delete many items from a catalog at once
<br />- Fixed an error where YouTube videos wouldn\'t play correctly for https sites

","yes");
INSERT INTO `gol_options` VALUES("250","UPCP_Update_Flag","No","yes");
INSERT INTO `gol_options` VALUES("253","current_theme","Golubika Theme","yes");
INSERT INTO `gol_options` VALUES("254","theme_mods_Golubika","a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:5:{s:11:\"header_menu\";i:0;s:11:\"footer_menu\";i:0;s:3:\"top\";i:0;s:6:\"bottom\";i:0;s:4:\"menu\";i:0;}s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `gol_options` VALUES("255","theme_switched","","yes");
INSERT INTO `gol_options` VALUES("301","new_admin_email","serg.didyk@gmail.com","yes");
INSERT INTO `gol_options` VALUES("354","dismissed_update_core","a:0:{}","no");
INSERT INTO `gol_options` VALUES("388","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:20:\"serg.didyk@gmail.com\";s:7:\"version\";s:5:\"4.9.5\";s:9:\"timestamp\";i:1523869742;}","no");
INSERT INTO `gol_options` VALUES("448","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `gol_options` VALUES("596","current_theme_supports_woocommerce","no","yes");
INSERT INTO `gol_options` VALUES("598","_transient_wc_attribute_taxonomies","a:0:{}","yes");
INSERT INTO `gol_options` VALUES("599","product_cat_children","a:0:{}","yes");
INSERT INTO `gol_options` VALUES("600","default_product_cat","39","yes");
INSERT INTO `gol_options` VALUES("606","_transient_woocommerce_webhook_ids","a:0:{}","yes");
INSERT INTO `gol_options` VALUES("607","widget_woocommerce_widget_cart","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("608","widget_woocommerce_layered_nav_filters","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("609","widget_woocommerce_layered_nav","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("610","widget_woocommerce_price_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("611","widget_woocommerce_product_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("612","widget_woocommerce_product_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("613","widget_woocommerce_product_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("614","widget_woocommerce_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("615","widget_woocommerce_recently_viewed_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("616","widget_woocommerce_top_rated_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("617","widget_woocommerce_recent_reviews","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("618","widget_woocommerce_rating_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("620","_transient_wc_count_comments","O:8:\"stdClass\":7:{s:14:\"total_comments\";i:0;s:3:\"all\";i:0;s:9:\"moderated\";i:0;s:8:\"approved\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}","yes");
INSERT INTO `gol_options` VALUES("645","aiowpsec_db_version","1.9","yes");
INSERT INTO `gol_options` VALUES("646","aio_wp_security_configs","a:87:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:1:\"1\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:60;s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:20:\"serg.didyk@gmail.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"jqtp00bn0v8tohd6jk46\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"y9t13745ja38h0dirf5q\";s:42:\"aiowps_enable_manual_registration_approval\";s:1:\"1\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:2;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:1;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:31:\"aiowps_enable_pingback_firewall\";s:1:\"1\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:1:\"1\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:1:\"1\";s:30:\"aiowps_disable_trace_and_track\";s:1:\"1\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:1:\"1\";s:34:\"aiowps_advanced_char_string_filter\";s:1:\"1\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:1:\"1\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:1:\"1\";s:32:\"aiowps_prevent_users_enumeration\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2018-04-16 12:07:46\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";}","yes");
INSERT INTO `gol_options` VALUES("896","theme_mods_twentyfifteen","a:1:{s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `gol_options` VALUES("898","_transient_twentyfifteen_categories","1","yes");
INSERT INTO `gol_options` VALUES("964","platform_children","a:0:{}","yes");
INSERT INTO `gol_options` VALUES("969","rewrite_rules","a:167:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:52:\"(en)/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?lang=$matches[1]&category_name=$matches[2]&feed=$matches[3]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:47:\"(en)/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?lang=$matches[1]&category_name=$matches[2]&feed=$matches[3]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:28:\"(en)/category/(.+?)/embed/?$\";s:63:\"index.php?lang=$matches[1]&category_name=$matches[2]&embed=true\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:40:\"(en)/category/(.+?)/page/?([0-9]{1,})/?$\";s:70:\"index.php?lang=$matches[1]&category_name=$matches[2]&paged=$matches[3]\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:22:\"(en)/category/(.+?)/?$\";s:52:\"index.php?lang=$matches[1]&category_name=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:49:\"(en)/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?lang=$matches[1]&tag=$matches[2]&feed=$matches[3]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:44:\"(en)/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?lang=$matches[1]&tag=$matches[2]&feed=$matches[3]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:25:\"(en)/tag/([^/]+)/embed/?$\";s:53:\"index.php?lang=$matches[1]&tag=$matches[2]&embed=true\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:37:\"(en)/tag/([^/]+)/page/?([0-9]{1,})/?$\";s:60:\"index.php?lang=$matches[1]&tag=$matches[2]&paged=$matches[3]\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:19:\"(en)/tag/([^/]+)/?$\";s:42:\"index.php?lang=$matches[1]&tag=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:50:\"(en)/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:67:\"index.php?lang=$matches[1]&post_format=$matches[2]&feed=$matches[3]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:58:\"index.php?lang=uk&post_format=$matches[1]&feed=$matches[2]\";s:45:\"(en)/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:67:\"index.php?lang=$matches[1]&post_format=$matches[2]&feed=$matches[3]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:58:\"index.php?lang=uk&post_format=$matches[1]&feed=$matches[2]\";s:26:\"(en)/type/([^/]+)/embed/?$\";s:61:\"index.php?lang=$matches[1]&post_format=$matches[2]&embed=true\";s:21:\"type/([^/]+)/embed/?$\";s:52:\"index.php?lang=uk&post_format=$matches[1]&embed=true\";s:38:\"(en)/type/([^/]+)/page/?([0-9]{1,})/?$\";s:68:\"index.php?lang=$matches[1]&post_format=$matches[2]&paged=$matches[3]\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:59:\"index.php?lang=uk&post_format=$matches[1]&paged=$matches[2]\";s:20:\"(en)/type/([^/]+)/?$\";s:50:\"index.php?lang=$matches[1]&post_format=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:41:\"index.php?lang=uk&post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:37:\"(en)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?lang=$matches[1]&&feed=$matches[2]\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:35:\"index.php?lang=uk&&feed=$matches[1]\";s:32:\"(en)/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?lang=$matches[1]&&feed=$matches[2]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:35:\"index.php?lang=uk&&feed=$matches[1]\";s:13:\"(en)/embed/?$\";s:38:\"index.php?lang=$matches[1]&&embed=true\";s:8:\"embed/?$\";s:29:\"index.php?lang=uk&&embed=true\";s:25:\"(en)/page/?([0-9]{1,})/?$\";s:45:\"index.php?lang=$matches[1]&&paged=$matches[2]\";s:20:\"page/?([0-9]{1,})/?$\";s:36:\"index.php?lang=uk&&paged=$matches[1]\";s:7:\"(en)/?$\";s:26:\"index.php?lang=$matches[1]\";s:46:\"(en)/comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?lang=$matches[1]&&feed=$matches[2]&withcomments=1\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?lang=uk&&feed=$matches[1]&withcomments=1\";s:41:\"(en)/comments/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?lang=$matches[1]&&feed=$matches[2]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?lang=uk&&feed=$matches[1]&withcomments=1\";s:22:\"(en)/comments/embed/?$\";s:38:\"index.php?lang=$matches[1]&&embed=true\";s:17:\"comments/embed/?$\";s:29:\"index.php?lang=uk&&embed=true\";s:49:\"(en)/search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?lang=$matches[1]&s=$matches[2]&feed=$matches[3]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?lang=uk&s=$matches[1]&feed=$matches[2]\";s:44:\"(en)/search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?lang=$matches[1]&s=$matches[2]&feed=$matches[3]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?lang=uk&s=$matches[1]&feed=$matches[2]\";s:25:\"(en)/search/(.+)/embed/?$\";s:51:\"index.php?lang=$matches[1]&s=$matches[2]&embed=true\";s:20:\"search/(.+)/embed/?$\";s:42:\"index.php?lang=uk&s=$matches[1]&embed=true\";s:37:\"(en)/search/(.+)/page/?([0-9]{1,})/?$\";s:58:\"index.php?lang=$matches[1]&s=$matches[2]&paged=$matches[3]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:49:\"index.php?lang=uk&s=$matches[1]&paged=$matches[2]\";s:19:\"(en)/search/(.+)/?$\";s:40:\"index.php?lang=$matches[1]&s=$matches[2]\";s:14:\"search/(.+)/?$\";s:31:\"index.php?lang=uk&s=$matches[1]\";s:52:\"(en)/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:67:\"index.php?lang=$matches[1]&author_name=$matches[2]&feed=$matches[3]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:58:\"index.php?lang=uk&author_name=$matches[1]&feed=$matches[2]\";s:47:\"(en)/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:67:\"index.php?lang=$matches[1]&author_name=$matches[2]&feed=$matches[3]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:58:\"index.php?lang=uk&author_name=$matches[1]&feed=$matches[2]\";s:28:\"(en)/author/([^/]+)/embed/?$\";s:61:\"index.php?lang=$matches[1]&author_name=$matches[2]&embed=true\";s:23:\"author/([^/]+)/embed/?$\";s:52:\"index.php?lang=uk&author_name=$matches[1]&embed=true\";s:40:\"(en)/author/([^/]+)/page/?([0-9]{1,})/?$\";s:68:\"index.php?lang=$matches[1]&author_name=$matches[2]&paged=$matches[3]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:59:\"index.php?lang=uk&author_name=$matches[1]&paged=$matches[2]\";s:22:\"(en)/author/([^/]+)/?$\";s:50:\"index.php?lang=$matches[1]&author_name=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:41:\"index.php?lang=uk&author_name=$matches[1]\";s:74:\"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&feed=$matches[5]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:88:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:69:\"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&feed=$matches[5]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:88:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:50:\"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:91:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&embed=true\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:82:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:62:\"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:98:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&paged=$matches[5]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:89:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:44:\"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:80:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:71:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:61:\"(en)/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:81:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&feed=$matches[4]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:72:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:56:\"(en)/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:81:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&feed=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:72:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:37:\"(en)/([0-9]{4})/([0-9]{1,2})/embed/?$\";s:75:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&embed=true\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:66:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&embed=true\";s:49:\"(en)/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:82:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&paged=$matches[4]\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:73:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:31:\"(en)/([0-9]{4})/([0-9]{1,2})/?$\";s:64:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:55:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]\";s:48:\"(en)/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:60:\"index.php?lang=$matches[1]&year=$matches[2]&feed=$matches[3]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?lang=uk&year=$matches[1]&feed=$matches[2]\";s:43:\"(en)/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:60:\"index.php?lang=$matches[1]&year=$matches[2]&feed=$matches[3]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?lang=uk&year=$matches[1]&feed=$matches[2]\";s:24:\"(en)/([0-9]{4})/embed/?$\";s:54:\"index.php?lang=$matches[1]&year=$matches[2]&embed=true\";s:19:\"([0-9]{4})/embed/?$\";s:45:\"index.php?lang=uk&year=$matches[1]&embed=true\";s:36:\"(en)/([0-9]{4})/page/?([0-9]{1,})/?$\";s:61:\"index.php?lang=$matches[1]&year=$matches[2]&paged=$matches[3]\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:52:\"index.php?lang=uk&year=$matches[1]&paged=$matches[2]\";s:18:\"(en)/([0-9]{4})/?$\";s:43:\"index.php?lang=$matches[1]&year=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:34:\"index.php?lang=uk&year=$matches[1]\";s:32:\"(en)/.?.+?/attachment/([^/]+)/?$\";s:49:\"index.php?lang=$matches[1]&attachment=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"(en)/.?.+?/attachment/([^/]+)/trackback/?$\";s:54:\"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"(en)/.?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"(en)/.?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"(en)/.?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:67:\"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"(en)/.?.+?/attachment/([^/]+)/embed/?$\";s:60:\"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"(en)/(.?.+?)/embed/?$\";s:58:\"index.php?lang=$matches[1]&pagename=$matches[2]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:25:\"(en)/(.?.+?)/trackback/?$\";s:52:\"index.php?lang=$matches[1]&pagename=$matches[2]&tb=1\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:45:\"(en)/(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?lang=$matches[1]&pagename=$matches[2]&feed=$matches[3]\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:40:\"(en)/(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?lang=$matches[1]&pagename=$matches[2]&feed=$matches[3]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:33:\"(en)/(.?.+?)/page/?([0-9]{1,})/?$\";s:65:\"index.php?lang=$matches[1]&pagename=$matches[2]&paged=$matches[3]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:40:\"(en)/(.?.+?)/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?lang=$matches[1]&pagename=$matches[2]&cpage=$matches[3]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:29:\"(en)/(.?.+?)(?:/([0-9]+))?/?$\";s:64:\"index.php?lang=$matches[1]&pagename=$matches[2]&page=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:32:\"(en)/[^/]+/attachment/([^/]+)/?$\";s:49:\"index.php?lang=$matches[1]&attachment=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"(en)/[^/]+/attachment/([^/]+)/trackback/?$\";s:54:\"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"(en)/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"(en)/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"(en)/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:67:\"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"(en)/[^/]+/attachment/([^/]+)/embed/?$\";s:60:\"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"(en)/([^/]+)/embed/?$\";s:54:\"index.php?lang=$matches[1]&name=$matches[2]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:25:\"(en)/([^/]+)/trackback/?$\";s:48:\"index.php?lang=$matches[1]&name=$matches[2]&tb=1\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:45:\"(en)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:60:\"index.php?lang=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:40:\"(en)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:60:\"index.php?lang=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:33:\"(en)/([^/]+)/page/?([0-9]{1,})/?$\";s:61:\"index.php?lang=$matches[1]&name=$matches[2]&paged=$matches[3]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:40:\"(en)/([^/]+)/comment-page-([0-9]{1,})/?$\";s:61:\"index.php?lang=$matches[1]&name=$matches[2]&cpage=$matches[3]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:29:\"(en)/([^/]+)(?:/([0-9]+))?/?$\";s:60:\"index.php?lang=$matches[1]&name=$matches[2]&page=$matches[3]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:21:\"(en)/[^/]+/([^/]+)/?$\";s:49:\"index.php?lang=$matches[1]&attachment=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\"(en)/[^/]+/([^/]+)/trackback/?$\";s:54:\"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\"(en)/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"(en)/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"(en)/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:67:\"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"(en)/[^/]+/([^/]+)/embed/?$\";s:60:\"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `gol_options` VALUES("1063","catalog_children","a:0:{}","yes");
INSERT INTO `gol_options` VALUES("1954","category_children","a:3:{i:129;a:6:{i:0;i:4;i:1;i:73;i:2;i:80;i:3;i:85;i:4;i:101;i:5;i:107;}i:85;a:2:{i:0;i:89;i:1;i:93;}i:87;a:2:{i:0;i:91;i:1;i:95;}}","yes");
INSERT INTO `gol_options` VALUES("2067","_crb_phone","+38 097 227 93 43","no");
INSERT INTO `gol_options` VALUES("2068","_crb_email","golubika.forbeloved@gmail.com","no");
INSERT INTO `gol_options` VALUES("2280","cpto_options","a:7:{s:23:\"show_reorder_interfaces\";a:2:{s:4:\"post\";s:4:\"show\";s:10:\"attachment\";s:4:\"hide\";}s:8:\"autosort\";i:1;s:9:\"adminsort\";i:1;s:18:\"use_query_ASC_DESC\";s:0:\"\";s:17:\"archive_drag_drop\";i:1;s:10:\"capability\";s:14:\"manage_options\";s:21:\"navigation_sort_apply\";i:1;}","yes");
INSERT INTO `gol_options` VALUES("2281","CPT_configured","TRUE","yes");
INSERT INTO `gol_options` VALUES("2305","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-4.9.5.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-4.9.5.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.5\";s:7:\"version\";s:5:\"4.9.5\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1524044963;s:15:\"version_checked\";s:5:\"4.9.5\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `gol_options` VALUES("2306","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1524044965;s:7:\"checked\";a:1:{s:8:\"Golubika\";s:3:\"1.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `gol_options` VALUES("2307","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1524044965;s:7:\"checked\";a:3:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.3.2\";s:22:\"cyr3lat/cyr-to-lat.php\";s:3:\"3.5\";s:21:\"polylang/polylang.php\";s:5:\"2.3.4\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:3:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.3.2\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1232826\";}s:11:\"banners_rtl\";a:0:{}}s:22:\"cyr3lat/cyr-to-lat.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/cyr3lat\";s:4:\"slug\";s:7:\"cyr3lat\";s:6:\"plugin\";s:22:\"cyr3lat/cyr-to-lat.php\";s:11:\"new_version\";s:3:\"3.5\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/cyr3lat/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/cyr3lat.3.5.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:51:\"https://s.w.org/plugins/geopattern-icon/cyr3lat.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:21:\"polylang/polylang.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/polylang\";s:4:\"slug\";s:8:\"polylang\";s:6:\"plugin\";s:21:\"polylang/polylang.php\";s:11:\"new_version\";s:5:\"2.3.4\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/polylang/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/polylang.2.3.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/polylang/assets/icon-256x256.png?rev=1331499\";s:2:\"1x\";s:61:\"https://ps.w.org/polylang/assets/icon-128x128.png?rev=1331499\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/polylang/assets/banner-1544x500.png?rev=1405299\";s:2:\"1x\";s:63:\"https://ps.w.org/polylang/assets/banner-772x250.png?rev=1405299\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `gol_options` VALUES("2316","_site_transient_timeout_browser_efc56fe28520bcd166ef136f44025003","1524505211","no");
INSERT INTO `gol_options` VALUES("2317","_site_transient_browser_efc56fe28520bcd166ef136f44025003","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"65.0.3325.181\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `gol_options` VALUES("2337","_site_transient_timeout_browser_4d90fb766c3b51de57fa42e860c03217","1524572869","no");
INSERT INTO `gol_options` VALUES("2338","_site_transient_browser_4d90fb766c3b51de57fa42e860c03217","a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"60.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:24:\"https://www.firefox.com/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `gol_options` VALUES("2358","_site_transient_timeout_theme_roots","1524046764","no");
INSERT INTO `gol_options` VALUES("2359","_site_transient_theme_roots","a:1:{s:8:\"Golubika\";s:7:\"/themes\";}","no");
INSERT INTO `gol_options` VALUES("2363","_transient_timeout_users_online","1524071257","no");
INSERT INTO `gol_options` VALUES("2364","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:3;s:13:\"last_activity\";d:1524080257;s:10:\"ip_address\";s:9:\"127.0.0.1\";}}","no");
INSERT INTO `gol_options` VALUES("2365","_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e","1524111726","no");
INSERT INTO `gol_options` VALUES("2366","_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e","a:2:{s:8:\"location\";a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}s:6:\"events\";a:0:{}}","no");
INSERT INTO `gol_options` VALUES("2367","_transient_timeout_feed_126d1ca39d75da07beec8b892738427b","1524107444","no");
INSERT INTO `gol_options` VALUES("2368","_transient_feed_126d1ca39d75da07beec8b892738427b","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Блог — Русский\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://ru.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Русский\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"
	Thu, 29 Mar 2018 03:03:39 +0000	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"ru-RU\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.0-alpha-42985\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"Выпуск WordPress 4.9.4 (требуется ручное обновление)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"https://ru.wordpress.org/news/2018/02/%d0%b2%d1%8b%d0%bf%d1%83%d1%81%d0%ba-wordpress-4-9-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 06 Feb 2018 16:46:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:22:\"Исправления\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:12:\"Релизы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1886\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:661:\"Доступна версия WordPress 4.9.4, исправляющая внесенную в выпуске 4.9.3 ошибку с автообновлением. Если вы успели (возможно автоматически) обновить свой сайт (или сайты) до 4.9.3, то вам нужно обновить WordPress  до версии 4.9.4, используя кнопку в Консоль &#62; Обновления, либо иным удобным вам способом (wp-cli, через ftp или ssh). Скачать архив дистрибутива можно здесь. Детали ошибки [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:905:\"<p>Доступна версия WordPress 4.9.4, исправляющая внесенную в выпуске 4.9.3 ошибку с автообновлением. Если вы успели (возможно автоматически) обновить свой сайт (или сайты) до 4.9.3, то вам нужно обновить WordPress  до версии 4.9.4, используя кнопку в <em>Консоль &gt; Обновления, </em>либо иным удобным вам способом (wp-cli, через ftp или ssh). Скачать архив дистрибутива можно <a href=\"https://ru.wordpress.org/releases/\">здесь</a>.</p>
<p>Детали ошибки <a href=\"https://make.wordpress.org/core/2018/02/06/wordpress-4-9-4-release-the-technical-details/\" target=\"_blank\" rel=\"noopener\">доступны</a> в блоге Make WordPress.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"Всемирный день перевода WordPress 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://ru.wordpress.org/news/2017/09/wp-translation-day-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 Sep 2017 18:55:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1841\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:655:\"Всемирный день перевода — это мероприятие, которое проходит по всему миру в один день в формате вебинаров или митапов, когда каждый может принять участие в переводе плагинов, тем, документации и ядра WordPress на свой родной язык. Быть разработчиком для этого совсем не обязательно, участвовать может любой желающий. Если вы давно хотели внести свой вклад в [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4393:\"<p><a href=\"https://wptranslationday.org/\">Всемирный день перевода</a> — это мероприятие, которое проходит по всему миру в один день в формате вебинаров или митапов, когда каждый может принять участие в переводе плагинов, тем, документации и ядра WordPress на свой родной язык.</p>
<p><a href=\"https://wptranslationday.org/\"><img class=\"alignnone wp-image-1842 size-full\" src=\"https://ru.wordpress.org/files/2017/09/4by3.jpg\" alt=\"\" width=\"1024\" height=\"768\" srcset=\"https://ru.wordpress.org/files/2017/09/4by3.jpg 1024w, https://ru.wordpress.org/files/2017/09/4by3-300x225.jpg 300w, https://ru.wordpress.org/files/2017/09/4by3-768x576.jpg 768w, https://ru.wordpress.org/files/2017/09/4by3-440x330.jpg 440w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /></a></p>
<p>Быть разработчиком для этого совсем не обязательно, участвовать может любой желающий. Если вы давно хотели внести свой вклад в развитие WordPress — сейчас самое время!</p>
<p>В России в рамках мероприятия планируется встреча в Ростове-на-Дону, а также вебинар для тех, кто будет переводить у себя дома.</p>
<p><strong>Когда</strong></p>
<p>День перевода WordPress пройдёт в субботу, 30 сентября.</p>
<p><strong>Где</strong></p>
<ul>
<li>Ростов-на-Дону: ул. Большая Садовая, д. 81/31 (кафе Starbucks). Начало в 12:00.</li>
<li>Вебинар: <a href=\"https://www.crowdcast.io/e/gwtd3/22\">https://www.crowdcast.io/e/gwtd3/22</a>, начало в 20:00 по московскому времени. Вы узнаете, как переводить WordPress, плагины и темы на русский язык, сможете выбрать проект и приступить к переводу.</li>
</ul>
<p>Расписание всех вебинаров мероприятия: <a href=\"https://wptranslationday.org/#primary\">https://wptranslationday.org/#primary</a>.</p>
<p><strong>Полезные ресурсы</strong></p>
<ul>
<li><a href=\"https://ru.wordpress.org/support/topic/%D0%BA%D0%B0%D0%BA-%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%B5%D1%81%D1%82%D0%B8-%D1%82%D0%B5%D0%BC%D1%83-%D0%B8%D0%BB%D0%B8-%D0%BF%D0%BB%D0%B0%D0%B3%D0%B8%D0%BD/\">Как перевести тему или плагин?</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.A1.D1.82.D0.B8.D0.BB.D1.8C_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.D0.B0\">Рекомендации по стилю перевода</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.9A.D0.B0.D0.BA_.D1.81.D0.B4.D0.B5.D0.BB.D0.B0.D1.82.D1.8C_.D1.85.D0.BE.D1.80.D0.BE.D1.88.D0.B8.D0.B9_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.3F\">Как сделать хороший перевод</a></li>
<li><a href=\"https://translate.wordpress.org/locale/ru/default/glossary\">Словарь терминов</a></li>
<li><a href=\"https://make.wordpress.org/polyglots/handbook/about/get-involved/first-steps/\">Первые шаги переводчика</a></li>
<li><a href=\"https://make.wordpress.org/polyglots/handbook/tools/glotpress-translate-wordpress-org/\">Как работать с сайтом translate.wordpress.org (GlotPress)</a></li>
</ul>
<p>Для координации и обсуждения вопросов стоит зарегистрироваться в <a href=\"https://ruwp.slack.com/\">Slack-группе русскоязычного сообщества WordPress</a> и зайти на канал <code>#translations</code>. При регистрации введите адрес вида <code>username@chat.wordpress.org</code> (он же используется и в <a href=\"https://make.wordpress.org/chat/\">английском Slack</a>), где <code>username</code> — ваш логин на WordPress.org.</p>
<p>Да пребудут с нами понятные интерфейсы и качественная локализация!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"Всемирный день перевода WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ru.wordpress.org/news/2016/11/wp-translation-day/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 09 Nov 2016 16:35:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1751\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:655:\"Всемирный день перевода — это мероприятие, которое проходит по всему миру в один день в формате вебинаров или митапов, когда каждый может принять участие в переводе плагинов, тем, документации и ядра WordPress на свой родной язык. Быть разработчиком для этого совсем не обязательно, участвовать может любой желающий. Если вы давно хотели внести свой вклад в [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Sergey Biryukov\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4653:\"<p><a href=\"https://wptranslationday.org/\">Всемирный день перевода</a> — это мероприятие, которое проходит по всему миру в один день в формате вебинаров или митапов, когда каждый может принять участие в переводе плагинов, тем, документации и ядра WordPress на свой родной язык.</p>
<p><img class=\"alignnone wp-image-1764 size-large\" src=\"https://ru.wordpress.org/files/2016/11/global-wordpress-translation-day-2-1024x579.jpg\" width=\"692\" height=\"391\" srcset=\"https://ru.wordpress.org/files/2016/11/global-wordpress-translation-day-2-1024x579.jpg 1024w, https://ru.wordpress.org/files/2016/11/global-wordpress-translation-day-2-300x170.jpg 300w, https://ru.wordpress.org/files/2016/11/global-wordpress-translation-day-2-768x434.jpg 768w, https://ru.wordpress.org/files/2016/11/global-wordpress-translation-day-2.jpg 1200w\" sizes=\"(max-width: 692px) 100vw, 692px\" /></p>
<p>Быть разработчиком для этого совсем не обязательно, участвовать может любой желающий. Если вы давно хотели внести свой вклад в развитие WordPress — сейчас самое время!</p>
<p>В России в рамках мероприятия планируются встречи в Москве и Ростове-на-Дону, а также вебинар для тех, кто будет переводить у себя дома.</p>
<p><strong>Когда</strong></p>
<p>День перевода WordPress пройдёт в субботу, 12 ноября.</p>
<p><strong>Где</strong></p>
<ul>
<li><a href=\"https://wpmag.ru/2016/global-translation-day-moscow/\">Москва</a>: метро Краснопресненская, БЦ «Трехгорная мануфактура», ул. Рочдельская, д. 15 стр. 10, 2 этаж (офис компании Setka). Начало в 12:00.</li>
<li>Ростов-на-Дону: ул. Большая Садовая, д. 81/31 (кафе Starbucks). Начало в 12:00.</li>
<li>Вебинар: <a href=\"https://www.crowdcast.io/e/gwtd2/14\">https://www.crowdcast.io/e/gwtd2/14</a>, начало в 16:00 по московскому времени. Вы узнаете, как переводить WordPress, плагины и темы на русский язык, сможете выбрать проект и приступить к переводу.</li>
</ul>
<p>Расписание всех вебинаров мероприятия: <a href=\"https://wptranslationday.org/#schedule\">https://wptranslationday.org/#schedule</a>.</p>
<p><strong>Полезные ресурсы</strong></p>
<ul>
<li><a href=\"https://make.wordpress.org/polyglots/handbook/about/get-involved/first-steps/\">Первые шаги переводчика</a></li>
<li><a href=\"https://make.wordpress.org/polyglots/handbook/tools/glotpress-translate-wordpress-org/\">Как работать с сайтом translate.wordpress.org (GlotPress)</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.A1.D1.82.D0.B8.D0.BB.D1.8C_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.D0.B0\">Рекомендации по стилю перевода</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.9A.D0.B0.D0.BA_.D1.81.D0.B4.D0.B5.D0.BB.D0.B0.D1.82.D1.8C_.D1.85.D0.BE.D1.80.D0.BE.D1.88.D0.B8.D0.B9_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.3F\">Как сделать хороший перевод</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.A1.D0.BB.D0.BE.D0.B2.D0.B0.D1.80.D1.8C_.D1.82.D0.B5.D1.80.D0.BC.D0.B8.D0.BD.D0.BE.D0.B2\">Словарь терминов</a></li>
</ul>
<p>Для координации и обсуждения вопросов стоит зарегистрироваться в <a href=\"https://ruwp.slack.com/\">Slack-группе русскоязычного сообщества WordPress</a> и зайти на канал <code>#translations</code>. При регистрации введите адрес вида <code>username@chat.wordpress.org</code> (он же используется и в <a href=\"https://make.wordpress.org/chat/\">английском Slack</a>), где <code>username</code> — ваш логин на WordPress.org.</p>
<p>Да пребудут с нами понятные интерфейсы и качественная локализация!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"Конференция WordCamp Moscow 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://ru.wordpress.org/news/2016/07/wordcamp-moscow-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 26 Jul 2016 14:00:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1722\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:345:\"13 августа в Москве пройдёт конференция WordCamp Moscow 2016 в центре Digital October. Гостей ждет целый день лекций на интересные темы связанные с разработкой, дизайном, предпринимательством и блоггингом.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2961:\"<p>13 августа в Москве пройдёт конференция WordCamp Moscow 2016 в центре Digital October. Гостей ждет целый день лекций на интересные темы связанные с разработкой, дизайном, предпринимательством и блоггингом.</p>
<p><img src=\"https://ru.wordpress.org/files/2016/07/wordcamp-russia-2015-nikolay-1024x684.jpg\" alt=\"Николай Миронов на WordCamp Russia 2015\" width=\"692\" height=\"462\" class=\"alignnone size-large wp-image-1724\" srcset=\"https://ru.wordpress.org/files/2016/07/wordcamp-russia-2015-nikolay-1024x684.jpg 1024w, https://ru.wordpress.org/files/2016/07/wordcamp-russia-2015-nikolay-300x200.jpg 300w, https://ru.wordpress.org/files/2016/07/wordcamp-russia-2015-nikolay-768x513.jpg 768w\" sizes=\"(max-width: 692px) 100vw, 692px\" /></p>
<p>Cписок докладов находится на стадии утверждения, но некоторые темы уже определены:</p>
<ul>
<li>Как заказать разработку сайта у специалиста и остаться довольным</li>
<li>Как работает искусственный интеллект в поисковых системах</li>
<li>Откуда брать идеи для написания постов, плагинов и тем</li>
<li>Как опубликовать свою тему в директорию на WordPress.org</li>
<li>Чем может быть полезен стек Elasticsearch, Logstash и Kibana</li>
<li>Как держать потребление памяти в WordPress под контролем</li>
<li>Что такое A/B тестирование и как его проводить в WordPress</li>
<li>и многое другое</li>
</ul>
<p>В перерывах между докладами можно будет пообщаться с коллегами, задать вопросы опытным специалистам и поделиться своими идеями.</p>
<p>Приобрести билет можно на <a href=\"https://2016.moscow.wordcamp.org/tickets/\">сайте конференции</a> кредитной или дебетовой картой через PayPal, или при помощи системы Яндекс.Деньги.</p>
<p>После мероприятия всех ждёт afterparty, где участники смогут пообщаться в местном баре в неформальной обстановке. Ну и, конечно же, каждый из гостей получит футболку с символикой WordPress и унесет с собой столько наклеек и значков, сколько влезет в карманы.</p>
<p><a href=\"https://2016.moscow.wordcamp.org/tickets/\">Зарегистрироваться</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"Конференция WordCamp Russia 2015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://ru.wordpress.org/news/2015/07/wordcamp-russia-2015/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2015 10:08:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1660\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:282:\"Конференция WordCamp Russia 2015 пройдет в субботу, 15 августа в центре Digital October в Москве. Это третья официальная конференция посвященная самой популярной в мире CMS.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2883:\"<p>Конференция <a href=\"https://russia.wordcamp.org/2015/\">WordCamp Russia 2015</a> пройдет в субботу, 15 августа в центре Digital October в Москве. Это третья официальная конференция посвященная самой популярной в мире CMS.</p>
<p><img src=\"https://ru.wordpress.org/files/2015/07/wordcamp-russia-2-1024x683.jpg\" alt=\"WordCamp Russia\" width=\"692\" height=\"462\" class=\"alignnone size-large wp-image-1662\" srcset=\"https://ru.wordpress.org/files/2015/07/wordcamp-russia-2-1024x683.jpg 1024w, https://ru.wordpress.org/files/2015/07/wordcamp-russia-2-300x200.jpg 300w, https://ru.wordpress.org/files/2015/07/wordcamp-russia-2.jpg 1200w\" sizes=\"(max-width: 692px) 100vw, 692px\" /></p>
<p>В этом году на WordCamp вы сможете послушать интересные доклады от ведущих специалистов по WordPress в России, познакомиться с единомышленниками и поделиться своими идеями. Доклады разделены на два потока для пользователей и разработчиков WordPress, и охватывают дизайн, маркетинг, программирование, безопасность, производительность и поисковую оптимизацию.</p>
<h2>Программа</h2>
<p>На WordCamp Russia 2015 вы узнаете:</p>
<ul>
<li>Как создавать эффективные лендинги с помощью WordPress</li>
<li>Что такое поведенческие факторы и как они измеряются</li>
<li>Как создавать многоязычные сайты на WordPress</li>
<li>Самые распространенные причины медленных сайтов на WordPress</li>
<li>Как взламываются сайты на WordPress (на практике)</li>
<li>Что такое фильтры и события в WordPress</li>
<li>Чего ожидать от REST API в WordPress и как с ним работать</li>
<li>Почему следует участвовать в разработке ядра WordPress</li>
<li><a href=\"https://russia.wordcamp.org/2015/schedule/\">и многое другое</a></li>
</ul>
<p>Стоимость билета – $20. Сюда входит участие в конференции, обед и напитки, футболка с символикой мероприятия, значки, наклейки, подарки от спонсоров и целый день хорошего настроения.</p>
<p>Подробности и регистрация <a href=\"https://russia.wordcamp.org/2015/\">на сайте конференции &rarr;</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"WordPress 4.2.1 на русском\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://ru.wordpress.org/news/2015/04/wordpress-4-2-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Apr 2015 16:54:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Релизы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1636\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:766:\"Доступен WordPress 4.2.1. Это критическое обновление безопасности для всех предыдущих версий, и мы настоятельно рекомендуем вам обновить все свои сайты как можно скорее. Несколько часов назад команде WordPress стало известно об уязвимости межсайтового скриптинга, которая позволяла авторам комментариев получить доступ к сайту. Уязвимость обнаружил Йоуко Пиннонен. WordPress 4.2.1 уже устанавливается в фоновом режиме на сайты, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Sergey Biryukov\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1558:\"<p>Доступен WordPress 4.2.1. Это <strong>критическое обновление безопасности</strong> для всех предыдущих версий, и мы настоятельно рекомендуем вам обновить все свои сайты как можно скорее.</p>
<p>Несколько часов назад команде WordPress стало известно об уязвимости межсайтового скриптинга, которая позволяла авторам комментариев получить доступ к сайту. Уязвимость обнаружил <a href=\"http://klikki.fi/\">Йоуко Пиннонен</a>.</p>
<p>WordPress 4.2.1 уже устанавливается в фоновом режиме на сайты, которые <a href=\"http://https://wordpress.org/plugins/background-update-tester/\">поддерживают</a> автоматические фоновые обновления.</p>
<p>Дополнительную информацию можно найти в <a href=\"https://codex.wordpress.org/Version_4.2.1\">заметке о релизе</a> или в <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=32311&amp;stop_rev=32300\">списке изменений</a>.</p>
<p><a href=\"https://ru.wordpress.org/releases/\">Скачайте версию 4.2.1</a> или перейдите в меню «Консоль» → «Обновления» и нажмите кнопку «Обновить сейчас».</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"Конференция WordCamp Russia 2014\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://ru.wordpress.org/news/2014/07/wordcamp-russia-2014/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 03 Jul 2014 09:37:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://ru.wordpress.org/?p=1588\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:356:\"Конференция WordCamp Russia 2014 пройдет 9 августа в Москве. На мероприятии вы сможете пообщаться с профессионалами в сфере WordPress, поделиться своим опытом и узнать что-то новое о самой популярной в мире CMS.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1919:\"<p>Конференция <a href=\"http://2014.russia.wordcamp.org/\">WordCamp Russia 2014</a> пройдет 9 августа в Москве. На мероприятии вы сможете пообщаться с профессионалами в сфере WordPress, поделиться своим опытом и узнать что-то новое о самой популярной в мире CMS.</p>
<p>В этом году на WordCamp Russia планируется два отдельных потока для пользователей и разработчиков. С докладами на конференции выступят специалисты WordPress из России и из-за рубежа, включая разработчиков ядра WordPress. Среди подтвержденных докладов:</p>
<ul>
<li>Основы поисковой оптимизации WordPress</li>
<li>WordPress под нагрузкой: масштабирование и отказоустойчивость</li>
<li>Сайт глазами контентера: какой должна быть идеальная &#171;админка&#187;</li>
<li>Как не сойти с ума при разработке крупных проектов на WordPress</li>
<li>WordPress под прицелом хакеров. Что нужно знать, и как избежать проблем.</li>
<li>Все что вы хотели знать о WP_Query</li>
<li>Моделирование контента в WordPress: сильно больше, чем &#171;просто блог&#187;</li>
<li>Малоизвестные функции в ядре WordPress</li>
<li>Профилирование кода в WordPress</li>
</ul>
<p>Подробности и регистрация <a href=\"http://2014.russia.wordcamp.org/\">на сайте конференции &rarr;</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"WordPress 3.9 «Смит»\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://ru.wordpress.org/news/2014/04/3-9-smith/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Apr 2014 19:56:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Релизы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://ru.wordpress.org/?p=1516\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:710:\"Русская версия WordPress 3.9 &#171;Смит&#187; доступна для скачивания. Если вы уже используете WordPress, то вы можете выполнить обновление через панель администрирования в разделе «Консоль» → «Обновления». Это займет всего несколько секунд! Медиа и редактор В новой версии WordPress мы обновили визуальный редактор, который стал еще быстрее и надежнее, а также более удобным на мобильных устройствах. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5339:\"<p>Русская версия WordPress 3.9 &#171;Смит&#187; доступна для скачивания. Если вы уже используете WordPress, то вы можете выполнить обновление через панель администрирования в разделе «Консоль» → «Обновления». Это займет всего несколько секунд!</p>
<h3>Медиа и редактор</h3>
<p><img src=\"//wordpress.org/news/files/2014/04/editor1-300x233.jpg\" alt=\"editor\" width=\"228\" height=\"177\" /><img src=\"//wordpress.org/news/files/2014/04/image1-300x233.jpg\" alt=\"image\" width=\"228\" height=\"178\" /><img src=\"//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg\" alt=\"dragdrop\" width=\"228\" height=\"178\" /></p>
<p>В новой версии WordPress мы обновили визуальный редактор, который стал еще быстрее и надежнее, а также более удобным на мобильных устройствах. Вы теперь можете вставлять текст из таких программ, как Microsoft Word, и редактор автоматически преобразует их в чистую разметку.</p>
<p>Редактировать изображения (повернуть, перевернуть, обрезать) в медиатеке стало еще быстрее и приятнее в новой версии, а изменять размер вставленных изображений вы теперь можете прямо в самом редакторе.</p>
<p>Загружать новые файлы в библиотеку файлов также стало намного легче &#8212; теперь их достаточно просто перетащить с вашего компьютера (например, с рабочего стола) прямо в редактор WordPress.</p>
<p>При вставке галерей в визуальный редактор версии 3.9 вы теперь увидите полноценное превью ваших изображений. Предварительный просмотр элементов в редакторе также доступен для аудио, видео и плей-листов.</p>
<h3>Аудио и видео</h3>
<p>В WordPress 3.9 улучшена встроенная поддержка аудио- и видеофайлов. Мы обновили медиаплеер, а также добавили возможность легко создавать плей-листы для аудио и видео:</p>
<p><img class=\"alignnone size-large wp-image-1534\" src=\"//ru.wordpress.org/files/2014/04/wordpress-audio-playlist1.png\" alt=\"wordpress-audio-playlist\" width=\"641\" height=\"254\" srcset=\"https://ru.wordpress.org/files/2014/04/wordpress-audio-playlist1.png 641w, https://ru.wordpress.org/files/2014/04/wordpress-audio-playlist1-300x118.png 300w\" sizes=\"(max-width: 641px) 100vw, 641px\" /></p>
<h3>Работа с виджетами</h3>
<p>Виджетами теперь легко управлять прямо из конфигуратора тем WordPress. Для запуска конфигуратора зайдите в раздел «Внешний вид» → «Настроить». Любые изменения в этом режиме вступят в силу только после сохранения, так что не бойтесь экспериментировать!</p>
<p><img class=\"alignnone size-full wp-image-1536\" src=\"//ru.wordpress.org/files/2014/04/wordpress-3-9-widgets-screen.png\" alt=\"wordpress-3-9-widgets-screen\" srcset=\"https://ru.wordpress.org/files/2014/04/wordpress-3-9-widgets-screen.png 700w, https://ru.wordpress.org/files/2014/04/wordpress-3-9-widgets-screen-300x120.png 300w\" sizes=\"(max-width: 700px) 100vw, 700px\" /></p>
<h3>Поиск и установка тем</h3>
<p>В версии 3.9 изменился интерфейс для поиска и установки тем из официального каталога WordPress.org. Он стал чище, приятнее и намного быстрее:</p>
<p><img class=\"alignnone size-large wp-image-1539\" src=\"//ru.wordpress.org/files/2014/04/wordpress-3-9-themes-install.png\" alt=\"wordpress-3-9-themes-install\" srcset=\"https://ru.wordpress.org/files/2014/04/wordpress-3-9-themes-install.png 700w, https://ru.wordpress.org/files/2014/04/wordpress-3-9-themes-install-300x113.png 300w\" sizes=\"(max-width: 700px) 100vw, 700px\" /></p>
<p>В новой версии также произошло большое количество внутренних изменений, которые сделали WordPress 3.9 еще быстрее и надежнее. В разработке новой версии WordPress приняло участие более 250 человек из разных стран мира. Мы надеемся, что вам понравится данное обновление.</p>
<p>Если у вас возникнут проблемы с новой версией, обратитесь на <a href=\"https://ru.forums.wordpress.org/\">форум поддержки</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"WordPress 3.8 «Паркер»\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://ru.wordpress.org/news/2013/12/parker/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 13 Dec 2013 16:07:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Релизы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://ru.wordpress.org/?p=1478\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:749:\"Новая версия WordPress 3.8 &#171;Паркер&#187;, названная в честь джазового музыканта Чарли Паркера, доступна для скачивания или обновления через вашу консоль WordPress. Мы надеемся, что вы посчитаете данный релиз самым привлекательным. Совершенно новый внешний вид WordPress получил совершенно новый облик. Новая версия 3.8 полностью изменяет внешний вид панели администрирования, включая новый крупный шрифт Open Sans, плоские [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3736:\"<p>Новая версия WordPress 3.8 &#171;Паркер&#187;, названная в честь джазового музыканта Чарли Паркера, доступна для скачивания или обновления через вашу консоль WordPress. Мы надеемся, что вы посчитаете данный релиз самым привлекательным.</p>
<p><span id=\"more-1478\"></span></p>
<h2>Совершенно новый внешний вид</h2>
<p><img alt=\"Новый дизайн WordPress 3.8\"  src=\"//i1.wp.com/i0.wp.com/wpdotorg.files.wordpress.com/2013/12/overview.jpg?resize=623%2C193\" /></p>
<p>WordPress получил совершенно новый облик. Новая версия 3.8 полностью изменяет внешний вид панели администрирования, включая новый крупный шрифт Open Sans, плоские векторные иконки и восемь различных цветовых схем.</p>
<p><img alt=\"Цветовые схемы WordPress 3.8\"  src=\"//i1.wp.com/i0.wp.com/wpdotorg.files.wordpress.com/2013/12/colors.jpg?w=420\" /></p>
<p>Любителям писать &#171;на ходу&#187; будет интересно знать, что панель администрирования теперь стала адаптивной. Она автоматически подстраивается под необходимую ширину вашего экрана и безупречно работает как с крупными экранами настольных компьютеров, так и с мелкими экранами мобильных устройств и планшетов.</p>
<h2>Новый подход к работе с темами</h2>
<p>В новой версии WordPress стало намного проще и удобнее работать с темами оформления. Мы полностью переделали интерфейс для вашего удобства, включая возможность быстрого поиска по названию, описанию или автору темы, а также возможность &#171;листать&#187; темы с помощью клавиатуры.</p>
<p><img alt=\"Работа с темами в WordPress 3.8\"  src=\"//i1.wp.com/i0.wp.com/wpdotorg.files.wordpress.com/2013/12/themes.jpg?resize=360%2C344\" /></p>
<h2>Журнальная тема Twenty Fourteen</h2>
<p>Twenty Fourteen стала новой стандартной темой в WordPress 3.8. Темный лаконичный дизайн, адаптивная верстка, поддержка ряда форматов записей, несколько разделов для ваших виджетов и совершенно новый модуль &#171;Избранное содержимое&#187;, с помощью которого можно выделить ваши самые яркие записи в виде сетки или слайдера на главной странице.</p>
<p><img  src=\"//i1.wp.com/i0.wp.com/wpdotorg.files.wordpress.com/2013/12/twentyfourteen.jpg?resize=692%2C275\" alt=\"Тема Twenty Fourteen\" /></p>
<p>Скачать официальную русскую версию WordPress 3.8 вы можете по <a href=\"https://ru.wordpress.org/wordpress-3.8-ru_RU.zip\">этой ссылке</a>. Если вы уже пользуетесь WordPress, выполнить обновление можно в вашей панели администрирования в разделе Консоль → Обновления.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 3.7 «Бейси»\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://ru.wordpress.org/news/2013/10/wordpress-3-7/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 25 Oct 2013 08:47:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:12:\"Релизы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:3:\"3.7\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://ru.wordpress.org/?p=1464\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:741:\"WordPress 3.7 (названный в честь джазового музыканта Каунта Бейси) доступен для скачивания на русском языке. Данный релиз нацелен на некоторые улучшения архитектуры ядра: Автоматические обновления: с версией 3.7 вам больше не нужно беспокоиться об обновлении на технические релизы и релизы безопасности &#8212; WordPress самостоятельно выполнит необходимые обновления и сообщит вам об этом по электронной почте. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2380:\"<p>WordPress 3.7 (названный в честь джазового музыканта Каунта Бейси) доступен для скачивания на русском языке. Данный релиз нацелен на некоторые улучшения архитектуры ядра:</p>
<ul>
<li><strong>Автоматические обновления</strong>: с версией 3.7 вам больше не нужно беспокоиться об обновлении на технические релизы и релизы безопасности &#8212; WordPress самостоятельно выполнит необходимые обновления и сообщит вам об этом по электронной почте.</li>
<li><strong>Надёжные пароли</strong>: с новой библиотекой для проверки надёжности паролей в WordPress, пользователи и администраторы вашего сайта будут в безопасности. Индикатор надёжности теперь проверяет не только длину пароля, но и его содержимое. Например 1234567890, password, qwerty и даже h3ll0w0r1d теперь помечаются как &#171;очень слабые пароли&#187;.</li>
<li><strong>Улучшенная поддержка языковых пакетов</strong>: с новой версией, WordPress будет запрашивать и обновлять языковые пакеты для ядра и стандартных тем автоматически.</li>
</ul>
<p>Разработчики смогут управлять автоматическими обновлениями с помощью ряда новых фильтров и событий, выполнять комплексные запросы с датами с помощью нового класса <code>WP_Date_Query</code> и многое другое. Полный список изменений (более 400) вы можете посмотреть в <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.7\">баг-трэкере</a>. В данном релизе приняло участие более 200 разработчиков.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:35:\"https://ru.wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Wed, 18 Apr 2018 15:10:43 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Wed, 18 Apr 2018 15:07:23 GMT\";s:4:\"link\";s:61:\"<https://ru.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";}}s:5:\"build\";s:14:\"20130911010210\";}","no");
INSERT INTO `gol_options` VALUES("2369","_transient_timeout_feed_mod_126d1ca39d75da07beec8b892738427b","1524107444","no");
INSERT INTO `gol_options` VALUES("2370","_transient_feed_mod_126d1ca39d75da07beec8b892738427b","1524064244","no");
INSERT INTO `gol_options` VALUES("2371","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1524107445","no");
INSERT INTO `gol_options` VALUES("2372","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"HeroPress: Where WordPress REALLY Matters\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=2509\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:127:\"https://heropress.com/where-wordpress-really-matters/#utm_source=rss&utm_medium=rss&utm_campaign=where-wordpress-really-matters\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3591:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2016/03/041818-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: The silence is there. But it no longer scares me.\" /><p>A couple years ago I was given possibly the biggest gift the WordPress community has ever given me. The organizers of WordCamp Pune called me to speak, and the community sent me. It was an amazing experience that changed my life.</p>
<p>While I was there I met Mahangu Weerasinghe, a wonderful man from Sri Lanka. He spoke about things that really really resonated with me. His talk was about linguistic accessibility to the Internet in Southeast Asia. Many people told me that English is enough to communicate to all of India, but Mahangu pointed out that MILLIONS of people in Southeast Asia cannot read or understand a single language on the web, let alone English.</p>
<p>WordPress can change that, and that&#8217;s where WordPress really matters.  It&#8217;s wonderful that people around the world can make a living with it, and it&#8217;s wonderful that it gives creative outlet to so many, but <strong>important</strong> that WordPress can give global voice to those who have none.</p>
<p>Mahangu felt for a long time that he had no voice. WordPress changed that for him, and now he&#8217;s using WordPress to change that for everyone.  He&#8217;s been hugely inspirational to me, and I hope he is for you as well.</p>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://heropress.com/essays/breaking-the-silence/\">Breaking the Silence</a></p></blockquote>
<p></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Where WordPress REALLY Matters\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Where%20WordPress%20REALLY%20Matters&via=heropress&url=https%3A%2F%2Fheropress.com%2Fwhere-wordpress-really-matters%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Where WordPress REALLY Matters\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fwhere-wordpress-really-matters%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fwhere-wordpress-really-matters%2F&title=Where+WordPress+REALLY+Matters\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Where WordPress REALLY Matters\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/where-wordpress-really-matters/&media=https://heropress.com/wp-content/uploads/2016/03/041818-150x150.jpg&description=Where WordPress REALLY Matters\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Where WordPress REALLY Matters\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/where-wordpress-really-matters/\" title=\"Where WordPress REALLY Matters\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/where-wordpress-really-matters/\">Where WordPress REALLY Matters</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 18 Apr 2018 12:00:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: Abstract Aluminum\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48051\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://ma.tt/2018/04/abstract-aluminum/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:346:\"<p>You probably haven&#8217;t thought much about beer cans, Abstract Aluminum Space, the Midwest Premium, and how it all ties into Goldman Sachs, so you should read <a href=\"https://www.bloomberg.com/view/articles/2014-09-03/the-goldman-sachs-aluminum-conspiracy-lawsuit-is-over\">how the Goldman Sachs aluminum conspiracy lawsuit is over</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 17 Apr 2018 21:57:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"BuddyPress: BuddyPress 3.0 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=272059\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://buddypress.org/2018/04/buddypress-3-0-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3509:\"<p>It&#8217;s with a huge amount of pleasure and excitement that we&#8217;re announcing the Beta 2 release of BP 3.0 today ready for testing and feedback.</p>
<p>BuddyPress 3.0 will be a major milestone release for us and one we&#8217;re all really excited about, it&#8217;s been a long time coming but finally we are close to releasing the first template pack for BP, this is a completely new &#8216;theme&#8217; or set of template files and functionality designed to replace bp-legacy which has served us so well since it&#8217;s inception way back in the  major release of 1.7 where we introduced &#8216;Theme Compatibility&#8217;, and we&#8217;re all really eager for any feedback during these beta phases you may grab a copy of our beta1 release <a href=\"https://downloads.wordpress.org/plugin/buddypress.3.0.0-beta1.zip\">here</a> to test with.</p>
<p>Nouveau &#8211; as our new template pack has been named &#8211; provides an all new clean set of markup files, refactored from the ground up to be semantic and accessible. Styles are re-written and provided as Sass partials for developers if wanting to build out new packs. A lot of core functionality for components has been re-written and re-located to be sourced from include files by component in the template directory which allows even easier access to modify functions by overloading to a new theme or child theme. Our major loops, members, activity etc have been re-factored to run under Backbone for a smooth Ajax experience and indeed all the Javascript functionality is re-written to be far more modular than it was before and has a far better modern feel to it&#8217;s structuring.</p>
<p>For the first time we have brought in the Customizer to provide user option choices and a range of layout configurations may be selected. In our initial offering we have provided various layout options for the main BP navigation elements  allowing for vertical navs or horizontal, tab effect where suitable. for the component loops such as members, Groups we provide an option to display in a grid layout &amp; at row quantity options or simply as a flat classic list layout.</p>
<p>While we are really excited about Nouveau 3.0 also has many other improvements to offer and you can <a href=\"https://buddypress.trac.wordpress.org/query?status=closed&milestone=3.0&col=id&col=summary&col=status&col=milestone&col=owner&col=type&col=priority&order=priority\">view a list of all closed tickets for 3.0</a></p>
<p>As always your feedback and testing is an invaluable part of our releases, helping us to catch any last minute bugs.<br />
You can download the beta release for testing at <a href=\"https://downloads.wordpress.org/plugin/buddypress.3.0.0-beta1.zip\">downloads.wordpress.org</a> and install on a local copy of WordPress ( please remember this is a beta release and should not be run on an active production site). Any issues found can be reported on our Trac by creating a <a href=\"https://buddypress.trac.wordpress.org/newticket\">new ticket</a></p>
<p>If you&#8217;re a developer comfortable with SVN you might like to checkout a development copy which you can do <a href=\"https://svn.buddypress.org/trunk\">from this link</a> patches can be submitted to existing tickets or issues found reported on a new ticket.</p>
<p>Further guidance on contributing to BuddyPress is covered on our <a href=\"https://codex.buddypress.org/participate-and-contribute/\">Contributor guidelines page</a> in our <a href=\"https://codex.buddypress.org/\">Codex</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 17 Apr 2018 20:30:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Hugo Ashmore\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: Talking Gutenberg on Episode Eight of the Drunken UX Podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79942\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://wptavern.com/talking-gutenberg-on-episode-eight-of-the-drunken-ux-podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:738:\"<p>Last week, I had the pleasure of joining Michael Fienen and Aaron Hill, hosts of the Drunken UX podcast, to <a href=\"https://drunkenux.com/podcast/8-sweet-home-automattic-where-we-use-gutenberg/\">discuss Gutenberg</a>. We covered a lot of topics, including, why Gutenberg was created, our experiences, its timeline, pros, cons, resources, our biggest concerns, and what developers and freelancers need to know.</p>

<p>The show is one hour and thirty minutes in length. By the way, please don&#8217;t criticize my drink of choice.</p>


    <blockquote class=\"wp-embedded-content\"><a href=\"https://drunkenux.com/podcast/8-sweet-home-automattic-where-we-use-gutenberg/\">#8: Sweet Home Automattic, Where We Use Gutenberg</a></blockquote>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 17 Apr 2018 00:14:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: Plugins Hosted on WordPress.org Can No Longer Guarantee Legal Compliance\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79884\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"https://wptavern.com/plugins-hosted-on-wordpress-org-can-no-longer-guarantee-legal-compliance\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2105:\"<p>The plugin review team has amended <a href=\"https://developer.wordpress.org/plugins/wordpress-org/detailed-plugin-guidelines/#9-developers-and-their-plugins-must-not-do-anything-illegal-dishonest-or-morally-offensive\">guideline number nine</a> which states, <em>developers and their plugins must not do anything illegal, dishonest, or morally offensive</em>, to include the following statement:</p>

<ul>
    <li>Implying that a plugin can create, provide, automate, or guarantee legal compliance</li>
</ul>

<p>Mika Epstein, a member of the WordPress.org plugin review team, <a href=\"https://make.wordpress.org/plugins/2018/04/12/legal-compliance-added-to-guidelines/\">says</a> the change was made because plugins by themselves can not provide legal compliance. <br /></p>

<blockquote class=\"wp-block-quote\">
    <p>Sadly, no plugin in and of itself can provide legal compliance. While a plugin can certainly <em>assist</em> in automating the steps on a compliance journey, or allow you to develop a workflow to solve the situation, they cannot protect a site administrator from mistakes or lack of compliance, nor can they protect site users from incorrect or incomplete legal compliance on the part of the web site.</p><cite>Mika Epstein</cite></blockquote>

<p>Since sites can have any combination of WordPress plugins and themes activated, it&#8217;s nearly impossible for a single plugin to make sure they&#8217;re 100% legally compliant.</p>

<p>Plugin developers affected by this change will be contacted by the review team and be asked to change their titles, descriptions, plugin header images, and or the text within the readme.</p>

<p>Instead of claiming compliance, the team has published a <a href=\"https://developer.wordpress.org/plugins/wordpress-org/compliance-disclaimers/\">frequently asked questions</a> document that recommends plugin authors explain how the plugin will assist in compliance. If you have any questions, please leave a comment on the <a href=\"https://make.wordpress.org/plugins/2018/04/12/legal-compliance-added-to-guidelines/\">announcement post</a>. </p>

<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 Apr 2018 23:35:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"Post Status: All about you(r privacy) — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=45249\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://poststatus.com/all-about-your-privacy-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2485:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p><span>In this episode, the two Brians discuss the current conversations and controversy surrounding data collection and visitor privacy on the web. The duo dig in to the General Data Protection Regulation (GDPR) and what it means for you both as site visitors and site owners and, in particular, how WordPress core and plugin authors are (or should be) responding to the new regulation. It’s a pretty deep topic with many implications and ramifications. Be sure to follow the episode links, too, so that you can be best informed and prepared for when GDPR goes into effect on May 25, 2018.</span></p>
<p></p>
<p>Links</p>
<ul>
<li><a href=\"https://www.cjr.org/tow_center_reports/understanding-general-data-protection-regulation.php\">CJR report on understanding the General Data Protection Regulation</a></li>
<li><a href=\"https://make.wordpress.org/core/2018/03/28/roadmap-tools-for-gdpr-compliance/\">Core&#8217;s roadmap for GDPR compliance</a></li>
<li><a href=\"https://core.trac.wordpress.org/query?status=!closed&keywords=~gdpr\">Trac issues related to GDPR</a></li>
<li><a href=\"https://pagely.com/blog/gdpr-wordpress-2018-resources/?mc_cid=a002d1fc74&mc_eid=58d2ea272a\">Pagely&#8217;s GDPR guide</a></li>
<li><a href=\"https://www.smashingmagazine.com/2018/02/gdpr-for-web-developers/?mc_cid=a002d1fc74&mc_eid=58d2ea272a\">Heather Burns&#8217; detailed GDPR analysis in Smashing Magazine</a></li>
</ul>
<h3>Sponsor: Valet</h3>
<p>This episode is sponsored by <a href=\"https://www.valet.io/\">Valet</a>. Valet helps keep your clients happy &amp; coming back. They offer expert services and keep the websites they manage functioning flawlessly. They offer preventative care that provides peace of mind around the clock. For more information, check out <a href=\"https://www.valet.io/\">their website</a> and thank you to Valet for being a Post Status partner.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 Apr 2018 12:56:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Matt: Russell’s Treadmill\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48043\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"https://ma.tt/2018/04/russells-treadmill/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:704:\"<p>From <a href=\"https://www.amazon.com/dp/B015D3X0YG\">Bertrand Russell&#8217;s A Conquest of Happiness</a>.</p>

<blockquote class=\"wp-block-quote\">
    <p>It is very singular how little men seem to realize that they are not caught in the grip of a mechanism from which there is no escape, but that the treadmill is one upon which they remain merely because they have not noticed that it fails to take them up to a higher level.</p>
</blockquote>

<p>He also says later, &#8220;﻿There are two motives for reading a book: one, that you enjoy it; the other, that you can boast about it.&#8221; <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f602.png\" alt=\"😂\" class=\"wp-smiley\" /></p>

<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 13 Apr 2018 20:22:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"Dev Blog: GDPR Compliance Tools in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5728\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/news/2018/04/gdpr-compliance-tools-in-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3913:\"<p>GDPR compliance is an important consideration for all WordPress websites. The GDPR Compliance team is looking for help to test the privacy tools that are currently being developed in core. </p>

<h2>What is GDPR?</h2>

<p>GDPR stands for <a href=\"https://en.wikipedia.org/wiki/General_Data_Protection_Regulation\">General Data Protection Regulation</a> and is intended to strengthen and unify data protection for all individuals within the European Union. Its primary aim is to give control back to the EU residents over their personal data. <br /></p>

<p>Why the urgency? Although the GDPR was introduced two years ago, it becomes  enforceable starting May 25, 2018.</p>

<h2>Make WordPress GDPR Compliance Team</h2>

<p>Currently, the GDPR Compliance Team understands that helping WordPress-based sites become compliant is a large and ongoing task. The team is focusing on creating a comprehensive core policy, plugin guidelines, privacy tools and documentation. All of this requires your help.<br /></p>

<p>The GDPR Compliance Team is focusing on four main areas:</p>

<ul>
    <li>Add functionality to assist site owners in creating comprehensive privacy policies for their websites.</li>
    <li>Create guidelines for plugins to become GDPR ready.</li>
    <li>Add administration tools to facilitate compliance and encourage user privacy in general.</li>
    <li>Add documentation to educate site owners on privacy, the main GDPR compliance requirements, and on how to use the new privacy tools.</li>
</ul>

<h2>Don’t we already have a privacy policy?</h2>

<p>Yes and no. That said, The GDPR puts tighter guidelines and restrictions. Though we have many plugins that create privacy pages, we need means to generate a unified, comprehensive privacy policy. We will need tools for users to easily come into compliance.<br /></p>

<p>Site owners will be able to create GDPR compliant privacy policy in three steps:</p>

<ol>
    <li>Adding a dedicated page for the policy.<br /></li>
    <li>Adding privacy information from plugins.</li>
    <li>Reviewing and publishing the policy.</li>
</ol>

<p>A new &#8220;postbox&#8221; will be added to the Edit Page screen when editing the policy. All plugins that collect or store user data will be able to add privacy information there. In addition it will alert the site owners when any privacy information changes after a plugin is activated, deactivated, or updated.<br /></p>

<p>There is a new functionality to confirm user requests by email address. It is intended for site owners to be able to verify requests from users for displaying, downloading, or anonymizing of personal data.<br /></p>

<p>A new &#8220;Privacy&#8221; page is added under the &#8220;Tools&#8221; menu. It will display new, confirmed requests from users, as well as already fulfilled requests. It will also contain the tools for exporting and anonymizing of personal data and for requesting email confirmation to avoid abuse attempts.<br /></p>

<p>New section on privacy will be added to the <a href=\"https://developer.wordpress.org/plugins/\">Plugin Handbook</a>. It will contain some general information on user privacy, what a plugin should do to be compliant, and also tips and examples on how to use the new privacy related functionality in WordPress.<br /></p>

<p>The new privacy tools are scheduled for release at the end of April or beginning of May 2018.</p>

<h2>How can you get involved?</h2>

<p>We would love to have your help. The first step is awareness and education. For more information about the upcoming privacy tools see ﻿<a href=\"https://make.wordpress.org/core/2018/03/28/roadmap-tools-for-gdpr-compliance/\">the roadmap</a>.</p>

<p>If you would like to get involved in building WordPress Core and testing the new privacy tools, please join the #gdpr-compliance channel in the <a href=\"https://make.wordpress.org/chat/\">Make WordPress</a> Slack group.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Apr 2018 20:11:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Andrew Ozz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:103:\"WPTavern: WPWeekly Episode 312 – Dragon Drop, WordPress Accessibility Statement, and WooCommerce GDPR\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=79862&preview=true&preview_id=79862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:108:\"https://wptavern.com/wpweekly-episode-312-dragon-drop-wordpress-accessibility-statement-and-woocommerce-gdpr\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1888:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I start the show by sharing our thoughts on Mark Zuckberberg&#8217;s congressional hearing. We then discuss what&#8217;s new in Gutenberg 2.6 and describe our user experience. We let you know what&#8217;s in WooCommerce 3.3.5 and discuss what the development team is doing to prepare for GDPR compliance.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/gutenberg-2-6-introduces-drag-and-drop-block-sorting\">Gutenberg 2.6 Introduces Drag and Drop Block Sorting</a><br />
<a href=\"https://wptavern.com/theme-review-changes-place-more-onus-onto-theme-authors\">Theme Review Changes Place More Onus Onto Theme Authors</a><br />
<a href=\"https://wordpress.org/about/accessibility/\">WordPress Accessibility Statement</a><br />
<a href=\"https://woocommerce.wordpress.com/2018/04/10/woocommerce-3-3-5-fix-release-notes/\">WooCommerce 3.3.5 Released</a><br />
<a href=\"https://woocommerce.wordpress.com/2018/04/10/how-were-tackling-gdpr-in-woocommerce-core/\">How WooCommerce is tackling GDPR</a></p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://atomicblocks.com/introducing-the-atomic-blocks-plugin-and-theme/\">AtomBlocks by Mike McAlister</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, April 18th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #312:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Apr 2018 01:05:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"HeroPress: Growing Up Rural\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=2503\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://heropress.com/growing-up-rural/#utm_source=rss&utm_medium=rss&utm_campaign=growing-up-rural\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2947:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2015/10/ImpactForOthers-HeroPress-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: I hope and pray that in some small way I\'ll be able to take what I\'ve learned and make an impact for others.\" /><p>This week&#8217;s throwback essay is titled &#8220;<a href=\"https://heropress.com/essays/i-dont-know-anything-and-thats-ok/\">I don&#8217;t know anything, and that&#8217;s ok</a>&#8220;. It was written back in 2015 by my friend Kyle. He and I grew up in similar circumstances; far from a hub of civilization, in a relatively economically depressed area, without the best education opportunities.</p>
<p>Yet he and I both managed to find the web, dive in, and find home. We support our families and find joy in the work we produce. I&#8217;m not sure there&#8217;s a better way to live than that.</p>
<p>Check out Kyle&#8217;s essay and let him know what you think.</p>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://heropress.com/essays/i-dont-know-anything-and-thats-ok/\">I Don’t Know Anything and That’s OK</a></p></blockquote>
<p></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Growing Up Rural\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Growing%20Up%20Rural&via=heropress&url=https%3A%2F%2Fheropress.com%2Fgrowing-up-rural%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Growing Up Rural\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fgrowing-up-rural%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fgrowing-up-rural%2F&title=Growing+Up+Rural\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Growing Up Rural\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/growing-up-rural/&media=https://heropress.com/wp-content/uploads/2015/10/ImpactForOthers-HeroPress-150x150.jpg&description=Growing Up Rural\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Growing Up Rural\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/growing-up-rural/\" title=\"Growing Up Rural\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/growing-up-rural/\">Growing Up Rural</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 11 Apr 2018 12:15:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Theme Review Changes Place More Onus Onto Theme Authors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79771\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wptavern.com/theme-review-changes-place-more-onus-onto-theme-authors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2093:\"<p>The WordPress Theme Review team has <a href=\"https://make.wordpress.org/themes/2018/04/09/changes-in-theme-review-process/\">implemented changes</a> that simplify the process and places more responsibility onto theme authors. Theme reviewers now only need to check the following items to pass a theme.</p>

<ul>
    <li>Licensing</li>
    <li>Malicious or egregious stuff</li>
    <li>Content Creation</li>
    <li>Security</li>
</ul>

<p>Although the bar to pass a theme is significantly lower, theme authors are still expected to follow the <a href=\"https://make.wordpress.org/themes/handbook/review/required/\">required</a> and <a href=\"https://make.wordpress.org/themes/handbook/review/recommended/\">recommended</a> requirements listed in the theme handbook.</p>

<p>Moderators will check themes after they&#8217;ve gone live to make sure the author is following guidelines. If a moderator discovers any issues, a request will be made to the theme author to correct them. Failure to do so could lead to a temporary or permanent suspension.</p>

<p>Justin Tadlock <a href=\"https://make.wordpress.org/themes/2018/04/09/changes-in-theme-review-process/#comment-43128\">clarified</a> in the comments examples of egregious issues.</p>

<ul>
    <li>Illegal</li>
    <li>Dishonest</li>
    <li>Morally offensive</li>
    <li>PHP Errors</li>
</ul>

<p>In the past two years, The Theme Review Team has battled the theme review queue with moderate success. <a href=\"https://wptavern.com/wordpress-theme-review-team-making-progress-on-clearing-out-1000-review-backlog\">In early 2017</a>, the number of themes in the queue dropped below 200. Although there has been some work on automating the process, it&#8217;s largely reliant on humans.</p>

<p>Even though it hasn&#8217;t been updated in more than a year, theme authors are highly encouraged to use the <a href=\"https://wordpress.org/plugins/theme-check/\">Theme Check plugin</a> before submitting themes for review.</p>

<p>With a simplified process to get a theme live, reviewers are hoping it will free them up to focus on larger projects.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Apr 2018 23:45:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: Gutenberg 2.6 Introduces Drag and Drop Block Sorting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79658\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wptavern.com/gutenberg-2-6-introduces-drag-and-drop-block-sorting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1729:\"<p><a href=\"https://wordpress.org/plugins/Gutenberg/\">Gutenberg 2.6</a> is available for download and with it, comes a new way of sorting blocks. In addition to using up and down arrows, this version introduces the ability to sort blocks by <a href=\"https://github.com/WordPress/gutenberg/issues/6041\">dragging and dropping</a>.</p>

<p>If you hover the cursor over the up and down arrows on the left side of a block, you&#8217;ll see a hand icon. Simply click, hold, and drag the block up or down below or above the blue indicator.</p>


    


<p>In my limited testing, I found drag and drop to be hit or miss. Sometimes, when I try to drag and drop a block, the blue line doesn&#8217;t show up.</p>

<p>The hand icon for the cursor is different for the top and bottom of the block. You can drag a block by hovering over the bottom of it but you can&#8217;t do it from the top.</p>

<img />
    Hovering the cursor at the top of the block


<img />
    Hovering the cursor at the bottom of the block


<p>I also found it difficult to add a new block manually. For example, when I add a paragraph block, I don&#8217;t see the Plus icon to create a new block underneath it anymore.</p>

<p>Pressing enter at the end of a paragraph creates a new Paragraph block automatically. But I don&#8217;t know how to transform it into an image block. I&#8217;ll need to do more testing to figure out what&#8217;s going on. <br /></p>

<p>There&#8217;s a host of <a href=\"https://make.wordpress.org/core/2018/04/05/whats-new-in-gutenberg-5th-april/\">other improvements and bug fixes </a>in this release, some of which I covered <a href=\"https://wptavern.com/an-update-to-my-gutenberg-experience\">in this post</a>. ﻿<br />. ﻿<br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Apr 2018 00:09:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Post Status: Designing the news — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=45154\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://poststatus.com/designing-the-news-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1904:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p><span>In this episode, Brian and Brian discuss a variety of news topics spanning design, development, and business. Tune in to learn about the history of WordPress and the web, the newest TechCrunch redesign, a WordCamp for WordCamp organizers, and more.</span></p>
<p></p>
<h3>Links</h3>
<ul>
<li><a href=\"https://zeen101.com/for-developers/leakypaywall/\">Leaky Paywall</a></li>
<li><a href=\"https://designintech.report/\">2018 Design in Tech report</a></li>
<li><a href=\"https://gutenberg.courses/development/\">Gutenberg Development Course</a></li>
<li><a href=\"https://techcrunch.com/2018/03/13/welcome-to-the-new-techcrunch/\">TechCrunch redesign</a></li>
<li><a href=\"https://thehistoryoftheweb.com/the-story-of-wordpress/\">WordPress turns 15</a>, via History of the Web</li>
<li><a href=\"https://make.wordpress.org/community/2018/04/03/want-to-help-organize-a-wordcamp-for-organizers/\">Proposal for a WordCamp for WordCamp organizers </a></li>
</ul>
<h3>Sponsor: Gravity Forms</h3>
<p><a href=\"http://www.gravityforms.com/?utm_source=post_status&utm_medium=banner&utm_campaign=ps_ads\">Gravity Forms</a> makes the best web forms on the planet. Over a million WordPress sites are already using Gravity Forms. Is yours? Thanks to Gravity Forms for being a Post Status partner.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 09 Apr 2018 18:36:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"WPTavern: An Update to My Gutenberg Experience\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79564\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wptavern.com/an-update-to-my-gutenberg-experience\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2508:\"<p>Not long after I published <a href=\"https://wptavern.com/my-gutenberg-experience-thus-far\">my experience with Gutenberg</a>, developers reached out to me to work on some of the issues I mentioned. Riad Benguella <a href=\"https://github.com/WordPress/gutenberg/pull/5902\">figured out</a> why meta boxes were not collapsing or expanding.</p>

<p>It turns out that some meta boxes depend on the post script which has a side effect of calling the window.postboxes.add_postbox_toggles( postType ) twice, causing meta boxes to break.</p>

<p>Gutenberg 2.6 <a href=\"https://make.wordpress.org/core/2018/04/05/whats-new-in-gutenberg-5th-april/\">released earlier this week</a>, fixes the issue and all meta boxes function properly again. This also fixes the issue I had with the Telegram for WordPress plugin. <br /></p>

<p><a href=\"https://wordpress.org/plugins/public-post-preview/\">Public Post Preview</a> still doesn&#8217;t work in Gutenberg but the plugin&#8217;s developer, Dominik Schilling, shared some experiments he has conducted with adding support for Gutenberg on Twitter.</p>


    <blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Can\'t wait for seeing Gutenberg in WordPress core. So many new possibilities. Even for Public Post Preview (<a href=\"https://t.co/Xsw9hugxKT\">https://t.co/Xsw9hugxKT</a>). With just a few lines I was able to create this: <a href=\"https://t.co/fxyuBIMPOl\">pic.twitter.com/fxyuBIMPOl</a></p>&mdash; Dominik Schilling <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f30a.png\" alt=\"🌊\" class=\"wp-smiley\" /> (@ocean90) <a href=\"https://twitter.com/ocean90/status/980420608822562816?ref_src=twsrc%5Etfw\">April 1, 2018</a></blockquote>


<p>In the preview video, you can see Public Post Preview&#8217;s options added to the sidebar and in addition to generating a link, you can choose when that URL expires which is better than what&#8217;s currently available in the plugin.</p>

<p>I mentioned how Tags would sometimes disappear and there overall behavior was inconsistent. This <a href=\"https://github.com/WordPress/gutenberg/pull/5913\">pull request </a>that made it into Gutenberg 2.6, fixes the issue by only including the term in the Tag selector if it&#8217;s known.</p>

<p>Although I&#8217;m still bummed that certain plugins are not yet compatible with Gutenberg, I&#8217;m pretty happy that two of the major pain points I experienced have been fixed. Thanks to Riad, Tammie Lister, and others for helping to solve these problems so quickly. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 06 Apr 2018 21:29:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"WPTavern: A WordCamp for Organizers Is in the Planning Stages\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79513\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wptavern.com/a-wordcamp-for-organizers-is-in-the-planning-stages\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2684:\"<p>Last year, Drew Jaynes and Carol Stambaugh <a href=\"https://make.wordpress.org/community/2017/08/16/proposed-event-wordcamp-for-wordcamp-organizers/\">proposed</a> a new WordCamp event geared towards organizers to the WordPress Community Team. After fleshing out the details and discussing the idea over the course of seven months, the duo <a href=\"https://make.wordpress.org/community/2018/04/03/want-to-help-organize-a-wordcamp-for-organizers/\">has announced</a> that a WordCamp for Organizers is officially on the table.</p>

<p>The goal of the event is to provide an opportunity for meetup and WordPress event organizers to share their experience with others in the community. The plan is to host a one-day event a day or two before <a href=\"https://2018.us.wordcamp.org/\">WordCamp US</a> in Nashville, TN, later this year.</p>

<p>&#8220;The idea for WordCamp for Organizers – what some of us affectionately refer to as &#8216;dotOrganize&#8217; – was really borne out of many conversations I’ve had over the years with others in the WordPress community lamenting the lack of a ready knowledge sharing opportunity between event organizers,&#8221; Jaynes said.</p>

<p>&#8220;One common thread seemed to be the idea of common lessons learned, and how awesome it would be to just have an event for organizers to get together and swap tips and tricks. </p>

<p>&#8220;We’re all here organizing the same community, maybe we should get together and trade notes! And so we now have a new topic-based WordCamp just for organizers. </p>

<p>&#8220;It’s kind of meta – organizing a WordCamp for Organizers, but I really feel like this could be a boon for anybody currently organizing or looking to start organizing in WordPress. Exciting!&#8221;</p>

<p>Some of the session topics that could be presented on include:</p>

<ul>
    <li>Spreading the word about your community events</li>
    <li>Tips for wrangling speakers, volunteers, and sponsors</li>
    <li>Conflict resolution among organizing teams</li>
    <li>How to respond to a code of conduct issue</li>
    <li>Finding and using official organizing tools and resources<br /></li>
</ul>

<p>The team is seeking volunteers who can spend 2-4 hours per week to help organize the event. Although it&#8217;s focused on organizers, those who have attended many conferences, including WordCamps, with little event organizing experience, are encouraged to join the team.</p>

<p>If you&#8217;re interested in volunteering, please leave a comment on the <a href=\"https://make.wordpress.org/community/2018/04/03/want-to-help-organize-a-wordcamp-for-organizers/\">official announcement post</a>. </p>

<p><br /></p><br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 06 Apr 2018 00:22:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WPTavern: Jetpack 6.0 Takes Steps Towards GDPR Compliance\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79459\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wptavern.com/jetpack-6-0-takes-steps-towards-gdpr-compliance\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1148:\"<p>Jetpack 6.0 <a href=\"https://jetpack.com/2018/04/03/jetpack-6-0/\">is available</a> for upgrade. It comes with improvements to the social media icons widget, enhanced brute force protection, and better compatibility between WooCommerce and Jetpack.</p>

<p>Its headlining features though are privacy related as the <a href=\"https://www.eugdpr.org/\">General Data Protection Regulation</a> (GDPR) is set to go into effect May 25th. In 6.0, Jetpack has a dedicated privacy settings page that links to privacy documents and includes a way to opt-out of activity tracking.</p>

<p>These settings can be accessed by clicking the Privacy link at the bottom of the Jetpack Dashboard page. </p>

<img />
    Jetpack 6.0 Privacy Settings


<p>The &#x27;<a href=\"https://jetpack.com/support/what-data-does-jetpack-sync/\">What Data Does Jetpack Sync</a>&#x27; page outlines what data is used, how it&#x27;s used, the relationship it has with the WordPress mobile apps, and provides an inside look at how Jetpack works.</p>

<p>These are the first steps towards GDPR compliance with more updates planned before the regulation goes into effect next month. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 05 Apr 2018 23:20:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: WPWeekly Episode 311 – Jetpack 6.0, WordPress 4.9.5, and A WordCamp for Organizers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=79447&preview=true&preview_id=79447\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"https://wptavern.com/wpweekly-episode-311-jetpack-wordpress-4-9-5-and-a-wordcamp-for-organizers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1628:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I discuss a <a href=\"https://glueckpress.com/9336/amp-and-wordpress/\">great article</a> published by Caspar Hübinger on AMP and WordPress. We cover what&#8217;s new in WordPress 4.9.5, Jetpack 6.0, and a WordCamp geared toward organizers.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/wordpress-4-9-5-squashes-25-bugs\">WordPress 4.9.5 Squashes 25 Bugs</a><br />
<a href=\"https://wptavern.com/try-gutenberg-prompt-pushed-back-to-a-later-release\">‘Try Gutenberg’ Prompt Pushed Back to A Later Release</a><br />
<a href=\"https://jetpack.com/2018/04/03/jetpack-6-0/\">Jetpack 6.0 Released</a><br />
<a href=\"https://make.wordpress.org/community/2018/04/03/code-of-conduct-survey/\">Code of Conduct Survey</a><br />
<a href=\"https://make.wordpress.org/community/2018/04/03/want-to-help-organize-a-wordcamp-for-organizers/\">Want to Help Organize a WordCamp for Organizers?</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, April 11th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #311:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 05 Apr 2018 01:15:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"HeroPress: The Year I Got Cancer Was The Year My WordPress Business Took Off\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2497\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:204:\"https://heropress.com/essays/the-year-i-got-cancer-was-the-year-my-wordpress-business-took-off/#utm_source=rss&utm_medium=rss&utm_campaign=the-year-i-got-cancer-was-the-year-my-wordpress-business-took-off\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8809:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2018/04/040418-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: Take care of yourselves and of each other, it\'s very important.\" /><p>In 2010 I was beginning to take on client work creating WordPress web sites when I was diagnosed with ovarian cancer. Ironically, at 43 years old I was more fit and healthy than I had ever been in my entire life. I had been running road marathons and trail ultra marathons for a few years leading up to my diagnosis. Good thing too, because surgery and treatment were obviously very tough.</p>
<p>I was transitioning my design studio from analog to digital. Previously, I was working as a professional artist and illustrator creating commission portraiture and college mascot illustrations with some moderate successes. My background is in Fine Art and Design. I studied Drawing, Sculpture, &amp; Time Arts. (2D, 3D &amp; 4D &#8211; 4D can be described as: Length, width, height, and time/ motion) Naturally, as a Time Arts artist/illustrator I love the web! I love designing for the web and mobile too. Web work is immediately gratifying. I do design for both the web and print but I have always felt drawn to the web as it is more accessible, more fluid, dynamic, interconnected, animated, media rich, and well … if you are reading this then you already get the picture. <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /></p>
<blockquote><p>To get through treatment it was important to me that I still work every day.</p></blockquote>
<p>Some days it was just a couple hours in the afternoon but it really helped me to cope and endure unplanned surgery and many painful chemotherapy treatments. I had recently completed a couple of websites with the help of my mentor Jerry Turk. Those sites had good reach. I mean they were the kind of sites that groups of people used and managed so I got some attention for the work and word of mouth spread locally.</p>
<p>It was while getting through that period of treatment and the shock of a devastating diagnosis that my digital design agency really got legs. It could not have happened at a better time. So, my studio, C&amp;D Studios &#8211; <a href=\"https://CandDStudios.com\">https://CandDStudios.com</a> continued it’s move towards being 100% digital. No more analog photography and not much more drawing at the drawing table either. Now my work was nearly 100% focused on screens and it would also begin to pay the bills. That was eight years ago. I was very fortunate to learn using reliable frameworks, themes, plug-ins, and hosts that would also stand the test of time. Thank you Genesis Framework, StudioPress and Gravity Forms to name a few…</p>
<p>Fast forward to 2016 after having been cancer free all those years and cranking out a lot of agency work, I had a cancer reoccurrence. I never wanted cancer to be part of my story and I tried to deny or overcome it in all ways but it had resurfaced in October of 2016. Professionally, I was involved in collaborating on very large scale enterprise sites with teams. I was spending the year testing the waters at a new level of production. It was not good timing to require another surgery and 18 more rounds of chemotherapy. Fortunately, I found support in the community from other designers and developers whom helped me to the finish lines with 3 large projects in areas of e-commerce, college membership and enterprise site work -one with a large volume of SVG animations. After surgery, in February of 2017 I completed 18 rounds of chemotherapy treatments.</p>
<blockquote><p>I have survived and am cancer free once again!</p></blockquote>
<p>While going through treatment the second time I was not really focused on what good thing will I be able to grow towards professionally. Honestly, when you go through these things in life &#8211; you just spend your energy getting through as best as you can. I think it is worth noting here that while a positive attitude is great and it can improve a patient’s overall experience. Please don’t tell people they will survive cancer because of their positive attitude. Cancer is horrible, it does not discriminate and when people can’t beat a disease with their mental attitude they end up blaming themselves unnecessarily. That is not good. That is not what people intend when then try to offer support in that way but that is something I wanted to share.</p>
<p>Now I have landed on the other side of treatment again and as I reflect, it’s been a really epic year! Our WordPress community has been open and supportive, welcoming me at conferences, online, and in slack groups, whether I had hair, energy, or resources &#8211; always welcoming and always encouraging. Over the years I have made some wonderful friends through WordPress! Some of us have been at this for a long time and we now have many shared experiences and skills.</p>
<h3>Having Survived Again I’m Launching a WordPress Product</h3>
<p>Having survived again, and having been inspired at PressNomics in Tempe last spring, I’m busy launching a mobile product/service with my team Dr. Kendra Remington and Rita Best called <a href=\"https://docswithapps.com\">Docs With Apps</a>.</p>
<p>I still accept some client work, and some retainer work but I’m pretty selective about the projects we work on “in house.”</p>
<p>I love SVG animation work so in 2018 I’m overjoyed to be doing more contracted SVG animation work with my collaborator Jackie D’Elia. Hit us up!!</p>
<p>These are some very wonderful times in technology and within the Internet of things. I feel very grateful to have been able to ride the digital wave into the present and future. At WCUS in Nashville I began the process of contributing to make WordPress after having spent many years empowering others with it.</p>
<p>When I was young I needed a way to get my portfolio on line and that is how I got started. Thank you for the opportunity to share my story, to publicly thank my husband Dominic, my family, and friends too. The future is going to be awesome!</p>
<p>Take care of yourself and of each other, it&#8217;s very important.</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: The Year I Got Cancer Was The Year My WordPress Business Took Off\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=The%20Year%20I%20Got%20Cancer%20Was%20The%20Year%20My%20WordPress%20Business%20Took%20Off&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fthe-year-i-got-cancer-was-the-year-my-wordpress-business-took-off%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: The Year I Got Cancer Was The Year My WordPress Business Took Off\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fthe-year-i-got-cancer-was-the-year-my-wordpress-business-took-off%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fthe-year-i-got-cancer-was-the-year-my-wordpress-business-took-off%2F&title=The+Year+I+Got+Cancer+Was+The+Year+My+WordPress+Business+Took+Off\" rel=\"nofollow\" target=\"_blank\" title=\"Share: The Year I Got Cancer Was The Year My WordPress Business Took Off\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/the-year-i-got-cancer-was-the-year-my-wordpress-business-took-off/&media=https://heropress.com/wp-content/uploads/2018/04/040418-150x150.jpg&description=The Year I Got Cancer Was The Year My WordPress Business Took Off\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: The Year I Got Cancer Was The Year My WordPress Business Took Off\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/the-year-i-got-cancer-was-the-year-my-wordpress-business-took-off/\" title=\"The Year I Got Cancer Was The Year My WordPress Business Took Off\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/the-year-i-got-cancer-was-the-year-my-wordpress-business-took-off/\">The Year I Got Cancer Was The Year My WordPress Business Took Off</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 04 Apr 2018 12:00:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Cathi Bosco\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"WPTavern: WordPress 4.9.5 Squashes 25 Bugs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79399\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wptavern.com/wordpress-4-9-5-squashes-25-bugs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:940:\"<p>WordPress 4.9.5 <a href=\"https://wordpress.org/news/2018/04/wordpress-4-9-5-security-and-maintenance-release/\">is available</a> for download and is a maintenance and security release. WordPress 4.9.4 and earlier versions are affected by three security issues. The following security hardening changes are in 4.9.5.</p>

<ul>
    <li>Localhost is no longer treated as the same host by default.<br /></li>
    <li>Safe redirects are used when redirecting the login page if SSL is forced.</li>
    <li>Versions strings are correctly escaped for use in generator tags.</li>
</ul>

<p>Twenty-five bugs are fixed in this release including, improve compatibility with PHP 7.2, previous styles on caption shortcodes are restored, and clearer error messages. To see a full list of changes along with their associated trac tickets, check out <a href=\"https://make.wordpress.org/core/2018/04/02/wordpress-4-9-5/\">the detailed release post</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Apr 2018 23:02:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"Dev Blog: WordPress 4.9.5 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5645\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2018/04/wordpress-4-9-5-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6336:\"<p>WordPress 4.9.5 is now available. This is a <strong>security and maintenance release</strong> for all versions since WordPress 3.7. We strongly encourage you to update your sites immediately.</p>

<p>WordPress versions 4.9.4 and earlier are affected by three security issues. As part of the core team&#x27;s ongoing commitment to security hardening, the following fixes have been implemented in 4.9.5:</p>

<ol>
    <li>Don&#x27;t treat <code>localhost</code> as same host by default.</li>
    <li>Use safe redirects when redirecting the login page if SSL is forced.</li>
    <li>Make sure the version string is correctly escaped for use in generator tags.</li>
</ol>

<p>Thank you to the reporters of these issues for practicing <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">﻿coordinated security disclosure</a>: <a href=\"https://profiles.wordpress.org/xknown\">xknown</a> of the WordPress Security Team, <a href=\"https://hackerone.com/nitstorm\">Nitin Venkatesh (nitstorm)</a>, and <a href=\"https://twitter.com/voldemortensen\">Garth Mortensen</a> of the WordPress Security Team.</p>

<p>Twenty-five other bugs were fixed in WordPress 4.9.5. Particularly of note were:</p>

<ul>
    <li>The previous styles on caption shortcodes have been restored.</li>
    <li>Cropping on touch screen devices is now supported.</li>
    <li>A variety of strings such as error messages have been updated for better clarity.</li>
    <li>The position of an attachment placeholder during uploads has been fixed.</li>
    <li>Custom nonce functionality in the REST API JavaScript client has been made consistent throughout the code base.</li>
    <li>Improved compatibility with PHP 7.2.</li>
</ul>

<p><a href=\"https://make.wordpress.org/core/2018/04/03/wordpress-4-9-5/\">This post has more information about all of the issues fixed in 4.9.5 if you&#x27;d like to learn more</a>.</p>

<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.9.5</a> or venture over to Dashboard → Updates and click \"Update Now.\" Sites that support automatic background updates are already beginning to update automatically.</p>

<p>Thank you to everyone who contributed to WordPress 4.9.5:</p>

<p><a href=\"https://profiles.wordpress.org/1265578519-1/\">1265578519</a>, <a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/schlessera/\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/alexgso/\">alexgso</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andrei0x309/\">andrei0x309</a>, <a href=\"https://profiles.wordpress.org/antipole/\">antipole</a>, <a href=\"https://profiles.wordpress.org/aranwer104/\">Anwer AR</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/blair-jersyer/\">Blair jersyer</a>, <a href=\"https://profiles.wordpress.org/bandonrandon/\">Brooke.</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/codegrau/\">codegrau</a>, <a href=\"https://profiles.wordpress.org/conner_bw/\">conner_bw</a>, <a href=\"https://profiles.wordpress.org/davidakennedy/\">David A. Kennedy</a>, <a href=\"https://profiles.wordpress.org/designsimply/\">designsimply</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling (ocean90)</a>, <a href=\"https://profiles.wordpress.org/electricfeet/\">ElectricFeet</a>, <a href=\"https://profiles.wordpress.org/ericmeyer/\">ericmeyer</a>, <a href=\"https://profiles.wordpress.org/fpcsjames/\">FPCSJames</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/soulseekah/\">Gennady Kovshenin</a>, <a href=\"https://profiles.wordpress.org/henrywright/\">Henry Wright</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jbpaul17/\">Jeffrey Paul</a>, <a href=\"https://profiles.wordpress.org/jipmoors/\">Jip Moors</a>, <a href=\"https://profiles.wordpress.org/joemcgill/\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johnpgreen/\">johnpgreen</a>, <a href=\"https://profiles.wordpress.org/junaidkbr/\">Junaid Ahmed</a>, <a href=\"https://profiles.wordpress.org/kristastevens/\">kristastevens</a>, <a href=\"https://profiles.wordpress.org/obenland/\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/lakenh/\">Laken Hafner</a>, <a href=\"https://profiles.wordpress.org/lancewillett/\">Lance Willett</a>, <a href=\"https://profiles.wordpress.org/leemon/\">leemon</a>, <a href=\"https://profiles.wordpress.org/melchoyce/\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/mikeschroder/\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/mrmadhat/\">mrmadhat</a>, <a href=\"https://profiles.wordpress.org/nandorsky/\">nandorsky</a>, <a href=\"https://profiles.wordpress.org/jainnidhi/\">Nidhi Jain</a>, <a href=\"https://profiles.wordpress.org/swissspidy/\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/qcmiao/\">qcmiao</a>, <a href=\"https://profiles.wordpress.org/rachelbaker/\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/larrach/\">Rachel Peter</a>, <a href=\"https://profiles.wordpress.org/ravanh/\">RavanH</a>, <a href=\"https://profiles.wordpress.org/otto42/\">Samuel Wood (Otto)</a>, <a href=\"https://profiles.wordpress.org/sebastienthivinfocom/\">Sebastien SERRE</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/shital-patel/\">Shital Marakana</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/thomas-vitale/\">Thomas Vitale</a>, <a href=\"https://profiles.wordpress.org/kwonye/\">Will Kwon</a>, and <a href=\"https://profiles.wordpress.org/yahil/\">Yahil Madakiya</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Apr 2018 19:56:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Aaron D. Campbell\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: ‘Try Gutenberg’ Prompt Pushed Back to A Later Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79273\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wptavern.com/try-gutenberg-prompt-pushed-back-to-a-later-release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4312:\"<p>Last week, <a href=\"https://wptavern.com/in-wordpress-4-9-5-users-will-be-two-clicks-away-from-installing-and-activating-gutenberg-from-the-dashboard\">we reported</a> that WordPress 4.9.5 would ship with a call-out prompt that asks users if they want to try the new editor experience.</p>

<p>Within the comments of the post, Gary Pendergast, who works for Automattic, is a WordPress core contributor, and a lead developer on the Gutenberg project, <a href=\"https://wptavern.com/in-wordpress-4-9-5-users-will-be-two-clicks-away-from-installing-and-activating-gutenberg-from-the-dashboard#comment-246119\">informed us</a> that the prompt would not be in WordPress 4.9.5. Instead, it will ship in a later version once it has gone through a few more refinements.</p>

<blockquote class=\"wp-block-quote\">
    <p>Change of plans, this won’t be happening in the 4.9.5 release: there are still a few issues we’d like to fix up the callout happens, they won’t be done in time for the 4.9.5 release. I expect there will be a smaller 4.9.6 release that contains this callout, and any bugfixes that happen to be ready.</p><cite>Gary Pendergast</cite></blockquote>

<p>Reverting the call-out has <a href=\"https://core.trac.wordpress.org/ticket/41316\">extended the conversation</a> surrounding its implementation. Jadon N who works for InMotion hosting and is a contributor to the <a href=\"https://make.wordpress.org/chat/\">#hosting-community slack channel</a>, says the hosting-community group is working on ideas to help test popular plugins for Gutenberg compatibility.</p>

<blockquote class=\"wp-block-quote\">
    <p>We have been working to expand our collection of data about how well plugins function with Gutenberg. To help with that effort, we would like to explore using feedback collected from WordPress users through the Try Gutenberg effort to add to the existing database on WordPress plugin compatibility if that could be worked out. </p>
    <p>The goal of this project is to make sure everyone can use Gutenberg without having to worry about plugin incompatibilities.</p><cite>Jadon N</cite></blockquote>

<p>The <a href=\"https://plugincompat.danielbachhuber.com/\">Gutenberg Plugin Compatibility Database project</a> launched by Daniel Bachhuber last month attempts to determine which popular plugins are already compatible with Gutenberg by having volunteers test them in a sandboxed environment.</p>

<p>Out of the 4,213 plugins in the database, 84% have an unknown compatibility status. Out of 610 plugins that have been tested, 82% don&#x27;t include editor functionality.</p>

<p>Pendergast <a href=\"https://core.trac.wordpress.org/ticket/41316#comment:92\">supports the idea</a> of hosts collecting a wide range of testing data and turning it into actionable items for the team to work on. There&#x27;s also been some discussion on creating snapshots of plugin compatibility and filtering those results into Bachhuber&#x27;s project.</p>

<p>Chris Lema, Vice President of Products at LiquidWeb, <a href=\"https://core.trac.wordpress.org/ticket/41316#comment:98\">responded</a> in the trac ticket with a suggestion that the team place as much emphasis on the Learn More and Report Issues sections as the Try Gutenberg message. He also added a prototype screenshot of what the call-out could look like. <br /></p>

<img />
    Gutenberg Call Out Prototype by Chris Lema


<p>\"The reality is that people don&#x27;t read a lot, so people may not fully grasp the &#x27;testing&#x27; part given the proposed design,\" Lema said. \"When there are equal weight to the design, the message also carries with it the same equality.\"</p>

<p>One of the best suggestions I&#x27;ve read comes <a href=\"https://core.trac.wordpress.org/ticket/41316#comment:98\">from Bachhuber</a>. He suggests displaying the prompt to a small percentage of WordPress sites to prevent thousands of users from re-reporting known issues with Gutenberg. It would also help lessen the load on the support forums.</p>

<p>One of my main concerns with the call-out is the lack of upfront information to the user that it is beta software and it could cause adverse affects on their site. Lema&#x27;s prototype does a great job of informing the user of this possibility and a link to known issues is a great enhancement. What do you think?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Apr 2018 00:13:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Matt: Goose-down Nape\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48011\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"https://ma.tt/2018/04/goose-down-nape/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1378:\"<p>There was a <a href=\"https://www.nytimes.com/2018/03/28/magazine/poem-the-nod.html\">beautiful poem by Kayo Chingonyi in the New York Magazine this week</a> titled The Nod:</p>

<blockquote class=\"wp-block-quote\">
    <p>When we’re strangers that pass each other<br />in the street, it will come down to this tilt<br />of the head — acknowledging another<br />version of events set in a new-build<br />years from now, a mess of a place filled<br />with books and records, our kids thick as thieves<br />redefining all notions of mischief.</p>
    <p>Perhaps our paths will cross in a city<br />of seven hills as the light draws your face<br />out from the bliss of anonymity.<br />Maybe you’ll be stroking the goose-down nape<br />of a small child with eyes the exact shade<br />of those I met across a room at the start<br />of this pain-in-the-heart, this febrile dance.</p>
</blockquote>

<p>When I hear \"seven hills\" my mind immediately goes to Rome, then San Francisco, but <a href=\"https://en.wikipedia.org/wiki/List_of_cities_claimed_to_be_built_on_seven_hills\">Wikipedia has a helpful list of cities that claim to be built on seven hills</a>.</p>

<p>A friend pointed out <em>The Nod</em> is a <a href=\"https://www.familyfriendpoems.com/poem/the-invitation-by-oriah-mountain-dreamer\">fine complement to <em>The Invitation</em> by Oriah Mountain Dreamer</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Apr 2018 00:05:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"Post Status: Contextualized Learning in or around WordPress — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=44987\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://poststatus.com/contextualized-learning-in-or-around-wordpress-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1838:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p><span>In this episode, the dynamic Brian duo discuss the highly-anticipated return of WordSesh, the different ways in which we all learn the same, and some of the problems we face in skill building. The guys also spend time finding and contacting the addressable market around WordPress, characterizing a business as WordPress-focused vs providing WordPress services in the context of a broader market, and some of the nuances of providing contextualized services (whether they be training, consulting, or otherwise).</span></p>
<p></p>
<h3>Links</h3>
<ul>
<li><a href=\"https://www.nbcnews.com/health/health-news/scientists-say-they-ve-discovered-unknown-human-organ-could-help-n860601\">New human organ</a></li>
<li><a href=\"http://wordsesh.com/\">WordSesh.com</a></li>
<li><a href=\"https://wpsessions.com/\">WPSessions.com</a></li>
</ul>
<h3>Sponsor: OptinMonster</h3>
<p><a href=\"http://optinmonster.com\">OptinMonster</a> allows you to convert visitors into subscribers. You can easily create &amp; A/B test beautiful lead capture forms without a developer. Be sure to check out their new <a href=\"http://optinmonster.com/announcing-the-inactivitysensor-activity-logs-and-more/\">Inactivity Sensor</a> technology.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Apr 2018 19:31:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"Dev Blog: The Month in WordPress: March 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5632\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/news/2018/04/the-month-in-wordpress-march-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4323:\"<p>With a significant new milestone and some great improvements to WordPress as a platform, this month has been an important one for the project. Read on to find out more about what happened during the month of March.

</p>

<hr class=\"wp-block-separator\" />

<h2>WordPress Now Powers 30% of the Internet</h2>

<p>Over the last 15 years, the popularity and usage of WordPress has been steadily growing. That growth hit a significant milestone this month when <a href=\"https://w3techs.com/technologies/details/cm-wordpress/all/all\">W3Techs reported that WordPress now powers over 30% of sites on the web.</a></p>

<p>The percentage is determined based on W3Techs’ review of the top 10 million sites on the web, and it’s a strong indicator of the popularity and flexibility of WordPress as a platform.</p>

<p>If you would like to have hand in helping to grow WordPress even further, <a href=\"https://make.wordpress.org/\">you can get involved today</a>.</p>

<h2>WordPress Jargon Glossary Goes Live</h2>

<p>The WordPress Marketing Team has been hard at work lately putting together <a href=\"https://make.wordpress.org/marketing/2018/02/28/wordpress-jargon-glossary/\">a comprehensive glossary of WordPress jargon</a> to help newcomers to the project become more easily acquainted with things.</p>

<p>The glossary <a href=\"https://make.wordpress.org/marketing/2018/02/28/wordpress-jargon-glossary/\">is available here</a> along with a downloadable PDF to make it simpler to reference offline.</p>

<p>Publishing this resource is part of an overall effort to make WordPress more easily accessible for people who are not so familiar with the project. If you would like to assist the Marketing Team with this, you can follow <a href=\"https://make.wordpress.org/marketing/\">the team blog</a> and join the #marketing channel in the<a href=\"https://make.wordpress.org/chat/\"> Making WordPress Slack group</a>.</p>

<h2>Focusing on Privacy in WordPress</h2>

<p>Online privacy has been in the news this month for all the wrong reasons. It has reinforced the commitment of the GDPR Compliance Team to continue working on enhancements to WordPress core that allow site owners to improve privacy standards.</p>

<p>The team&#x27;s work, and the wider privacy project, spans four areas: Adding tools which will allow site administrators to collect the information they need about their sites, examining the plugin guidelines with privacy in mind, enhancing privacy standards in WordPress core, and creating documentation focused on best practices in online privacy.</p>

<p>To get involved with the project, you can <a href=\"https://make.wordpress.org/core/2018/03/28/roadmap-tools-for-gdpr-compliance/\">view the roadmap</a>, <a href=\"https://make.wordpress.org/core/tag/gdpr-compliance/\">follow the updates</a>, <a href=\"https://core.trac.wordpress.org/query?status=!closed&keywords=~gdpr\">submit patches</a>, and join the #gdpr-compliance channel in the <a href=\"https://make.wordpress.org/chat\">Making WordPress Slack group</a>. Office hours are 15:00 UTC on Wednesdays.</p>

<hr class=\"wp-block-separator\" />

<h2>Further Reading:</h2>

<ul>
    <li>The WordPress Foundation has published <a href=\"https://wordpressfoundation.org/2017-annual-report/\">their annual report for 2017</a> showing just how much the community has grown over the last year.</li>
    <li>The dates for WordCamp US <a href=\"https://2018.us.wordcamp.org/2018/03/13/announcing-wordcamp-us-2018/\">have been announced</a> — this flagship WordCamp event will be held on 7-9 December this year in Nashville, Tennessee.</li>
    <li>WordPress 4.9.5 is due for release on April 3 — <a href=\"https://make.wordpress.org/core/2018/03/21/wordpress-4-9-5-beta/\">find out more here</a>.</li>
    <li>Version 2.5 of Gutenberg, the new editor for WordPress core, <a href=\"https://make.wordpress.org/core/2018/03/29/whats-new-in-gutenberg-29th-march/\">was released this month</a> with a host of great improvements.</li>
    <li>WordSesh, a virtual WordPress conference, <a href=\"http://wordsesh.com/\">is returning in July this year</a>.</li>
</ul>

<p><em>If you have a story we should consider including in the next “Month in WordPress” post, please <a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\">submit it here</a>.</em><br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Apr 2018 08:00:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: WPWeekly Episode 310 – Community Management, PHP, and Hello Dolly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=79249&preview=true&preview_id=79249\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"https://wptavern.com/wpweekly-episode-310-community-management-php-and-hello-dolly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2325:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I discuss the news of the week including, the removal of offensive lyrics in Hello Dolly, a request for plugin developers to stop supporting legacy PHP versions, and changes coming in WordPress 4.9.5.</p>
<p>We also talk about community management, the difference between comments and forums, and finally, John shares his concerns on how the Gutenberg call-out prompt is being built into core.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/a-plea-for-plugin-developers-to-stop-supporting-legacy-php-versions\">A Plea For Plugin Developers to Stop Supporting Legacy PHP Versions</a><br />
<a href=\"https://wptavern.com/without-context-some-lyrics-inside-the-hello-dolly-plugin-are-degrading-to-women\">Without Context, Some Lyrics Inside the Hello Dolly Plugin Are Degrading to Women</a><br />
<a href=\"https://wptavern.com/why-gutenberg-and-why-now\">Why Gutenberg and Why Now?</a><br />
<a href=\"https://wptavern.com/noteworthy-changes-coming-in-wordpress-4-9-5\">Noteworthy Changes Coming in WordPress 4.9.5</a><br />
<a href=\"https://wptavern.com/in-wordpress-4-9-5-users-will-be-two-clicks-away-from-installing-and-activating-gutenberg-from-the-dashboard\">In WordPress 4.9.5, Users Will Be Two Clicks Away From Installing and Activating Gutenberg From the Dashboard</a></p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://wptavern.com/how-to-disable-push-notification-requests-in-firefox\">How to Disable Push Notification Requests in Firefox</a></p>
<p><a href=\"https://addons.mozilla.org/en-US/firefox/addon/facebook-container/\">Facebook Container Add-on for Firefox</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, April 4th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #310:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 Mar 2018 21:07:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"WPTavern: My Gutenberg Experience Thus Far\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78991\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wptavern.com/my-gutenberg-experience-thus-far\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5397:\"<p>Ive used Gutenberg for several months and during that time, there have been moments where I love it and situations where I&#x27;ve had to disable the plugin because of frustrating bugs. </p>

<p>One of the most frustrating aspects of using Gutenberg is the lack of support from the plugins I depend on.</p>

<h2>Publish Post Preview</h2>

<p>I use the <a href=\"https://wordpress.org/plugins/public-post-preview/\">Publish Post Preview</a> plugin to generate a preview link for posts so that people can see what it looks like before it&#x27;s published.</p>

<img />
    Publish Preview Checkbox in the Current Editor


<p>In the current editor, the checkbox to generate a link is in the Publish meta box. In Gutenberg, that option doesn&#x27;t exist. According to a <a href=\"https://wordpress.org/support/topic/compatibility-with-gutenberg/\">recent support forum post</a>, the author does not plan on making it Gutenberg compatible until there is a finalized API to extend the sidebar.</p>

<h2>Telegram for WordPress</h2>

<p>We use the <a href=\"https://wordpress.org/plugins/telegram-for-wp/\">Telegram for WordPress</a> plugin to automatically send published posts to our Telegram channel. The plugin adds a meta box that has options to send the post, configure the message structure, send a file, and display the featured image.</p>

<p>In Gutenberg, the meta box is open by default which provides access to those options. However, when I edit a published post, there are times when the meta box is closed and clicking the arrow to expand it doesn&#x27;t work. <em>Since the Send this post to channel</em> option is on by default, ﻿saving changes to the post will resend the post to Telegram subscribers. Something I don&#x27;t want to happen for simple edits. <br /></p>

<h2>Edit Flow</h2>

<p>We use <a href=\"https://wordpress.org/plugins/edit-flow/\">Edit Flow</a> to collaborate on posts and often use the Editorial Comments feature to provide feedback. In Gutenberg, the meta boxes for Editorial Comments and Notifications do not open when clicking the arrow. Therefor, we can&#x27;t use those features. <br /></p>

<img />
    <br /><br />Edit Flow Meta Boxes are Broken


<h2>After the Deadline</h2>

<p>I&#x27;m a fan of <a href=\"https://jetpack.com/support/spelling-and-grammar/\">After the Deadline</a> which is a proofreading module in Jetpack. It checks posts for spelling, grammar, and misused words. When activated, a button is added to the visual editor to perform the checks. This button is not available in Gutenberg, so those features are not available as well.</p>

<h2>Adding Images to Paragraphs is a Pain</h2>

<p>Adding images to paragraphs in Gutenberg is more cumbersome than it needs to be. In the current editor, all I have to do is place the cursor where I want to insert an image, add media, choose image size, align it, and I&#x27;m done.</p>

<p>In Gutenberg, you need to create an image block below the paragraph block, move the image block to the paragraph block, align it, and use handlebars on the corner of the image to resize it. </p>

<p>I realize that there are a few workflows that I&#x27;m going to have to change because of how Gutenberg works, but this workflow doesn&#x27;t make any sense to me, especially when I can&#x27;t insert images without creating a new block. Thankfully, the Gutenberg team is on top of it and is <a href=\"https://github.com/WordPress/gutenberg/pull/5794\">working on a solution</a> to add images within a paragraph block.</p>

<h2>Random Blank Paragraph Blocks</h2>

<p>I recently copied a large amount of text from a Google Doc and pasted it into Gutenberg and was surprised by how well it worked. Blocks were created in the right spots and I didn&#x27;t have to edit it much.</p>

<p>I opened the post in the classic editor so that I could use the proofreading feature and it mangled the post. I opened the post in Gutenberg again and noticed a bunch of empty paragraph blocks created in-between paragraph blocks.</p>

<p>This resulted in having to spend some time deleting the empty paragraph blocks and questioning whether I should avoid transferring posts between editors in the future.</p>

<h2>Tags Sometimes Appear Blank in the Meta Box</h2>

<p>When adding tags to posts, sometimes the tags appear blank although they show up on the front-end. Also, deleting tags sometimes doesn&#x27;t work. I click on the X and nothing happens in the back-end, but the tag will be removed from the front-end. <br /></p>

<img />
    Blank Tags in Gutenberg


<h2>Gutenberg Has a Lot of Rough Edges</h2>

<p>If this version of Gutenberg were merged into WordPress today, it would be a disaster. It&#x27;s clear that the project has a long way to go before being considered for merge into core. Most of the issues I&#x27;ve outlined in this post are known and are being addressed. <br /></p>

<p>Gutenberg is supposed to make everything we do in the current editor easier and more efficient. If it doesn&#x27;t, then I have to ask, what&#x27;s the point?</p>

<p>What concerns me the most about Gutenberg is plugin support. Some of the plugins I mentioned above are active on 10K sites or less but are important to the way I craft and publish content in WordPress. <br /></p>

<p> Without them, using Gutenberg is not a great experience and instead, makes me want to use the current editor where things simply work. <br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 Mar 2018 20:28:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"HeroPress: Giving Back In Your Own Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=2490\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:133:\"https://heropress.com/giving-back-in-your-own-community/#utm_source=rss&utm_medium=rss&utm_campaign=giving-back-in-your-own-community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3298:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2015/11/GoodtimeToBe-HeroPress-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull quote: It is a good time to be part of the global WordPress community: the costs are low, the developer community is strong, and job availability is at an all time high.\" /><p>I was delighted to find several years ago that there&#8217;s a thriving WordPress community in Nepal. Via Slack I got to meet Sakin Shrestha, and learned all about what their group is doing in Nepal to create jobs and keep the Nepali from having to leave the country to find work.</p>
<p>I recently found out that Sakin is finding a new way to give back to his community: <a href=\"https://sakinshrestha.com/events/announcing-my-new-venture-aksharaa-kindergarten/\">opening a kindergarten</a>. In order for any country to grow strong it has to have good education for its children, and Sakin is working to make that happen.</p>
<p>Read about how the Nepali WordPress community is working to build their own country.</p>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://heropress.com/essays/doing-our-part-for-the-community/\">Doing Our Part for the Community</a></p></blockquote>
<p></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Giving Back In Your Own Community\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Giving%20Back%20In%20Your%20Own%20Community&via=heropress&url=https%3A%2F%2Fheropress.com%2Fgiving-back-in-your-own-community%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Giving Back In Your Own Community\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fgiving-back-in-your-own-community%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fgiving-back-in-your-own-community%2F&title=Giving+Back+In+Your+Own+Community\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Giving Back In Your Own Community\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/giving-back-in-your-own-community/&media=https://heropress.com/wp-content/uploads/2015/11/GoodtimeToBe-HeroPress-150x150.jpg&description=Giving Back In Your Own Community\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Giving Back In Your Own Community\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/giving-back-in-your-own-community/\" title=\"Giving Back In Your Own Community\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/giving-back-in-your-own-community/\">Giving Back In Your Own Community</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Mar 2018 14:21:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:119:\"WPTavern: In WordPress 4.9.5, Users Will Be Two Clicks Away From Installing and Activating Gutenberg From the Dashboard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78827\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:129:\"https://wptavern.com/in-wordpress-4-9-5-users-will-be-two-clicks-away-from-installing-and-activating-gutenberg-from-the-dashboard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3920:\"<p>At the end of last month, Matt Cromwell, Head of Support and Community Outreach for <a href=\"https://givewp.com/\">GiveWP</a> and an administrator for the <a href=\"https://www.facebook.com/groups/advancedwp/\">Advanced WordPress Facebook group</a>, hosted a <a href=\"https://wptavern.com/matt-cromwell-hosts-matt-mullenweg-in-qa-gutenberg-interview\">question and answer session</a> about Gutenberg with Matt Mullenweg.</p>

<p>Mullenweg was asked a few times if he could provide a concrete date on when Gutenberg and WordPress 5.0 would be ready. While a date was not given, Mullenweg said, \"For those who want a concrete date, we will have one or two orders of magnitude more users of Gutenberg in April.\"</p>

<p>It&#x27;s now clear what he meant by that. WordPress 4.9.5, scheduled for release in April, will <a href=\"https://core.trac.wordpress.org/ticket/41316\">feature a call-out prompt</a> that has links to information about Gutenberg and a button to quickly install the plugin if user permissions allow. <br /></p>

<img />
    Gutenberg Call-out in WordPress 4.9.5


<p>The core team added a Try Gutenberg prompt in October of last year but <a href=\"https://wptavern.com/wordpress-4-9-beta-4-removes-try-gutenberg-call-to-action\">it was removed</a> in WordPress 4.9 Beta 4. After discussing the subject with Mullenweg, it was determined that Gutenberg was not ready for large-scale testing.</p>

<p>The prompt in WordPress 4.9.5 changes the button text based on the following scenarios.<br /></p>

<ul>
    <li>If Gutenberg is not installed, <em>and</em> the user can install plugins, the Install Today button is displayed.<br /></li>
    <li>If Gutenberg is installed but not activated, <em>and</em> the user can install plugins, the Activate Today button is displayed.<br /></li>
    <li>If Gutenberg is installed and activated, <em>and</em> the user can edit posts, the Try Today button is displayed.<br /></li>
</ul>

<p>If Gutenberg is not installed and the user can not install plugins, the button is hidden from view. If you&#x27;d like to hide the prompt from users, David Decker has <a href=\"https://github.com/deckerweb/remove-gutenberg-panel\">created a plugin</a> that&#x27;s available on GitHub that simply hides it from view.</p>

<p>One of the concerns about the prompt is the lack of warning of the risks involved using beta software on a live site. Gutenberg is beta software that&#x27;s still in development that could <a href=\"https://core.trac.wordpress.org/ticket/41316#comment:75\">adversely affect sites</a>. There is no warning on the call-out box and in two clicks, users can install and activate Gutenberg. <br /></p>

<p>Whether it&#x27;s Gutenberg or some other beta software, this general advice applies. Create a full backup of your site before installing and if possible, install it on a staging site first.</p>

<p>I predict that the volunteers who manage the WordPress.org support forums will have their hands full once WordPress 4.9.5 is released. The support team <a href=\"https://make.wordpress.org/support/2018/03/agenda-for-march-22nd-support-meeting/\">is preparing</a> by brainstorming user outcomes, common questions that may be asked, and potential pitfalls users experience after installing Gutenberg. <br /></p>

<p>If you&#x27;d like to give them a helping hand, check out the <a href=\"https://make.wordpress.org/support/handbook/\">Support Handbook</a> and if you have any questions, stop by the <a href=\"https://wordpress.slack.com/?redir=%2Fmessages%2Fforums%2F\">#forums</a> channel in <a href=\"https://make.wordpress.org/chat/\">Slack</a>.</p>

<p>The Gutenberg call-out has the potential to pave the way for large audiences to test major features in core without needing to use or install a beta branch of WordPress. However, this convenience comes with risks and while they can be reduced, WordPress needs to be up front and center to users about those risks.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 27 Mar 2018 22:55:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"WPTavern: Why Gutenberg and Why Now?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78707\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://wptavern.com/why-gutenberg-and-why-now\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:17921:\"<img />

<p>Tevya Washburn has been building websites for more than 20 years and building them on WordPress for 10. He bootstrapped his website maintenance and support company, <a href=\"http://wordx.press\">WordXpress</a>, that he’s worked on full-time for more than seven years.</p>

<p>Late last year he launched his first premium plugin, and presented at WordCamp Salt Lake City. He lives in Caldwell, ID and is the founding member of the WordPress Meetup group in Western Idaho. <br /></p>

<hr />

<p>It was only a few months ago that I knew almost nothing about WordPress’ new Gutenberg editor. I had a basic concept of what it was and this vague annoyance that it would mean I’d have to learn new things and probably put a lot of effort into making some sites or projects work with it.</p>

<p>I kept hearing all of the frustration and issues with Gutenberg itself and the lack of information on how to integrate with it. At <a href=\"https://wordx.press\">WordX</a>p<a href=\"https://wordx.press\">ress</a> we recently pivoted away from designing websites. When we designed them in the past, we used premium themes. I figured Gutenberg was the theme developer’s problem.<br /></p>

<p>I still had this feeling of dread though, knowing many of my favorite plugins might not add support for it. I also felt some apprehension that even if the themes we use did add support for it, they might have a lot of new bugs through the first few releases.</p>

<p>Then I launched my first WordPress plugin, <a href=\"https://starfishwp.com\">Starfish Reviews</a>, and suddenly they weren’t someone else’s problems anymore! Now I’d have to come up with a plan to integrate our plugin with Gutenberg. I installed the Gutenberg plugin on a test site where we were testing our plugin with the nightly releases of WordPress and started playing around with it.</p>

<p>I was pleasantly surprised at how intuitive and easy it was to use! Now it wasn’t (and isn’t) finished, so there were bugs and annoyances, but overall I was impressed.</p>

<p>Around the same time, I suggested we should have someone present on Gutenberg at our local meetup. My brief experience was more than what anyone else had, so the responsibility fell on me. Preparing for the presentation forced me to look at Gutenberg more carefully and pay more attention to the information and debate going on throughout the community.</p>

<p>I started reading blog posts, paying more attention in podcasts, and even looking at what was being said on Twitter. I watched the State of the Word at WordCamp US where the general tide in the feelings toward Gutenberg, seemed to turn, though many people still remain skeptical, critical, or antagonistic toward the project as a whole.</p>

<p>Today, I saw someone suggesting legal action if Gutenberg caused problems on their sites. That’s ridiculous on several levels, but shows that there’s still a lot of suspicion, frustration, and outright anger around Gutenberg.</p>

<p><em>A couple notes: 1. the graphs below are for illustration purposes only, they’re not meant to be accurate to any actual data. 2. If you prefer listening, you can </em><a href=\"https://www.youtube.com/watch?v=S4ZqrVJ465E\"><em>watch my screencast version</em></a><em> (13:12) of what follows. The message is the same, but differs in many aspects of presentation.</em></p>

<h2><strong>Finding the Why</strong></h2>

<p>Simon Sinek is known for <a href=\"https://www.youtube.com/watch?v=u4ZoJKF_VuA\">his Ted talk</a> where he explains that most people explain a new product or service by talking about ‘what’ it is and ‘how’ it works, but they rarely explain the ‘why’ behind it. The ‘why’ actually resonates with people the most. They want to understand the reason and beliefs behind it.</p>

<p>In my research, I couldn’t seem to find a clear answer to the most important question: “Why Gutenberg?” If I was going to present to people who knew little or nothing about it, I wanted to provide a reason why this major change was coming that might cause significant frustration, work, and pain for them.</p>

<img />

<p>I found a lot of ‘what’ and ‘how’ about Gutenberg. In some posts by <a href=\"https://ma.tt/2017/08/we-called-it-gutenberg-for-a-reason/\">Matt Mullenweg</a> and <a href=\"https://matiasventura.com/post/gutenberg-or-the-ship-of-theseus/\">Matías Ventura</a>, I found hints about ‘why’ Gutenberg existed, but no really clear, simple explanation of why this whole project was happening. Why would Matt and others want to seemingly force this major change on us all? Why does it have to be such a radical departure from the past? Why now?</p>

<p>I was certain the conspiracy theorists—who seem to believe that Automattic’s sole mission is to make their lives more miserable—were wrong. But what was the purpose? Could it really just be a <strong>me too</strong> attitude that left all of these brilliant minds feeling like they had to keep up with Squarespace and Medium? That didn’t seem to fit. Especially since Gutenberg is already leagues better than Squarespace’s convoluted visual editor.</p>

<h2><strong>Innovative Disruption</strong></h2>

<img />
    The Innovator&#x27;s Dilemma Book Cover


<p>Taking cues from those hints and suggestions, I started thinking about the innovative disruption model. It was popularized in business circles, starting in 1997 when the book “<a href=\"https://en.wikipedia.org/wiki/The_Innovator%27s_Dilemma\">The Innovator’s Dilemma</a>” was published by Clayton Christensen, a Harvard professor. His book was an expansion of an <a href=\"https://hbr.org/1995/01/disruptive-technologies-catching-the-wave\">earlier article</a> in the Harvard Business Review.</p>

<p>At the risk of oversimplifying the model, innovative disruption is what happens when an existing company who is the top dog (either in sales or market share) gets comfortable with their position at the top along with their revenue stream and quits innovating. They make small, incremental updates to their products or services to keep customers happy, but fail to look at the future of their industry.</p>

<p>This makes it easier for a startup or smaller, more innovative company to bring a new product or service to market that completely disrupts the existing market because it’s better, faster, cheaper. The established company doesn’t see the disruption coming because they feel secure in their large market share and steady sales revenue. They often respond with “why would anyone want that?” when approached with the new model that is about to completely upset their business model.</p>

<h2><strong>Blockbuster Gets Busted</strong></h2>

<p>The classic example of this is Blockbuster Entertainment, Inc. They had over 9,000 stores at one time, allowing people to rent VHS tapes and later, DVDs. They had a huge portion of the market all to themselves and it seemed nobody could compete with this juggernaut.</p>

<p>Then along came two small startups: Netflix and Redbox. Netflix comes along and says “we’re going to stream movies over the internet. That’s the future and the way everyone will want to consume movies and TV in the future. But since the internet is too slow right now, we’ll just start by mailing DVDs to people.”</p>

<p>Blockbuster looked at this and said, “the internet is <em>way</em> too slow to stream movies. That’s ridiculous! Who wants to wait two weeks to get a movie in the mail?! Hahaha! Stupid startup, they’re wasting their money and energy.” In hindsight this seems ridiculous. At the time, most people would have agreed with Blockbuster.</p>

<p>As you know, people started changing the way they rented movies. Once they tried it, they were happy to pay a subscription and use a queue to get DVDs delivered in the mail. Ultimately, making the decision of what to watch ahead of time was better than wandering through a cathedral of DVDs only to find the one you wanted to watch has already been checked out.</p>

<p>Consumer internet bandwidth speeds quickly caught up. Netflix even invented some of the technologies that provide high quality streaming video to your home. Now, most of us can’t imagine having to go to the store to rent a physical copy of a movie. And those that can, get them from a Redbox kiosk that has a limited selection, but is much quicker and easier than a video store. Netflix now has a larger market share than Blockbuster ever did, with <em>zero</em> physical locations.</p>

<img />

<p>There are exactly nine Blockbuster stores still operating, mostly in Alaska. From 9,000 down to nine in only a few years! This is what failing to innovate does. This is how comfort and confidence in market share and sales blinds people and organizations to the coming innovations that will disrupt their market.</p>

<h2><strong>Literacy, Disruption, and Gutenberg</strong></h2>

<p>Disruptive innovation doesn’t apply just in business. I have a Bachelor’s degree in history. So one example I love to use is how literacy and education ultimately toppled monarchies and traditional power structures in favor of republics and representative democracy.</p>

<p>The choice of Gutenberg as the name of the new WordPress editor seems prescient in this example as well. The name was one of the clues that led me to answer the ‘why?’ question. It was Johannes Gutenberg and his movable type printing press that was the innovative disruption that changed everything!</p>

<p>Before that, the vast majority of people in Europe were illiterate and uneducated. The scarcity of books and written material made it impractical and prohibitively expensive for most people to learn to read. It also allowed the Church and aristocracy to control the opportunity to become literate. That meant the rich and powerful were the gatekeepers of knowledge. Most riots and uprisings to this point were about hunger.</p>

<p>The Gutenberg press changed all that. Suddenly books could be mass-produced faster, cheaper, better than they ever could before. Literacy caught on like a wildfire. The power structures thought they could control it and maintain the status quo. They outlawed printing without state approval and did many other things to limit the spread of ideas through printed materials.</p>

<p>But it was too late, the power to spread ideas that the printing press provided was much too viral. Many printing presses were operated illegally, then destroyed when they were discovered by authorities.</p>

<img />

<p>The tipping point had been reached though. The ability to read and spread ideas via printed documents was much more powerful than the money, soldiers, and weapons of the monarchy. Though hunger might have sparked riots and uprisings from this time on, those tiny flames were fanned into an inferno of revolution by ideas spread through printed words. <a href=\"https://en.wikipedia.org/wiki/Thomas_Paine\">Thomas Paine</a>’s Common Sense is a great example if you want to learn more about concrete examples.</p>

<h2><strong>The Pain of Disrupting Yourself</strong></h2>

<p>I don’t have a business degree, but from my understanding, <em>The Innovator’s Dilemma</em> can be simplified down to this: to survive, and stay on top, a company (or software, or community) must innovate. It <em>can not</em> be incremental innovation. It <em>must</em> be innovation that disrupts the company’s core product or business model, even to the point of entirely replacing it.</p>

<p>Blockbuster tried some Redbox-like and Netflix-like solutions, but they were too little, too late. The only way they could have survived would have been to disrupt their own business model and service. They would have had to say, “in five years we will close all 9k stores and completely shift our business to providing video online.”</p>

<p>Who does that? Who thinks “we have built an empire, but we have to completely change it and replace it all over again”? That’s “The Innovator’s Dilemma” that the book’s title refers to: it’s incredibly difficult to think in those terms when you’re on the top. It’s nearly impossible to say, “we have to disrupt ourselves. We must compete with our own business and products and services.” But ultimately it’s the only way to survive.</p>

<p>…Or you can buy an innovative company and let them disrupt your main business. Did you know Blockbuster had the <a href=\"http://www.businessinsider.com/blockbuster-ceo-passed-up-chance-to-buy-netflix-for-50-million-2015-7\">chance to buy Netflix</a> for $50 million in 2000? It was pocket change, but they passed because it was a very small, niche business.</p>

<p>Had they bought Netflix and allowed it to continue innovating and disrupting their core retail rental model, Blockbuster might still be around. It wouldn’t have 9k retail stores, but it would have an even larger market share than it ever did renting DVDs.</p>

<img />

<p>In either case, the process is painful. That’s why it’s called disruptive. Not because it’s a walk on the beach or small speed bump, but because it takes a lot of work and forward-thinking and causes a lot of pain to create and implement.</p>

<p>If you are the market leader, you can’t rest on your previous success. You have to change everything once again, like you did to get to where you are now. Despite the pain of doing it, you have to invest yourself and your resources into hard work and difficult questions and challenging thinking that goes directly counter to our natural tendency as humans. If you want to stay on top, it’s the only way.</p>

<h2><strong>WordPress is Ripe for Disruption</strong></h2>

<p>WordPress has a 30% market share right now. It won’t be long before 1 out of every 3 websites is built on WordPress. No other platform is even close.</p>

<p>As WordPress professionals and community members, it seems like we have all the momentum and benefits of being the leader. “Surely nothing could displace WordPress!” That’s what Blockbuster said. That’s what monarchs of past ages said. The truth is simple: “yes, something could. In fact, something will, if WordPress doesn’t innovatively disrupt itself.”</p>

<img />

<p>Is it going to be painful? Yes. Is it going to cause a lot of work and effort on the part of the community? Yes! Absolutely. But the alternative is to learn a totally new platform in five years when WordPress dies like Blockbuster did. You think this change is going to be difficult? Try throwing out WordPress entirely and moving your website(s) to an entirely new platform. Because that’s the alternative.</p>

<h2><strong>Good Arguments Against Gutenberg</strong></h2>

<p>I see many people listing a string of bugs in the Gutenberg UI/UX and concluding that Gutenberg shouldn’t exist. I see others critiquing the underlying technologies and claiming that’s evidence that Gutenberg is entirely wrong.</p>

<p>I’m sorry, but those arguments are entirely invalid. They may be great arguments for how Gutenberg needs to change or improve, but they are <em>not</em> valid arguments against the existence of Gutenberg and its inclusion in core.</p>

<p>Hopefully, I’ve made it clear that WordPress is in dire need of innovation. If that’s true, then as I see it, there’s only one really great argument against Gutenberg. As one person in one of the meetups I presented at put it: “is it the right innovation?”</p>

<p>That&#x27;s the crux of the whole thing: <strong>WordPress must innovate to survive</strong>. Matt Mullenweg and the entire Gutenberg team have looked at the past and the future and decided that a better, faster, easier user interface and experience, are the disruptive innovations that WordPress needs to survive.</p>

<p>You can argue that it’s not, that there’s some other innovation that will completely change WordPress and thereby save it from disruption by outside forces. And that&#x27;s a totally valid argument to make. But in my opinion, <strong>you can’t argue that continued, incremental changes are enough.</strong> You can’t argue that the path we’ve been on the last five years is going to keep WordPress on top for the next five years. It simply won’t.</p>

<h2><strong>I Like Gutenberg, but I Love What it’s Doing</strong></h2>

<p>In my experience thus far, I like Gutenberg. I believe it is the right disruptive innovation WordPress needs at this time. It will make WordPress easier to use and help its underpinnings be ready for the future. Being easy to use is what got WordPress where it is today.</p>

<p>It’s not very easy to use any more. There are significantly easier options out there, that could disrupt WordPress and replace it. I think Gutenberg will allow WordPress to disrupt itself and keep ahead of other disruptive innovations. It will save WordPress and allow us all to keep using it and building our businesses on it for another 10 years into the future.</p>

<p>I like Gutenberg, but I really love what Gutenberg means, what it represents, and what it&#x27;s doing. Gutenberg is bigger than just a new post editor, it shows that the leaders of the WordPress community are willing to make hard decisions and innovate even when it means disrupting their own work and previous innovations.</p>

<img />

<p>I have huge respect for the Gutenberg team, who have not only had to rethink everything and do all those difficult things I referred to before, but have had to do it all very publicly, while navigating a gauntlet of criticism, personal attacks, and much more.</p>

<p>I hope this post shows my thanks and newfound appreciation for what they’re doing and going through. Flipping the phrase from <em>The Dark Knight,</em> the members of the Gutenberg team are “the heroes the WordPress community needs right now, even if they’re not the ones we deserve.”</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 26 Mar 2018 18:20:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"Post Status: The Future of Content Distribution — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=44599\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://poststatus.com/future-content-distribution-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2385:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p><span>This week the Brians put their brains together and discuss content distribution across various mediums and platforms as well as subscriptions for both digital and physical products. The conversation shifts between different tooling and platforms that exist for enabling content distribution as well as some of the societal shifts that have shaped how we share and consume both content and products. </span></p>
<p><span>This is a good episode for anyone who is developing sites and selling solutions around content distribution or subscriptions as well as anyone who is running (or looking to run) a business based around a subscriber model (paid or otherwise).</span></p>
<p></p>
<h3>Links</h3>
<ul>
<li><a href=\"https://make.wordpress.org/marketing/2018/02/28/wordpress-jargon-glossary/\">WP Jargon Glossary</a></li>
<li><a href=\"https://www.blog.google/topics/google-news-initiative/announcing-google-news-initiative/\">Google News subscription initiative</a></li>
<li><a href=\"https://woocommerce.com/2018/02/succeed-with-woocommerce-subscriptions-technical-tips/\">Brent&#8217;s blog post</a></li>
<li><a href=\"https://woocommerce.com/products/teams-woocommerce-memberships/\">Teams for WooCommerce Memberships</a></li>
<li><a href=\"https://www.recode.net/2017/12/13/16771646/target-shipt-acquisition-price-550-million-grocery-delivery-same-day\">Target acquires Shipt</a></li>
</ul>
<h3>Sponsor: Pagely</h3>
<p><a href=\"https://pagely.com\"><span>Pagely</span></a><span> offers best in class managed WordPress hosting, powered by the Amazon Cloud, the Internet’s most reliable infrastructure. Post Status is proudly hosted by Pagely. Thank you to </span><a href=\"https://pagely.com\"><span>Pagely</span></a><span> for being a Post Status partner</span></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 26 Mar 2018 13:24:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"BuddyPress: 10 years\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=271550\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://buddypress.org/2018/03/10-years/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5437:\"<p>In 2008 (just 10 short years ago) <a href=\"https://profiles.wordpress.org/apeatling\">Andy Peatling</a> made the very first code-commit to the newly adopted BuddyPress project, joining bbPress, GlotPress, and BackPress at the time. As most of you can probably imagine, BuddyPress was a different piece of software back then, trying to solve a completely different decade&#8217;s worth of problems for a completely different version of WordPress.</p>
<p>BuddyPress was multisite only, meaning it did not work on the regular version of WordPress that most people were accustomed to installing. It needed to completely take over the entire website experience to work, with a specific theme for the primary part of your site, and blog themes for user profiles and everything else.</p>
<p>There was a lot to love about the original vision and version of BuddyPress. It was ambitious, but in a clever kind of way that made everyone tilt their heads, squint their eyes, and ponder what WordPress was capable of. BuddyPress knew exactly what it was trying to do, and owned it without apologies.</p>
<p>It touted itself as a &#8220;Social Network in a box&#8221; at a time when MySpace was generating 75.9 million <em>unique</em> visitors per month, so if you couldn&#8217;t imagine how different BuddyPress may have been before, imagine how excited everyone was at the idea of owning their own MySpace.</p>
<p>Since then, Andy invited <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone</a>, <a href=\"https://profiles.wordpress.org/djpaul\">Paul</a>, and <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">me</a> to help lead the project forward, and in-turn we&#8217;ve invited several other prolific BuddyPress contributors to help with every aspect of the project, website, design, and so on.</p>
<p>The BuddyPress team has grown in a few different ways. Most recently, we&#8217;ve added <a href=\"https://profiles.wordpress.org/espellcaste\">Renato Alves</a> to the team to help with WP-CLI support. Renato is a long-time contributor who stepped up big-time to really own the WP-CLI implementation and finally see it through to the end.</p>
<p><a href=\"https://profiles.wordpress.org/slaffik\">Slava Abakumov</a> lead the 2.8 release, and we finally met in person for the very first time just last week at WordCamp Miami. He&#8217;s another long-time contributor who has always had the best interests of the project in mind and at heart.</p>
<p><a href=\"https://profiles.wordpress.org/offereins\">Laurens Offereins</a> has been helping fix BuddyPress bugs and work on evolving features since version 2.1, and while we haven&#8217;t met in person <em>yet</em>, I look forward to it someday!</p>
<p><a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a> (who you may recognize from bbPress) also works a bit on BuddyPress, largely around tooling &amp; meta related things, but he&#8217;s fully capable and will jump in and help anywhere he can, be it the forums or features.</p>
<p><a href=\"https://profiles.wordpress.org/mercime\">Mercime</a> would prefer I not blather on endlessly here about how important she is, or how much I appreciate her, or anything like that, so please forget I mentioned it.</p>
<p><a href=\"https://profiles.wordpress.org/hnla\">Hugo Ashmore</a> has spent the past 2 years completely rebuilding the default template pack. This is an absolutely huge undertaking, and everyone is really excited about sunsetting ye olde <code>bp-legacy</code>.</p>
<p><a href=\"https://profiles.wordpress.org/karmatosed\">Tammie Lister</a> has moved on to work on the enormously important and equally ambitious <a href=\"https://wordpress.org/plugins/gutenberg/\">Gutenberg</a> project. Tammie is wonderful, and doing a great job crafting what the future of democratizing publishing is.</p>
<p>Lastly, a few of our veteran team members took sabbaticals from contributing to BuddyPress in the past few years, which I see as an opportunity to return with fresh ideas and perspectives, or maybe moving onto new &amp; exciting challenges. This is a good, healthy thing to do, both for oneself and the project. Space makes the heart grow fonder, and all that.</p>
<hr />
<p>A small aside but worth saying here &amp; now, is that leading an open-source project is everything you think it is (or maybe have read already that it is) and like a million other things that are hard to understand until you understand. The one constant (and subsequently the hardest and funnest part) is how to provide opportunities for personal growth, without prohibiting contributions, while also doing what&#8217;s best for the greater vision of the project itself, amongst a completely remote group of bespoke volunteers. I think Paul, Boone, and I do OK at this, but we are always learning and adjusting, so please reach out to us if there is anything we can do differently or better.</p>
<hr />
<p>BuddyPress is my personal favorite piece of software. It&#8217;s my favorite community. I wake up excited every day because of what it can do and who it does it for. Put another way, I love what we make it do and who we make it for: ourselves, one another, each other, and you.</p>
<p>Cheers to 10 years, and here&#8217;s to another 10!</p>
<p><img class=\"alignnone wp-image-271562 size-full\" src=\"https://buddypress.org/wp-content/uploads/1/2018/03/Screen-Shot-2018-03-25-at-4.38.12-PM.png\" alt=\"\" width=\"898\" height=\"452\" /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 25 Mar 2018 22:54:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"JJJ\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"WPTavern: Noteworthy Changes Coming in WordPress 4.9.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78611\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wptavern.com/noteworthy-changes-coming-in-wordpress-4-9-5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2401:\"<p>WordPress 4.9.5 Beta 1 <a href=\"https://make.wordpress.org/core/2018/03/21/wordpress-4-9-5-beta/\">is available</a> for testing and brings with it 23 bug fixes and improvements. A release candidate is scheduled for release on March 20th and a final release on April 3rd. Here are some notable changes you can expect in the release.</p>

<h3>\"Cheatin’ uh?\" Error Message is Replaced</h3>

<p>The \"Cheatin’ uh?\" error message has existed in WordPress for years and for some, is insulting. The error doesn&#x27;t explain what went wrong and accuses the user of trying to cheat the system.</p>

<img />
    Cheatin&#x27; Uh Error Message<br />


<p>Eric Meyer highlighted the error in <a href=\"https://wordpress.tv/2016/06/24/eric-a-meyer-design-for-real-life/\">his keynote</a> at WordCamp North East Ohio in 2016, when talking about Designing for Real Life. He also <a href=\"https://core.trac.wordpress.org/ticket/38332#comment:11\">contributed to the ticket</a> with suggestions on how to improve the wording.</p>

<p>In WordPress 4.9.5, the error <a href=\"https://core.trac.wordpress.org/ticket/38332\">has been changed</a> to more meaningful messages depending on the error that occurs.</p>

<h3>Recommended PHP Version Increased to 7.2</h3>

<p>Inside of the readme file in WordPress, the current recommended PHP version is 7.0. This version of PHP reached end of life last December. In 4.9.5, the recommend version is PHP 7.2. This is the same version that is <a href=\"https://wordpress.org/about/requirements/\">recommended on WordPress.org</a>.</p>

<h3>Offensive Lyrics Removed From Hello Dolly</h3>

<p>As we covered <a href=\"https://wptavern.com/without-context-some-lyrics-inside-the-hello-dolly-plugin-are-degrading-to-women\">earlier this week</a>, some of the lines displayed in the dashboard from the Hello Dolly plugin are inappropriate without context. In 4.9.5, the plugin will no longer display those lines.</p>

<p>There&#x27;s a possibility that in the future, there will be a musical note icon or symbol placed next to the line to indicate it&#x27;s from a song. In addition, the lyrics are more in line with Louis Armstrong&#x27;s recording.</p>

<p>To see a full list of changes in WordPress 4.9.5, you can <a href=\"https://core.trac.wordpress.org/query?status=closed&milestone=4.9.5&group=component\">view a full list</a> of closed tickets on Trac. </p>

<p><br /></p><br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 22 Mar 2018 21:32:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WPTavern: WPWeekly Episode 309 – All AMPed Up\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=78601&preview=true&preview_id=78601\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wptavern.com/wpweekly-episode-309-all-amped-up\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2180:\"<p>In this episode, I&#8217;m joined by <a href=\"https://medinathoughts.com/\">Alberto Medina</a>, Developer Advocate working with the Web Content Ecosystems Team at Google, and <a href=\"https://weston.ruter.net/\">Weston Ruter</a>, CTO of XWP. We have a candid conversation about <a href=\"https://www.ampproject.org/\">Google&#8217;s AMP Project</a>. We start by learning why the project was created, what its main goal is, and the technology behind it.</p>
<p>We also dive into some of the controversy surrounding the project by discussing whether or not AMP is a threat to the Open Web. Medina and Ruter provide insight into AMP&#8217;s transformation from focusing on the mobile web to providing a great user experience across the entire web. Last but not least, we learn about the relationship between Automattic, XWP, and the AMP team and how it&#8217;s helping to shape the future of the project.</p>
<h2>Notable Links Mentioned:</h2>
<p><a href=\"https://wordpress.org/plugins/amp/\">AMP for WordPress Plugin</a><br />
<a href=\"https://github.com/Automattic/amp-wp\">AMP for WordPress GitHub Repository</a><br />
<a href=\"https://github.com/ampproject\">AMP GitHub Repository</a><br />
<a href=\"https://www.youtube.com/watch?v=GGS-tKTXw4Y\">Video presentation from AMP Conf 2018 showcasing the work that&#8217;s gone into the AMP for WordPress plugin</a><br />
<a href=\"https://www.ampproject.org/latest/blog/standardizing-lessons-learned-from-amp/\">Official blog post outlining the future of the AMP Project</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, March 28th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #309:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 22 Mar 2018 14:34:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Matt: Don’t Like Change\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47998\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"https://ma.tt/2018/03/dont-like-change/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:407:\"<blockquote class=\"wp-block-quote\">
    <p>If you don&#x27;t like change, you&#x27;re going to like irrelevance even less.</p><cite>General Eric Shinseki</cite></blockquote>

<p>I actually heard this on the <a href=\"https://www.fs.blog/2015/06/michael-lombardi/\">Farnam Street podcast with Patriots coach Michael Lombardi</a>, but it seems like General Shinseki said it first so attributing it there.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 22 Mar 2018 00:01:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"HeroPress: Keeping Community Alive\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=2487\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:113:\"https://heropress.com/keeping-community-alive/#utm_source=rss&utm_medium=rss&utm_campaign=keeping-community-alive\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3425:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2016/09/090716-David-Laietta-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: Be a pillar of support for your community.\" /><p>In the last year or so I&#8217;ve been a lot more involved with the business side of WordPress than the community side. The business side isn&#8217;t nearly as loving and supportive as the community side, and some of that is out of necessity. Business is business, and people need to eat.</p>
<p>The problem comes when people get so focused on the business side of things that they forget they&#8217;re dealing with people. Recently <a href=\"https://twitter.com/carlhancock/status/971182969514799105\">Carl Hancock mentioned on twitter</a> that there are things that happen in business in the WordPress community that would horrify people. I don&#8217;t know who those people are that do those things, and I don&#8217;t even know what the things are, but I have hope that the community can be bigger and better than that.</p>
<p>There will always be selfish jerks who abuse the system for personal gain, but I have hope that the WordPress community can generally rise above that, and perhaps even change the hearts of poor players.</p>
<p>This week&#8217;s HeroPress replay is from David Laietta, about how our community changes lives.</p>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://heropress.com/essays/a-community-of-acceptance/\">A Community of Acceptance</a></p></blockquote>
<p></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Keeping Community Alive\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Keeping%20Community%20Alive&via=heropress&url=https%3A%2F%2Fheropress.com%2Fkeeping-community-alive%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Keeping Community Alive\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fkeeping-community-alive%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fkeeping-community-alive%2F&title=Keeping+Community+Alive\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Keeping Community Alive\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/keeping-community-alive/&media=https://heropress.com/wp-content/uploads/2016/09/090716-David-Laietta-150x150.jpg&description=Keeping Community Alive\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Keeping Community Alive\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/keeping-community-alive/\" title=\"Keeping Community Alive\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/keeping-community-alive/\">Keeping Community Alive</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 21 Mar 2018 15:39:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: A Plea For Plugin Developers to Stop Supporting Legacy PHP Versions\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78533\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"https://wptavern.com/a-plea-for-plugin-developers-to-stop-supporting-legacy-php-versions\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2188:\"<p>Iain Poulson has <a href=\"https://deliciousbrains.com/legacy-php-version-support/\">published a thoughtful request</a> on the Delicious Brains blog asking WordPress plugin developers to stop supporting legacy PHP versions. He covers some of the benefits of developing with newer versions of PHP, what Delicious Brains is doing with its plugins, and using the <a href=\"https://make.wordpress.org/plugins/2017/08/29/minimum-php-version-requirement/\">Requires Minimum PHP Version header</a> in readme.txt.<br /></p>

<blockquote class=\"wp-block-quote\">
    <p>While we wait for the Trac discussion to roll on and the WordPress development wheels to turn we can take action ourselves in our plugins to stop them working on installs that don’t meet our requirements. </p>
    <p>We do this in our own plugins where it is strictly necessary (<a href=\"https://deliciousbrains.com/wp-offload-s3/\">WP Offload S3</a> relies on the Amazon Web Services S3 SDK, which requires PHP 5.3.3+ and will we will <a href=\"https://deliciousbrains.com/wp-offload-s3/doc/php-version-requirements/\">move to PHP 5.5</a> in the future), and the more plugins that do this out of choice will help move the needle further.</p><cite>Iain Poulson <br type=\"_moz\" /></cite></blockquote>

<p>Poulson mentions the <a href=\"https://github.com/WordPress/servehappy\">ServeHappy project</a> in his post and it&#x27;s worth a mention here as well. The ServeHappy project was <a href=\"https://make.wordpress.org/core/2018/01/09/servehappy-roadmap/\">launched earlier this year</a> by a group of volunteers.</p>

<p>Its main goal is to reduce the number of WordPress installs running on unsupported PHP versions through education, awareness, and tools to help users update their site&#x27;s PHP versions.</p>

<p>This project is in need of contributors. If you&#x27;re interested, join the #core-php channel on <a href=\"https://make.wordpress.org/chat/\">WordPress Slack</a>. The team has meetings every Monday at 11:00 AM EDT. You can also follow the <a href=\"https://make.wordpress.org/core/tag/core-php/\">#core-php tag</a> on the Make WordPress.org Core site where links to chat logs and meeting summaries are published. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 21 Mar 2018 00:31:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: How to Disable Push Notification Requests in Firefox\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78475\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wptavern.com/how-to-disable-push-notification-requests-in-firefox\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1246:\"<p>Have you noticed how many sites ask if you want to enable push notifications? I&#x27;ve answered no to every request but thanks <a href=\"https://twitter.com/tkraftner/status/976116234365358081\">to a tip</a> suggested by Thomas Kräftner, you can disable requests from appearing altogether in Firefox.</p>

<p>Last week, Mozilla <a href=\"https://www.mozilla.org/en-US/firefox/59.0/releasenotes/\">released Firefox 59.0</a> and added a <a href=\"https://support.mozilla.org/en-US/kb/push-notifications-firefox\">new privacy feature</a> that allows users to block sites from sending push notification requests. To enable it, open the Options panel in Firefox 59.0 and click the Privacy&amp;Security tab.<br /></p>

<p>Scroll down to the Permissions section. Click on the Settings button for Notifications and check the box that says <em>Block new requests asking to allow notifications.﻿</em></p>

<img />
    Settings panel for Notifications


<p>Click the Save Changes button and enjoy one less thing interrupting your browsing experience.  To accomplish the same thing in Chrome, follow <a href=\"https://fieldguide.gizmodo.com/how-to-block-super-annoying-website-notification-reques-1797499616\">this tutorial published by Field Guide</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 20 Mar 2018 23:32:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"WPTavern: Without Context, Some Lyrics Inside the Hello Dolly Plugin Are Degrading to Women\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78372\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"https://wptavern.com/without-context-some-lyrics-inside-the-hello-dolly-plugin-are-degrading-to-women\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2914:\"<p>There have been <a href=\"https://core.trac.wordpress.org/ticket/11538\">many discussions</a> over the years on whether or not <a href=\"https://wordpress.org/plugins/hello-dolly/\">Hello Dolly</a> should be unbundled with WordPress. Seven years ago, it was <a href=\"https://core.trac.wordpress.org/ticket/15769\">argued</a> that the lyrics are copyrighted and could potentially violate the GPL license.</p>

<p>The latest issue with Hello Dolly is that some lyrics that appear in users dashboards with the plugin activated can be degrading to women without context.</p>

<p><blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Find her an empty lap, fellas.<br /><br />Wondering about my <a href=\"https://twitter.com/WordPress?ref_src=twsrc%5Etfw\">@WordPress</a> dashboard. Apparently they\'re lyrics. <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f643.png\" alt=\"🙃\" class=\"wp-smiley\" /> <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f644.png\" alt=\"🙄\" class=\"wp-smiley\" /> <a href=\"https://t.co/oxNU9czr5X\">pic.twitter.com/oxNU9czr5X</a></p>&mdash; Michelle Felt (@michellefelt) <a href=\"https://twitter.com/michellefelt/status/974060334502719488?ref_src=twsrc%5Etfw\">March 14, 2018</a></blockquote></p>

<p>Two examples are:</p>

<ul>
    <li>Find her an empty lap, fellas</li>
    <li>Find her a vacant knee, fellas</li>
</ul>

<p>Joe McGill has <a href=\"https://core.trac.wordpress.org/ticket/43555\">created a trac ticket</a> proposing that those two lines be removed. \"The Hello Dolly plugin has been bundled in WordPress for many years, being a simple example of how to build a plugin for WordPress while also adding a bit of whimsy to admin,\" he said.</p>

<p>\"However, there are several passages of text from this song which are inappropriate to display without any context to people using WordPress—particularly as the WordPress project seeks to promote inclusivity for all.\"</p>

<p>The discussion within the ticket suggests creating a black list or replacing the lyrics with less offensive versions. In many of the Google search results for Hello Dolly lyrics by Jerry Herman, shows that the lyrics inside the plugin and those in the song are different.</p>

<p>The lyrics say, \"Find me a vacant knee, fellas.\" In a <a href=\"https://www.youtube.com/watch?v=RETJfq1U_gg\">video on YouTube</a> of Hello Dolly featuring Sarah Gardner singing the lyrics, she clearly says \"Find her an empty lap, fellas.\" In a YouTube video of <a href=\"https://www.youtube.com/watch?v=kmfeKUNDDYs\">Louis Armstrong singing Hello Dolly live</a>, he says \"Find her an empty lap, fellas.\"<br /></p>

<p>Putting aside the debate of which version of the lyrics are used, displaying the text above without context can and is seen as degrading women. At a time when WordPress and its community are doing what it can to be more inclusive, changing or removing the lyrics seems like an easy win. </p>

<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 16 Mar 2018 20:45:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"WPTavern: Watch WordCamp Miami 2018 Via Free Livestream\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78359\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"https://wptavern.com/watch-wordcamp-miami-2018-via-free-livestream\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:618:\"<p>Tickets for the event may be sold out, but you can watch the event from anywhere thanks to a <a href=\"https://2018.miami.wordcamp.org/live/\">free livestream</a>. The stream starts today and covers both the E-Commerce and developers workshops. The stream begins tomorrow at 8:30AM EDT with separate links to <a href=\"https://bizstreams.fiu.edu/Mediasite/Play/05a25d9473ca4c919b5f29aa426bb0c01d?catalog=f4f4edd3-2dee-4302-91c6-d77c1da5f437\">morning</a> and <a href=\"https://bizstreams.fiu.edu/Mediasite/Play/30c9fdc284ce46648866ed715fd3b90d1d?catalog=f4f4edd3-2dee-4302-91c6-d77c1da5f437\">afternoon</a> sessions. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 16 Mar 2018 16:18:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Let’s Encrypt Wildcard Certificates Are Now Available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78287\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wptavern.com/lets-encrypt-wildcard-certificates-are-now-available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1765:\"<p>In July of last year, <a href=\"https://letsencrypt.org/\">Let&#x27;s Encrypt</a> announced that it would begin <a href=\"https://letsencrypt.org/2017/07/06/wildcard-certificates-coming-jan-2018.html\">issuing Wildcard certificates</a> for free in January of 2018. Although a little late, the organization <a href=\"https://community.letsencrypt.org/t/acme-v2-and-wildcard-certificate-support-is-live/55579\">has announced</a> that Wildcard certificate support is now live.</p>

<p>In addition to these certificates, the organization has updated its <a href=\"https://datatracker.ietf.org/wg/acme/about/\">ACME protocol</a> to version 2.0. ACMEv2 is required for clients that want to use Wildcard certificates.</p>

<p>Wildcard certificates enable site administrators to secure all sub domains with a single certificate. This can be especially convenient for WordPress Multi-site networks.</p>

<p>Let&#x27;s Encrypt is working on transitioning all clients and subscribers to ACMEv2, though it hasn&#x27;t set a time table on when it will expire the ACMEv1 API. </p>

<p>In July of 2017, Let&#x27;s Encrypt was securing 47 million domains. Today, the organization is <a href=\"https://letsencrypt.org/stats/\">securing nearly 70 million domains with 54 million certificates</a>. In the United States, nearly 80% of sites loaded in Firefox are through HTTPS.</p>

<p>Let&#x27;s Encrypt is an open certificate authority that&#x27;s part of the non-profit <a href=\"https://letsencrypt.org/isrg/\">Internet Security Research Group</a>. It&#x27;s mission is to make 100% of the web HTTPS. Operations are financed through sponsors and donations. If this is a mission you believe in, please consider <a href=\"https://letsencrypt.org/donate/\">donating</a> to the project.<br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Mar 2018 17:23:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: WPWeekly Episode 308 – Wildcard SSL Certificates For All\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=78291&preview=true&preview_id=78291\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wptavern.com/wpweekly-episode-308-wildcard-ssl-certificates-for-all\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2349:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I discuss the news of the week including the results from the 2018 Stack Overflow survey, Tech Crunch&#8217;s rebuild, and Let&#8217;s Encrypt adding support for wildcard certificates. We also talk about Google working towards AMP or parts of it becoming official web standards. I ranted about how the mobile experience on the web sucks, and we end the show with some event news.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/stack-overflow-survey-respondents-still-rank-wordpress-among-the-most-dreadful-platforms\">Stack Overflow Survey Respondents Still Rank WordPress Among the Most Dreadful Platforms</a><br />
<a href=\"https://www.theverge.com/2018/3/8/17095078/google-amp-accelerated-mobile-page-announcement-standard-web-packaging-urls\">Inside Google’s plan to make the whole web as fast as AMP</a><br />
<a href=\"https://community.letsencrypt.org/t/acme-v2-and-wildcard-certificate-support-is-live/55579\">ACME v2 and Wildcard Certificate Support is Live</a><br />
<a href=\"https://techcrunch.com/2018/03/13/welcome-to-the-new-techcrunch/\">TechCrunch rebuilt using the REST API</a><br />
<a href=\"https://wptavern.com/wpcampus-scheduled-for-july-12-14-in-st-louis-mo\">WPCampus Scheduled for July 12-14 in St. Louis, MO</a></p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://themeshaper.com/2018/03/07/designing-gutenberg-block-driven-themes-with-sketch/\">Designing Themes with Gutenberg Blocks and Sketch</a></p>
<p><a href=\"https://www.pioneerdj.com/en-us/product/controller/ddj-1000/black/overview/\">DDJ-1000 The 4-channel professional performance DJ controller for rekordbox dj</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, March 21st 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #308:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Mar 2018 01:09:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"HeroPress: A look back: Tamsin Taylor, Freedom Through Blogging\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=2484\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:167:\"https://heropress.com/a-look-back-tamsin-taylor-freedom-through-blogging/#utm_source=rss&utm_medium=rss&utm_campaign=a-look-back-tamsin-taylor-freedom-through-blogging\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3463:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2016/10/100516-2-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: We cannot know the end of any journey until we find ourselves there.\" /><p>In August of 2016 I saw <a href=\"https://wordpress.tv/2016/08/09/tamsin-taylor-a-heros-journey/\">a WordCamp talk on WordPress.tv</a> called &#8220;A Hero&#8217;s Journey&#8221;, and I thought that seemed like something I should know a lot more about.  A short time later I was speaking with Tamsin Taylor on Slack.</p>
<p><img class=\"aligncenter wp-image-2485 size-full\" src=\"https://s20094.pcdn.co/wp-content/uploads/2018/03/Screen-Shot-2018-03-14-at-8.46.22-AM.png\" alt=\"A greeting conversation\" width=\"356\" height=\"201\" /></p>
<p>I love telling stories, but I love hearing them more. Tamsin told me a story grief and loss, and how WordPress provided an outlet for those feelings. I hope her story resonates with you as well.</p>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://heropress.com/essays/bumpy-journey-becoming/\">The Bumpy Journey of Becoming</a></p></blockquote>
<p></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: A look back: Tamsin Taylor, Freedom Through Blogging\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=A%20look%20back%3A%20Tamsin%20Taylor%2C%20Freedom%20Through%20Blogging&via=heropress&url=https%3A%2F%2Fheropress.com%2Fa-look-back-tamsin-taylor-freedom-through-blogging%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: A look back: Tamsin Taylor, Freedom Through Blogging\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fa-look-back-tamsin-taylor-freedom-through-blogging%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fa-look-back-tamsin-taylor-freedom-through-blogging%2F&title=A+look+back%3A+Tamsin+Taylor%2C+Freedom+Through+Blogging\" rel=\"nofollow\" target=\"_blank\" title=\"Share: A look back: Tamsin Taylor, Freedom Through Blogging\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/a-look-back-tamsin-taylor-freedom-through-blogging/&media=https://heropress.com/wp-content/uploads/2016/10/100516-2-150x150.jpg&description=A look back: Tamsin Taylor, Freedom Through Blogging\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: A look back: Tamsin Taylor, Freedom Through Blogging\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/a-look-back-tamsin-taylor-freedom-through-blogging/\" title=\"A look back: Tamsin Taylor, Freedom Through Blogging\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/a-look-back-tamsin-taylor-freedom-through-blogging/\">A look back: Tamsin Taylor, Freedom Through Blogging</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 14 Mar 2018 12:46:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"WPTavern: Stack Overflow Survey Respondents Still Rank WordPress Among the Most Dreadful Platforms\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78278\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:109:\"https://wptavern.com/stack-overflow-survey-respondents-still-rank-wordpress-among-the-most-dreadful-platforms\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2902:\"<p><a href=\"https://stackoverflow.com/\">Stack Overflow</a>, a Q&amp;A community for developers, has published the results of <a href=\"https://insights.stackoverflow.com/survey/2018/\">its 2018 developer survey</a>. The survey was held between January 8th through the 28th and includes responses from 101,592 software developers from 183 countries across the world. This is nearly twice the amount of responses compared to <a href=\"https://insights.stackoverflow.com/survey/2017#methodology\">last year&#8217;s survey</a>.</p>
<p><a href=\"https://insights.stackoverflow.com/survey/2017#technology-most-loved-dreaded-and-wanted-platforms\">Last year</a>, WordPress was the third most dreaded software platform behind Salesforce and SharePoint. This year, WordPress has improved in the rankings and is the sixth most dreaded platform. Respondents found Windows Phone, Mainframe, Salesforce, Drupal, and SharePoint to be more dreadful.</p>
<img />WordPress is the sixth most dreaded software platform
<p>Despite making headway, WordPress has <a href=\"https://wptavern.com/stack-overflow-developer-survey-ranks-wordpress-as-the-3rd-most-dreaded-technology\">consistently ranked near the top</a> in Stack Overflow&#8217;s survey for most dreadful platform. Asking developers why is probably akin to opening <a href=\"https://en.wikipedia.org/wiki/Pandora%27s_box\">Pandora&#8217;s box</a>.</p>
<p>JavaScript was once again the <a href=\"https://insights.stackoverflow.com/survey/2018/#most-popular-technologies\">most popular technology</a> with HTML, CSS, and SQL following closely behind. Among the various JavaScript frameworks and libraries that exist, <a href=\"https://insights.stackoverflow.com/survey/2018/#technology-frameworks-libraries-and-tools\">Node.js is the most commonly used</a> followed by Angular and React.</p>
<p>The survey introduced a few new topics this year, including questions about <a href=\"https://insights.stackoverflow.com/survey/2018/#technology-and-society\">artificial intelligence</a> and ethics. When <a href=\"https://insights.stackoverflow.com/survey/2018/#work-what-would-developers-do-if-asked-to-write-code-for-an-unethical-purpose\">posed with a hypothetical situation</a> in which a developer was asked if they would write code for unethical purposes, more than half of the respondents said no. Also of note is that <a href=\"https://insights.stackoverflow.com/survey/2018/#developer-profile-contributing-to-open-source\">less than half</a> of the respondents say they contribute to open source.</p>
<p>There are a lot of interesting data points in the survey. I encourage you to <a href=\"https://insights.stackoverflow.com/survey/2018/#overview\">check out the results</a> and let me know in the comments what sticks out to you.</p>
<p><strong>Updated 3/14/2018</strong> Corrected to say that WordPress has improved in the rankings and is therefor, less dreadful than before.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 14 Mar 2018 10:08:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: WPCampus Scheduled for July 12-14 in St. Louis, MO\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78273\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wptavern.com/wpcampus-scheduled-for-july-12-14-in-st-louis-mo\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1138:\"<p><a href=\"https://2018.wpcampus.org/about/\">WPCampus</a>, an in-person conference dedicated to WordPress in higher education <a href=\"https://2018.wpcampus.org/\">has announced</a> its third annual event will be held July 12-14 at <a href=\"https://wustl.edu/\">Washington University</a> in St. Louis, MO. The <a href=\"https://2018.wpcampus.org/call-for-speakers/application/\">call for speakers</a> is open until April 7th. The event is two months after <a href=\"https://2018.stlouis.wordcamp.org/\">WordCamp St. Louis </a>which will also be held at Washington University.</p>
<p>WPCampus held its first event in 2016 in Sarasota, FL, and its second in 2017 in Buffalo, NY. The schedule is not yet finalized but to get an idea on what to expect, check out the <a href=\"http://wpcampus.org/videos/\">video presentations</a> from previous events. Organizers expect about 200 attendees and are accepting <a href=\"https://2018.wpcampus.org/sponsors/\">sponsorship inquiries</a>.</p>
<p>Tickets are not yet available but those interested in attending can sign up to the WPCampus mailing list where ticket information will be distributed first.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 13 Mar 2018 00:12:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"Post Status: Network effects and WordPress — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=44341\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"https://poststatus.com/network-effects-wordpress-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2200:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p>In this episode, Brian and Brian discuss the power of network effects and how they relate to WordPress’ increasing market share and maturity. WordPress has recently hit two major milestones, turning 15 years old and reaching 30% market share of the top 10 million websites, and we spend this episode reflecting on the innovations that brought us here and where innovations are likely to occur over the next 10 years.</p>
<p>We’ve come quite a long way in these 15 years. From the famous 5-minute install to being entirely pre-installed. From a supportive band of volunteers and vast ecosystem of free software to the commercially supported and highly-polished products that exist today. There is a lot about WordPress to be thankful for, and a lot of great things that will exist in the future because of it. And you can hear a bit about all of that on this episode of the Post Status Draft podcast.</p>
<p></p>
<h3>Links</h3>
<ul>
<li><a href=\"https://medium.com/evergreen-business-weekly/the-power-of-network-effects-why-they-make-such-valuable-companies-and-how-to-harness-them-5d3fbc3659f8\">The Power of Network Effects</a></li>
<li>Mel Choice&#8217;s LoopConf presentation on <a href=\"https://loopconf.com/talk/customizing-the-future/\">Customizing the Future</a></li>
</ul>
<h3>Sponsor: Yoast</h3>
<p>Yoast SEO Premium gives you 24/7 support from a great support team and extra features such as a redirect manager, recommended internal links, tutorial videos and integration with Google Webmaster Tools! Check out <a href=\"https://yoast.com/\">Yoast SEO Premium</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 10 Mar 2018 20:18:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"WPTavern: Yoast Launches Fund to Increase Speaker Diversity at Tech Conferences\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78248\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://wptavern.com/yoast-launches-fund-to-increase-speaker-diversity-at-tech-conferences\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1421:\"<p>In an effort to increase speaker diversity at conferences worldwide, the team at Yoast SEO has <a href=\"https://yoast.com/yoast-diversity-fund/\">launched</a> a diversity fund. The fund will pledge a minimum of €25,000 each year. Its purpose is to remove the financial burdens that can cause minorities or underrepresented groups to speak at conferences.</p>
<p>&#8220;There are WordCamps throughout the world, these are conferences about, by and for the WordPress community,&#8221; Joost de Valk said.</p>
<p>&#8220;While we already sponsor a lot of them, they tend to not have the budget to pay for speakers’ travel and accommodation cost. The same applies to other conferences about open source, certainly those that are not commercially run. We want to take away that particular reason for not having a diverse conference.&#8221;</p>
<p>Eligible candidates will be reimbursed €1,000 for travel and accommodations per event. In order to qualify for the fund, speakers must meet the following requirements:</p>
<ul>
<li>Is a part of – or identifies as part of – a typically underrepresented group.</li>
<li>The conference is not commercial.</li>
<li>The conference targets either the WordPress, Magento, or TYPO3 community.</li>
<li>Has been accepted as a speaker to the conference.</li>
</ul>
<p>To submit an application, email diversity-fund at yoast.com where applications are reviewed within a week.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2018 03:20:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: WPWeekly Episode 307 – Thirty Percent of the Web\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=78242&preview=true&preview_id=78242\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wptavern.com/wpweekly-episode-307-thirty-percent-of-the-web\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2423:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I start with a continued discussion of AMP from last week. We cover the big releases of the week including Jetpack, Genesis, Yoast SEO, and Gutenberg. We discuss a new project that aims to determine Gutenberg compatible plugins, debate the terminology used to describe WordPress&#8217; market share, and a new plugin that makes WordPress updates more secure.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://make.wordpress.org/core/2018/03/02/whats-new-in-gutenberg-2nd-march/\">Gutenberg 2.3, Now With Nested Blocks</a><br />
<a href=\"https://studiopress.blog/genesis-2-6/\">Genesis 2.6</a><br />
<a href=\"https://yoast.com/yoast-seo-7-0/\">Yoast SEO 7.0</a><br />
<a href=\"https://jetpack.com/category/releases/\">Jetpack 5.9</a><br />
<a href=\"https://wptavern.com/4500-plugins-need-your-help-in-determining-gutenberg-compatibility\">4,500 Plugins Need Your Help in Determining Gutenberg Compatibility</a><br />
<a href=\"https://wptavern.com/new-plugin-makes-wordpress-core-updates-more-secure-by-requiring-cryptographic-signature-verification\">New Plugin Makes WordPress Core Updates More Secure by Requiring Cryptographic Signature Verification</a><br />
<a href=\"https://wptavern.com/wordpress-now-used-on-30-of-the-top-10-million-sites\">WordPress Now Used on 30% of the Top 10 Million Sites</a></p>
<h2>Picks of the Week:</h2>
<p>Mel Choyce&#8217;s presentation on <a href=\"https://wptavern.com/conceptual-ideas-on-how-the-customizer-could-integrate-with-gutenberg\">Customizing the Future</a> at LoopConf.</p>
<p>Felix Arntz&#8217;s presentation on a Global Admin, a <a href=\"https://www.youtube.com/watch?v=V085zCBdRfc\">deep dive into multi-network organization</a> at LoopConf.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, February 14th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #307:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Mar 2018 03:39:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Matt: Back to Blogging\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47991\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"https://ma.tt/2018/03/back-to-blogging/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:134:\"<p>I really enjoyed <a href=\"http://tomcritchlow.com/2018/02/23/small-b-blogging/\">Tom Critchlow&#x27;s post Small b blogging</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 07 Mar 2018 22:59:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"WPTavern: Conceptual Ideas on How the Customizer Could Integrate With Gutenberg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78232\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://wptavern.com/conceptual-ideas-on-how-the-customizer-could-integrate-with-gutenberg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1598:\"<p>While the initial focus of Gutenberg is the editor, the second focus is the Customization experience in WordPress. <a href=\"https://choycedesign.com/\">Mel Choyce</a>, Product Designer at Automattic, recently spoke at <a href=\"https://loopconf.com/\">LoopConf</a>, on the <a href=\"https://loopconf.com/talk/customizing-the-future/\">past, present, and future</a> of the customizer.</p>
<p>Choyce begins the presentation by describing when and how the customizer was added to WordPress. Fun fact, the customizer or what was known as the Theme Customizer at the time, was added to <a href=\"https://wordpress.org/news/2012/06/green/\">WordPress 3.4 &#8220;Green&#8221;</a> in June 2012.</p>
<p>The session continues with Choyce showcasing new features and enhancements that have been made to the customizer since 2012. Near the 23 minute mark, Choyce shows conceptual images of what the customization experience could be like when implemented with Gutenberg.</p>
<p>In the experimental images, you can see options to choose page templates or layouts, live previewing changes to blocks, global site styles, and a standard set of user interface patterns. The ideas presented are concepts and likely to change.</p>
<p>Because the session was recorded with a picture-in-picture, I&#8217;m not able to provide high quality screen captures of the conceptual images. To see those items in detail, I recommend viewing the video in full-screen 1080p. You can full all of the LoopConf sessions for free via <a href=\"https://www.youtube.com/channel/UCAwOVsWiMdlz6snWRF2HdSQ\">their YouTube channel</a>.</p>
<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 07 Mar 2018 10:17:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"HeroPress: Building A New Life\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2480\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:112:\"https://heropress.com/essays/building-a-new-life/#utm_source=rss&utm_medium=rss&utm_campaign=building-a-new-life\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:12981:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2018/03/030718-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: Plan your business around what matters to you/\" /><p>This is the story of how I co-founded Barn2 Media with my husband Andy, and scaled it from a startup to one of the UK’s best known WordPress agencies &#8211; all while working part-time.</p>
<p>I&#8217;ll tell you about the challenges I faced in building a WordPress business that is compatible with a good work-life balance. I&#8217;ll share what I did each time the growing business started to threaten my lifestyle, and how you can do the same.</p>
<h2>The Beginning</h2>
<p>I had a traditional full-time job throughout my 20’s. I enjoyed building my career and earning a regular salary, but didn’t like the lack of flexibility that came with it.</p>
<p>I didn’t like having to arrive at work by a fixed time, or being unable to choose when I worked. As a hard-working person, it felt counter-productive to be forced to work set hours when I may not be at my best.</p>
<p>My daily commute was anything from 25-50 minutes (which I realise is less than many people). It felt like a waste of time as I could work just as well from home, not to mention the environmental impact of driving so far just to sit in an office. Day-to-day tasks such as ordering items for home delivery became a big deal, as I wasn’t home during the day.</p>
<p>As a result, I spent most of my 20’s simultaneously building my career in a traditional job, while dreaming about running my own business and working for myself. Andy felt the same about his own job as a senior software developer.</p>
<blockquote><p>I think that most people want a better lifestyle, but not many actually do anything about it. I thought I was one of those people.</p></blockquote>
<p>Andy and I would talk endlessly about different business ideas (most of them terrible!) and even experimented with building a few websites that were never launched. However, we didn’t have the drive to make it happen and launch a business in the real world.</p>
<h2>Starting a Business</h2>
<p>In late 2009, Andy had finally had enough of his job and we agreed that it was time for him to quit. We decided to start a web design business together. He would work solely on the new business, while I would support it alongside my main job (which I didn&#8217;t hate, even though I didn&#8217;t like the lifestyle).</p>
<p>We started by building WordPress websites for small local businesses. Andy built the websites and I was responsible for copywriting and marketing. We approached local tradespeople who didn&#8217;t already have a website &#8211; back in 2010, there were still a lot of these! Our first clients were local plumbers, electricians, a washing machine repair shop, etc.</p>
<p>These early projects were quite low budget. The average hourly rate was quite low because we were still learning and hadn&#8217;t perfected our processes yet. We wasted a lot of time on projects where we had under-quoted but were committed to honoring the agreed price.</p>
<blockquote><p>We made a lot of mistakes, and learned from them all!</p></blockquote>
<p>By Year 2, the business was making the equivalent of a fairly low salary for one person. However, we had to work a lot for a relatively small income. This encouraged us to work more hours, and it wasn&#8217;t bringing the lifestyle benefits I was looking for.</p>
<h2>Lifestyle Tip #1: Learn to Specialize</h2>
<p>In late 2010, it occurred to me that we were building all our websites in WordPress but not advertising ourself as a WordPress company. I wondered whether people were actually searching for WordPress experts and whether this could be a good way to advertise. That may seem obvious in 2018 now WordPress is the world&#8217;s biggest web platform &#8211; but it was a genuine question back in 2010.</p>
<p>On a whim, I invested $100 in Google AdWords targeting keywords such as &#8216;WordPress web design&#8217; and &#8216;WordPress developer&#8217;. Amazingly, we were overwhelmed with enquiries and quickly brought in over $4,000 of business &#8211; not a bad return on investment! The work came from medium sized companies who had never used our services before, with higher budgets.</p>
<blockquote><p>Positioning ourselves as WordPress specialists completely changed the profile of our client base, as well as the budgets we were working with.</p></blockquote>
<p>This vastly increased our average hourly income, so we were making more money without having to work more hours. Finally, it felt like a proper business with a better work-life balance.</p>
<h2>Lifestyle Tip #2: Build a (virtual) team</h2>
<p>The business grew quickly under its new identity as a specialist WordPress agency. By mid-2011, we had more work than we could manage ourselves. I also had a baby and increased my hours on the business while on maternity leave &#8211; eventually not returning to my old job. We still needed to increase the company&#8217;s income, while working towards the lifestyle we wanted.</p>
<p>We grew the business to the next level by building a virtual team.</p>
<blockquote><p>I felt quite strongly that I didn&#8217;t want to become a traditional employer with a team of staff, all working together in an office. That would bring me back to the lifestyle I started with!</p></blockquote>
<p>Instead, I decided to recruit a team of freelancers.</p>
<p>It took time to find the right freelancers, but the good news is that you can try someone out on a single project with no further commitment. If it doesn&#8217;t work out, then you don&#8217;t have to work with them again. Through trial and error, I built a team of freelancers with different WordPress-related skills. This increased capacity and allowed us to take on more projects without having to work more hours.</p>
<p>I was still managing all the projects, but could take a step back and wasn&#8217;t directly building the websites. Finally, it felt like a proper WordPress agency.</p>
<h2>Lifestyle Tip #3: Selling WordPress products</h2>
<p>By building a distributed team, the business became more and more successful. We were taking on more and more projects, and I was managing all of them. By the time we were running 20 projects at once, I had reached the limits of my capacity and was having to work a lot of hours.</p>
<p>From 2014-15, I experimented with working with freelance project managers, but had to give up because quality was dropping and our clients were less happy. I realised that with the current business model, I could only continue growing the business by working more and more hours. This wasn&#8217;t what I had been working towards!</p>
<p>It was time for Andy and I to pursue our other dream: selling WordPress products. We&#8217;d been talking about this since the early days of the business, but the client projects had kept us so busy that we&#8217;d never done anything about it.</p>
<p>In early 2016, Andy stepped out of the client business and started writing WordPress and WooCommerce plugins to sell. I continued managing client projects for the next 6 months, until the plugins were making enough money to stop taking on new projects and I could spend all my time marketing and supporting the plugins.</p>
<blockquote><p>Selling WordPress plugins has been very successful because we already knew the market inside out from our years of developing WordPress sites.</p></blockquote>
<p>We knew where the gaps were and what plugin customers want. We knew where other plugin companies get it wrong, and could learn from their mistakes without making the same mistakes ourselves!</p>
<p>By launching several plugins, we could listen to what our customers were asking for and build even more. In October 2016, we launched our <a href=\"https://barn2.co.uk/wordpress-plugins/woocommerce-product-table/\">WooCommerce Product Table plugin</a> because so many people asked for a way to list products in a table with add to cart buttons. This immediately became our bestselling plugin and has sold more than all our other plugins combined. Since then, the plugin business has gone from strength to strength.</p>
<blockquote><p>I have found that selling WordPress products brings a much better work-life balance than providing WordPress services.</p></blockquote>
<p>We receive (many) plugin support requests every day, but each one takes relatively little time and is less pressured than fixing problems for web design clients. The whole business feels much more relaxed, and I don&#8217;t feel guilty about taking time off.</p>
<p>Between the two of us, we spend a couple of hours a day on plugin support. We continue improving the plugins, marketing, adding features and building the business on top of that. However, all of this is optional and can easily be done while working part-time.</p>
<h2>Snow Day! Putting It Into Practice</h2>
<p>Before we finish, I&#8217;ll tell you about my week. Today is Friday. At 10.30am on Wednesday, I received a text that my daughter&#8217;s school had closed for the rest of the week because of the unusual snow here in the UK.</p>
<p>The parents with traditional jobs panicked and had to quickly arrange childcare or time-off work. Some of them were stuck in cars on snowed-in roads as they tried to return to the village. No one could get to work the next day. A lot of people lost a lot of money.</p>
<p>Andy and I simply stopped work, put on our snow gear, walked the 10 minutes to the school, and then went sledging. Since then, we&#8217;ve been sharing the childcare in between responding to plugin support requests (and writing this article!). We&#8217;ve had 37 plugin sales on our website since the school closed, even though we&#8217;ve been working less hours than usual. Now, that&#8217;s what I&#8217;ve been working towards!</p>
<h2>Conclusion</h2>
<p>I&#8217;ve worked hard and have been extremely committed to building Barn2 Media. However, this has always been on the condition that it wouldn&#8217;t sacrifice my lifestyle goals.</p>
<blockquote><p>For me, the ideal business is measured against a combination of financial success and lifestyle benefits. If the founders are working 70 hours a week to keep the money coming in, then it&#8217;s not a successful business!</p></blockquote>
<p>You can do the same. Design a WordPress business that will give you the lifestyle you want, as well as making money. If you love working with people, build a team and provide WordPress services (WordPress design and development are good for this). If you want to travel, choose work that you can do remotely from different time zones (WordPress products are good for this). Plan your business around what matters to you.</p>
<p>WordPress is such a huge ecosystem that it comes with many opportunities to build a successful business. With a bit of extra thought and planning, you can build a WordPress business that is successful AND lets you life the lifestyle you&#8217;ve always wanted. That is the true measure of success.</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Building A New Life\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Building%20A%20New%20Life&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fbuilding-a-new-life%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Building A New Life\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fbuilding-a-new-life%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fbuilding-a-new-life%2F&title=Building+A+New+Life\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Building A New Life\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/building-a-new-life/&media=https://heropress.com/wp-content/uploads/2018/03/030718-150x150.jpg&description=Building A New Life\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Building A New Life\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/building-a-new-life/\" title=\"Building A New Life\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/building-a-new-life/\">Building A New Life</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 07 Mar 2018 08:00:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Katie Keith\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Wed, 18 Apr 2018 15:10:44 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Wed, 18 Apr 2018 15:00:27 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20130911010210\";}","no");
INSERT INTO `gol_options` VALUES("2373","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1524107445","no");
INSERT INTO `gol_options` VALUES("2374","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1524064245","no");
INSERT INTO `gol_options` VALUES("2375","_transient_timeout_dash_v2_f69de0bbfe7eaa113146875f40c02000","1524107446","no");
INSERT INTO `gol_options` VALUES("2376","_transient_dash_v2_f69de0bbfe7eaa113146875f40c02000","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://ru.wordpress.org/news/2018/02/%D0%B2%D1%8B%D0%BF%D1%83%D1%81%D0%BA-wordpress-4-9-4/\'>Выпуск WordPress 4.9.4 (требуется ручное обновление)</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://heropress.com/where-wordpress-really-matters/#utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=where-wordpress-really-matters\'>HeroPress: Where WordPress REALLY Matters</a></li><li><a class=\'rsswidget\' href=\'https://ma.tt/2018/04/abstract-aluminum/\'>Matt: Abstract Aluminum</a></li><li><a class=\'rsswidget\' href=\'https://buddypress.org/2018/04/buddypress-3-0-beta-1/\'>BuddyPress: BuddyPress 3.0 Beta 2</a></li></ul></div>","no");
INSERT INTO `gol_options` VALUES("2377","_site_transient_timeout_available_translations","1524075062","no");
INSERT INTO `gol_options` VALUES("2378","_site_transient_available_translations","a:113:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-06 13:56:09\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-24 19:38:49\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-04 08:43:29\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.5/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-22 13:41:14\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-22 03:44:52\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-04 20:20:28\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-16 18:12:49\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-04 05:10:07\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-11 09:40:36\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-19 17:34:31\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-02-12 10:10:36\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-17 15:09:38\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-17 15:08:43\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.5/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-22 15:43:53\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.9.2/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-05 12:41:56\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-09 08:59:25\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-15 20:17:27\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 09:54:30\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-29 16:28:34\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-17 05:20:05\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-18 17:06:15\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-02-27 05:22:44\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-23 18:34:33\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 23:17:08\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 15:03:42\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-07-31 15:12:02\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-10-01 17:54:52\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.3/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-28 20:09:49\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-26 19:32:51\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-19 14:11:29\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-12-09 21:12:23\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-30 07:44:25\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-06 10:09:56\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-21 22:04:16\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-15 03:45:18\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-01-31 11:16:06\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.6/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-10 18:19:59\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-02-14 06:16:04\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-15 08:49:46\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-31 18:09:34\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-26 21:01:10\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-02 12:51:15\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-13 11:16:25\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-04-13 13:55:54\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-18 05:27:48\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-16 18:46:39\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-24 13:53:29\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Nerusaké\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-08 06:01:48\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-22 22:24:38\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.5/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-12 08:08:32\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-07 02:07:59\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-15 02:27:09\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:25\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 19:40:23\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-03-17 20:40:40\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.7/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.6/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-02-28 10:55:13\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 10:26:07\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-27 10:30:26\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-26 08:04:00\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.5/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-23 12:42:00\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-05 12:59:55\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-22 09:27:50\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-11 18:05:33\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-22 18:30:41\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-09 09:30:48\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/4.9.5/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-05 17:29:06\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 15:10:20\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-22 15:56:45\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-22 08:50:10\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-25 10:30:04\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-25 20:12:50\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-09 12:42:33\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-02 17:08:41\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-04 21:51:10\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 12:31:53\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:9:\"Uyƣurqə\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-06 20:34:06\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-13 08:24:25\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-09 10:37:43\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-11 05:09:29\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-09 00:56:52\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-13 02:41:15\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-17 22:20:52\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}}","no");
INSERT INTO `gol_options` VALUES("2381","_transient_pll_languages_list","a:2:{i:0;a:26:{s:7:\"term_id\";i:8;s:4:\"name\";s:7:\"English\";s:4:\"slug\";s:2:\"en\";s:10:\"term_group\";i:0;s:16:\"term_taxonomy_id\";i:8;s:8:\"taxonomy\";s:8:\"language\";s:11:\"description\";s:5:\"en_GB\";s:6:\"parent\";i:0;s:5:\"count\";i:9;s:10:\"tl_term_id\";i:9;s:19:\"tl_term_taxonomy_id\";i:9;s:8:\"tl_count\";i:11;s:6:\"locale\";R:9;s:6:\"is_rtl\";i:0;s:3:\"w3c\";s:5:\"en-GB\";s:8:\"facebook\";s:5:\"en_GB\";s:8:\"flag_url\";s:0:\"\";s:4:\"flag\";s:0:\"\";s:8:\"home_url\";s:25:\"http://golubika.local/en/\";s:10:\"search_url\";s:25:\"http://golubika.local/en/\";s:4:\"host\";N;s:5:\"mo_id\";s:2:\"31\";s:13:\"page_on_front\";N;s:14:\"page_for_posts\";N;s:6:\"filter\";s:3:\"raw\";s:9:\"flag_code\";s:0:\"\";}i:1;a:26:{s:7:\"term_id\";i:5;s:4:\"name\";s:20:\"Українська\";s:4:\"slug\";s:2:\"uk\";s:10:\"term_group\";i:1;s:16:\"term_taxonomy_id\";i:5;s:8:\"taxonomy\";s:8:\"language\";s:11:\"description\";s:2:\"uk\";s:6:\"parent\";i:0;s:5:\"count\";i:10;s:10:\"tl_term_id\";i:6;s:19:\"tl_term_taxonomy_id\";i:6;s:8:\"tl_count\";i:11;s:6:\"locale\";R:35;s:6:\"is_rtl\";i:0;s:3:\"w3c\";s:2:\"uk\";s:8:\"facebook\";s:5:\"uk_UA\";s:8:\"flag_url\";s:0:\"\";s:4:\"flag\";s:0:\"\";s:8:\"home_url\";s:22:\"http://golubika.local/\";s:10:\"search_url\";s:22:\"http://golubika.local/\";s:4:\"host\";N;s:5:\"mo_id\";s:2:\"30\";s:13:\"page_on_front\";N;s:14:\"page_for_posts\";N;s:6:\"filter\";s:3:\"raw\";s:9:\"flag_code\";s:0:\"\";}}","yes");


DROP TABLE IF EXISTS `gol_postmeta`;

CREATE TABLE `gol_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=457 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `gol_postmeta` VALUES("73","30","_pll_strings_translations","a:7:{i:0;a:2:{i:0;s:8:\"Golubika\";i:1;s:8:\"Golubika\";}i:1;a:2:{i:0;s:25:\"Felt bags&amp;accessories\";i:1;s:25:\"Felt bags&amp;accessories\";}i:2;a:2:{i:0;s:5:\"d.m.Y\";i:1;s:5:\"d.m.Y\";}i:3;a:2:{i:0;s:3:\"H:i\";i:1;s:3:\"H:i\";}i:4;a:2:{i:0;s:17:\"Лого меню\";i:1;s:17:\"Лого меню\";}i:5;a:2:{i:0;s:18:\"Лого О НАС\";i:1;s:18:\"Лого О НАС\";}i:6;a:2:{i:0;s:19:\"Лого футер\";i:1;s:19:\"Лого футер\";}}");
INSERT INTO `gol_postmeta` VALUES("74","31","_pll_strings_translations","a:7:{i:0;a:2:{i:0;s:8:\"Golubika\";i:1;s:8:\"Golubika\";}i:1;a:2:{i:0;s:25:\"Felt bags&amp;accessories\";i:1;s:25:\"Felt bags&amp;accessories\";}i:2;a:2:{i:0;s:5:\"d.m.Y\";i:1;s:5:\"d.m.Y\";}i:3;a:2:{i:0;s:3:\"H:i\";i:1;s:3:\"H:i\";}i:4;a:2:{i:0;s:17:\"Лого меню\";i:1;s:9:\"Logo menu\";}i:5;a:2:{i:0;s:18:\"Лого О НАС\";i:1;s:10:\"Logo About\";}i:6;a:2:{i:0;s:19:\"Лого футер\";i:1;s:11:\"Logo Footer\";}}");
INSERT INTO `gol_postmeta` VALUES("105","244","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("106","244","_edit_lock","1521642594:1");
INSERT INTO `gol_postmeta` VALUES("109","246","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("112","246","_edit_lock","1521642978:1");
INSERT INTO `gol_postmeta` VALUES("121","253","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("122","253","_edit_lock","1521643393:1");
INSERT INTO `gol_postmeta` VALUES("125","255","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("128","255","_edit_lock","1521643501:1");
INSERT INTO `gol_postmeta` VALUES("133","260","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("134","260","_edit_lock","1521643992:1");
INSERT INTO `gol_postmeta` VALUES("137","262","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("138","262","_edit_lock","1521643960:1");
INSERT INTO `gol_postmeta` VALUES("152","266","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("153","266","_edit_lock","1521653944:1");
INSERT INTO `gol_postmeta` VALUES("156","268","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("157","268","_edit_lock","1521653974:1");
INSERT INTO `gol_postmeta` VALUES("189","266","_wp_old_slug","individualni-zamovlennya__trashed");
INSERT INTO `gol_postmeta` VALUES("192","268","_wp_old_slug","individual-orders__trashed");
INSERT INTO `gol_postmeta` VALUES("193","273","_wp_attached_file","2018/03/Individual_order.jpg");
INSERT INTO `gol_postmeta` VALUES("194","273","_wp_attachment_metadata","a:5:{s:5:\"width\";i:400;s:6:\"height\";i:400;s:4:\"file\";s:28:\"2018/03/Individual_order.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"Individual_order-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"Individual_order-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:8:\"iPhone 6\";s:7:\"caption\";s:34:\"Processed with VSCO with a6 preset\";s:17:\"created_timestamp\";s:10:\"1494678062\";s:9:\"copyright\";s:36:\"Copyright 2017. All rights reserved.\";s:12:\"focal_length\";s:4:\"4.15\";s:3:\"iso\";s:2:\"80\";s:13:\"shutter_speed\";s:16:\"0.03030303030303\";s:5:\"title\";s:34:\"Processed with VSCO with a6 preset\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `gol_postmeta` VALUES("195","266","_thumbnail_id","273");
INSERT INTO `gol_postmeta` VALUES("196","268","_thumbnail_id","273");
INSERT INTO `gol_postmeta` VALUES("199","273","_edit_lock","1521654109:1");
INSERT INTO `gol_postmeta` VALUES("200","273","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("201","274","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("202","274","_edit_lock","1521656418:1");
INSERT INTO `gol_postmeta` VALUES("205","276","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("206","276","_edit_lock","1521911260:1");
INSERT INTO `gol_postmeta` VALUES("213","283","_wp_attached_file","2018/03/test.jpg");
INSERT INTO `gol_postmeta` VALUES("214","283","_wp_attachment_metadata","a:5:{s:5:\"width\";i:864;s:6:\"height\";i:576;s:4:\"file\";s:16:\"2018/03/test.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"test-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"test-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"test-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `gol_postmeta` VALUES("215","274","_thumbnail_id","283");
INSERT INTO `gol_postmeta` VALUES("216","276","_thumbnail_id","283");
INSERT INTO `gol_postmeta` VALUES("403","309","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("404","309","_edit_lock","1521911247:1");
INSERT INTO `gol_postmeta` VALUES("407","311","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("410","311","_edit_lock","1521911523:1");
INSERT INTO `gol_postmeta` VALUES("411","313","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("412","313","_edit_lock","1522057285:1");
INSERT INTO `gol_postmeta` VALUES("415","313","_crb_good_name","Тестовий товар");
INSERT INTO `gol_postmeta` VALUES("416","313","_crb_good_descr","Опис тестового товару");
INSERT INTO `gol_postmeta` VALUES("417","313","_crb_order_availability","not_available");
INSERT INTO `gol_postmeta` VALUES("418","313","_crb_good_price","2000");
INSERT INTO `gol_postmeta` VALUES("419","313","_crb_main_photo","http://golubika.local/wp-content/uploads/2018/03/Individual_order.jpg");
INSERT INTO `gol_postmeta` VALUES("420","313","_crb_secondary_photo1","");
INSERT INTO `gol_postmeta` VALUES("421","313","_crb_secondary_photo2","");
INSERT INTO `gol_postmeta` VALUES("422","315","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("423","315","_edit_lock","1522143084:1");
INSERT INTO `gol_postmeta` VALUES("424","316","_wp_attached_file","2018/03/Individual_order-1.jpg");
INSERT INTO `gol_postmeta` VALUES("425","316","_wp_attachment_metadata","a:5:{s:5:\"width\";i:400;s:6:\"height\";i:400;s:4:\"file\";s:30:\"2018/03/Individual_order-1.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"Individual_order-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"Individual_order-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:8:\"iPhone 6\";s:7:\"caption\";s:34:\"Processed with VSCO with a6 preset\";s:17:\"created_timestamp\";s:10:\"1494678062\";s:9:\"copyright\";s:36:\"Copyright 2017. All rights reserved.\";s:12:\"focal_length\";s:4:\"4.15\";s:3:\"iso\";s:2:\"80\";s:13:\"shutter_speed\";s:16:\"0.03030303030303\";s:5:\"title\";s:34:\"Processed with VSCO with a6 preset\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `gol_postmeta` VALUES("428","315","_crb_good_name","Test product");
INSERT INTO `gol_postmeta` VALUES("429","315","_crb_good_descr","Test product description");
INSERT INTO `gol_postmeta` VALUES("430","315","_crb_order_availability","not_available");
INSERT INTO `gol_postmeta` VALUES("431","315","_crb_good_price","100");
INSERT INTO `gol_postmeta` VALUES("432","315","_crb_main_photo","http://golubika.local/wp-content/uploads/2018/03/Individual_order-1.jpg");
INSERT INTO `gol_postmeta` VALUES("433","315","_crb_secondary_photo1","");
INSERT INTO `gol_postmeta` VALUES("434","315","_crb_secondary_photo2","");
INSERT INTO `gol_postmeta` VALUES("435","319","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("436","319","_edit_lock","1522597004:1");
INSERT INTO `gol_postmeta` VALUES("439","319","_crb_good_name","Ще один тестовий товар");
INSERT INTO `gol_postmeta` VALUES("440","319","_crb_good_descr","Опис ще одного тестового аксесуару");
INSERT INTO `gol_postmeta` VALUES("441","319","_crb_order_availability","not_available");
INSERT INTO `gol_postmeta` VALUES("442","319","_crb_good_price","5000");
INSERT INTO `gol_postmeta` VALUES("443","319","_crb_main_photo","http://golubika.local/wp-content/uploads/2018/03/Individual_order.jpg");
INSERT INTO `gol_postmeta` VALUES("444","319","_crb_secondary_photo1","");
INSERT INTO `gol_postmeta` VALUES("445","319","_crb_secondary_photo2","");
INSERT INTO `gol_postmeta` VALUES("446","321","_edit_last","1");
INSERT INTO `gol_postmeta` VALUES("447","321","_edit_lock","1522597065:1");
INSERT INTO `gol_postmeta` VALUES("450","321","_crb_good_name","Another test product");
INSERT INTO `gol_postmeta` VALUES("451","321","_crb_good_descr","description of another test product");
INSERT INTO `gol_postmeta` VALUES("452","321","_crb_order_availability","not_available");
INSERT INTO `gol_postmeta` VALUES("453","321","_crb_good_price","200");
INSERT INTO `gol_postmeta` VALUES("454","321","_crb_main_photo","http://golubika.local/wp-content/uploads/2018/03/Individual_order-1.jpg");
INSERT INTO `gol_postmeta` VALUES("455","321","_crb_secondary_photo1","");
INSERT INTO `gol_postmeta` VALUES("456","321","_crb_secondary_photo2","");


DROP TABLE IF EXISTS `gol_posts`;

CREATE TABLE `gol_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=327 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `gol_posts` VALUES("30","3","2018-02-10 14:04:06","2018-02-10 12:04:06","","polylang_mo_5","","private","closed","closed","","polylang_mo_5","","","2018-02-10 14:04:06","2018-02-10 12:04:06","","0","http://golubika.local/?post_type=polylang_mo&p=30","0","polylang_mo","","0");
INSERT INTO `gol_posts` VALUES("31","3","2018-02-10 14:05:27","2018-02-10 12:05:27","","polylang_mo_8","","private","closed","closed","","polylang_mo_8","","","2018-02-10 14:05:27","2018-02-10 12:05:27","","0","http://golubika.local/?post_type=polylang_mo&p=31","0","polylang_mo","","0");
INSERT INTO `gol_posts` VALUES("244","3","2018-03-21 15:30:32","2018-03-21 13:30:32","Все дуже просто - достатньо натиснути на кнопку “Замовити” поряд з уподобаною моделлю та заповнити необхідні дані.

Далі ми зв\'яжемося з Вами для узгодження деталей замовлення.

Поспілкуватися з нами, щось уточнити та замовити також можливо по телефону, Viber, Telegram та e-mail.","Замовити","","publish","open","open","","zamoviti","","","2018-03-21 16:24:16","2018-03-21 14:24:16","","0","http://golubika.local/?p=244","0","post","","0");
INSERT INTO `gol_posts` VALUES("245","3","2018-03-21 15:30:32","2018-03-21 13:30:32","","Замовити","","inherit","closed","closed","","244-revision-v1","","","2018-03-21 15:30:32","2018-03-21 13:30:32","","244","http://golubika.local/244-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("246","3","2018-03-21 15:30:32","2018-03-21 13:30:32","<p>Order now directly from this website - just push the button within the craft you chose and submit.</p>
<p>Straight after that we will contact you to agree on all details.</p>
<p>Do not hesitate to contact us via Viber, Telegram and e-mail.</p>
","Order now!","","publish","open","open","","order-now","","","2018-03-21 16:37:30","2018-03-21 14:37:30","","0","http://golubika.local/?p=246","0","post","","0");
INSERT INTO `gol_posts` VALUES("247","3","2018-03-21 15:31:21","2018-03-21 13:31:21","","Order now!","","inherit","closed","closed","","246-revision-v1","","","2018-03-21 15:31:21","2018-03-21 13:31:21","","246","http://golubika.local/246-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("248","3","2018-03-21 16:12:02","2018-03-21 14:12:02","Все дуже просто - достатньо натиснути на кнопку “Замовити” поряд з уподобаною моделлю та заповнити необхідні дані.

Далі ми зв\'яжемося з Вами для узгодження деталей замовлення.

Поспілкуватися з нами, щось уточнити та замовити також можливо по телефону, Viber, Telegram та e-mail.","Замовити","","inherit","closed","closed","","244-autosave-v1","","","2018-03-21 16:12:02","2018-03-21 14:12:02","","244","http://golubika.local/244-autosave-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("249","3","2018-03-21 16:12:10","2018-03-21 14:12:10","Все дуже просто - достатньо натиснути на кнопку “Замовити” поряд з уподобаною моделлю та заповнити необхідні дані.

Далі ми зв\'яжемося з Вами для узгодження деталей замовлення.

Поспілкуватися з нами, щось уточнити та замовити також можливо по телефону, Viber, Telegram та e-mail.","Замовити","","inherit","closed","closed","","244-revision-v1","","","2018-03-21 16:12:10","2018-03-21 14:12:10","","244","http://golubika.local/244-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("250","3","2018-03-21 16:34:41","2018-03-21 14:34:41","<p>Order now directly from this website - just push the button within the craft you chose and submit.</p>
<p>Straight after that we will contact you to agree on all details.</p>
Do not hesitate to contact us via Viber, Telegram, e-mail.
","Order now!","","inherit","closed","closed","","246-autosave-v1","","","2018-03-21 16:34:41","2018-03-21 14:34:41","","246","http://golubika.local/246-autosave-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("251","3","2018-03-21 16:34:53","2018-03-21 14:34:53","<p>Order now directly from this website - just push the button within the craft you chose and submit.</p>
<p>Straight after that we will contact you to agree on all details.</p>
<p>Do not hesitate to contact us via Viber, Telegram, e-mail.</p>
","Order now!","","inherit","closed","closed","","246-revision-v1","","","2018-03-21 16:34:53","2018-03-21 14:34:53","","246","http://golubika.local/246-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("252","3","2018-03-21 16:37:30","2018-03-21 14:37:30","<p>Order now directly from this website - just push the button within the craft you chose and submit.</p>
<p>Straight after that we will contact you to agree on all details.</p>
<p>Do not hesitate to contact us via Viber, Telegram and e-mail.</p>
","Order now!","","inherit","closed","closed","","246-revision-v1","","","2018-03-21 16:37:30","2018-03-21 14:37:30","","246","http://golubika.local/246-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("253","3","2018-03-21 16:41:29","2018-03-21 14:41:29","Коли усі деталі узгоджені, ми запропонуємо один з наступних способів оплати:

1. Передоплата на карту ПриватБанк (реквізити ми повідомимо по смс)

або

2. Оплата при отриманні замовлення у відділенні Нової Пошти (вартість послуги складає 20 грн + 2% від суми замовлення).","Оплатити","","publish","open","open","","oplatiti","","","2018-03-21 16:45:28","2018-03-21 14:45:28","","0","http://golubika.local/?p=253","0","post","","0");
INSERT INTO `gol_posts` VALUES("254","3","2018-03-21 16:41:29","2018-03-21 14:41:29","","Оплатити","","inherit","closed","closed","","253-revision-v1","","","2018-03-21 16:41:29","2018-03-21 14:41:29","","253","http://golubika.local/253-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("255","3","2018-03-21 16:41:29","2018-03-21 14:41:29","After all details are agreed, we will ask you to pay online invoice (WayForPay system).","Payment","","publish","open","open","","payment","","","2018-03-21 16:47:18","2018-03-21 14:47:18","","0","http://golubika.local/?p=255","0","post","","0");
INSERT INTO `gol_posts` VALUES("256","3","2018-03-21 16:42:26","2018-03-21 14:42:26","","Payment","","inherit","closed","closed","","255-revision-v1","","","2018-03-21 16:42:26","2018-03-21 14:42:26","","255","http://golubika.local/255-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("257","3","2018-03-21 16:45:28","2018-03-21 14:45:28","Коли усі деталі узгоджені, ми запропонуємо один з наступних способів оплати:

1. Передоплата на карту ПриватБанк (реквізити ми повідомимо по смс)

або

2. Оплата при отриманні замовлення у відділенні Нової Пошти (вартість послуги складає 20 грн + 2% від суми замовлення).","Оплатити","","inherit","closed","closed","","253-revision-v1","","","2018-03-21 16:45:28","2018-03-21 14:45:28","","253","http://golubika.local/253-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("258","3","2018-03-21 16:46:45","2018-03-21 14:46:45","<p>After all details are agreed, we will ask you to pay online invoice (WayForPay system).</
","Payment","","inherit","closed","closed","","255-autosave-v1","","","2018-03-21 16:46:45","2018-03-21 14:46:45","","255","http://golubika.local/255-autosave-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("259","3","2018-03-21 16:47:18","2018-03-21 14:47:18","After all details are agreed, we will ask you to pay online invoice (WayForPay system).","Payment","","inherit","closed","closed","","255-revision-v1","","","2018-03-21 16:47:18","2018-03-21 14:47:18","","255","http://golubika.local/255-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("260","3","2018-03-21 16:51:27","2018-03-21 14:51:27","Ми здійснюємо доставку по Україні та усьому світу.

Доставка по Україні здійснюється Новою Поштою - на відділення або адресна доставка.

Доставка на відділення безкоштовна.","Отримати","","publish","open","open","","otrimati","","","2018-03-21 16:55:29","2018-03-21 14:55:29","","0","http://golubika.local/?p=260","0","post","","0");
INSERT INTO `gol_posts` VALUES("261","3","2018-03-21 16:51:27","2018-03-21 14:51:27","Ми здійснюємо доставку по Україні та усьому світу.

Доставка по Україні здійснюється Новою Поштою - на відділення або адресна доставка.

Доставка на відділення безкоштовна.","Отримати","","inherit","closed","closed","","260-revision-v1","","","2018-03-21 16:51:27","2018-03-21 14:51:27","","260","http://golubika.local/260-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("262","3","2018-03-21 16:51:27","2018-03-21 14:51:27","We provide worldwide shipping.

For European countries it will take 1-2 weeks approximately.

Delivery cost will be agreed with you in advance and invoiced additionally. For European countries it usually costs up to 10 dollars approx.","Delivery","","publish","open","open","","delivery","","","2018-03-21 16:54:57","2018-03-21 14:54:57","","0","http://golubika.local/?p=262","0","post","","0");
INSERT INTO `gol_posts` VALUES("263","3","2018-03-21 16:54:33","2018-03-21 14:54:33","We provide worldwide shipping.

For European countries it will take 1-2 weeks approximately.

Delivery cost will be agreed with you in advance and invoiced additionally. For European countries it usually costs up to 10 dollars approx.","Delivery","","inherit","closed","closed","","262-revision-v1","","","2018-03-21 16:54:33","2018-03-21 14:54:33","","262","http://golubika.local/262-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("266","3","2018-03-21 18:05:22","2018-03-21 16:05:22","Більшість виробів GOLUBIKA - це результат натхнення якоюсь конкретною людиною, її унікальністю та стилем. Так, готуючи подарунок на день народження Андрію, народилася чоловіча сумка на пояс. Він пряцює у дельфінарії та постійно носить усе із собою. Одного разу, на хендмейд-маркеті до мене підійшов Анатолій та спитав, чи можу я зробити йому cover на ноутбук.

Ми з радістю створимо щось унікальне для вас, про вас та разом з вами. Виконати вподобану модель у іншому кольорі, зробити авторський принт, створити сумку такої форми, про яку ви давно мрієте - ми з радістю попрацюємо над цим. Напишіть нам!","Індивідуальні замовлення","","publish","open","open","","individualni-zamovlennya","","","2018-03-21 19:13:17","2018-03-21 17:13:17","","0","http://golubika.local/?p=266","0","post","","0");
INSERT INTO `gol_posts` VALUES("267","3","2018-03-21 18:05:22","2018-03-21 16:05:22","Більшість виробів GOLUBIKA - це результат натхнення якоюсь конкретною людиною, її унікальністю та стилем. Так, готуючи подарунок на день народження Андрію, народилася чоловіча сумка на пояс. Він пряцює у дельфінарії та постійно носить усе із собою. Одного разу, на хендмейд-маркеті до мене підійшов Анатолій та спитав, чи можу я зробити йому cover на ноутбук.

Ми з радістю створимо щось унікальне для вас, про вас та разом з вами. Виконати вподобану модель у іншому кольорі, зробити авторський принт, створити сумку такої форми, про яку ви давно мрієте - ми з радістю попрацюємо над цим. Напишіть нам!","Індивідуальні замовлення","","inherit","closed","closed","","266-revision-v1","","","2018-03-21 18:05:22","2018-03-21 16:05:22","","266","http://golubika.local/266-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("268","3","2018-03-21 18:05:22","2018-03-21 16:05:22","Probably all Golubika for beloved crafts were made inspired by some person that I used to met. Unique style, characters, occupation. A men belt bag had been crafted when I was preparing a gift for my friend Andrew. He works at delfinarium and get used to carry all his stuff. He needs to have free hands for working with kids. Participating in a handmade market, I was addressed by Anatoly if I can create a cover for a laptop.

We will create something unique for you too with pleasure. It could be some our model produced in another color, or the bag shape that you are dreaming about. We’d love to collaborate on it!

Please, write to us and share your idea. Looking forward to your order.","Individual orders","","publish","open","open","","individual-orders","","","2018-03-21 18:33:51","2018-03-21 16:33:51","","0","http://golubika.local/?p=268","0","post","","0");
INSERT INTO `gol_posts` VALUES("269","3","2018-03-21 18:10:43","2018-03-21 16:10:43","Probably all Golubika for beloved crafts were made inspired by some person that I used to met. Unique style, characters, occupation. A men belt bag had been crafted when I was preparing a gift for my friend Andrew. He works at delfinarium and get used to carry all his stuff. He needs to have free hands for working with kids. Participating in a handmade market, I was addressed by Anatoly if I can create a cover for a laptop.

We will create something unique for you too with pleasure. It could be some our model produced in another color, or the bag shape that you are dreaming about. We’d love to collaborate on it!

Please, write to us and share your idea. Looking forward to your order.","Individual orders","","inherit","closed","closed","","268-revision-v1","","","2018-03-21 18:10:43","2018-03-21 16:10:43","","268","http://golubika.local/268-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("273","3","2018-03-21 19:12:39","2018-03-21 17:12:39","","Individual orders image","Individual orders image","inherit","open","closed","","processed-with-vsco-with-a6-preset","","","2018-03-21 19:44:07","2018-03-21 17:44:07","","266","http://golubika.local/wp-content/uploads/2018/03/Individual_order.jpg","0","attachment","image/jpeg","0");
INSERT INTO `gol_posts` VALUES("274","3","2018-03-21 19:49:26","2018-03-21 17:49:26","<p id=\"aboutFirstLine\">- це сумки та аксесуари з фетру, які створені з любов\'ю та натхненням зробити щось унікальне саме для вас.</p>
Ми прагнемо поєднати відчуття краси та практичність у користуванні, зробити наші вироби зручними та створеними для життя.

Ми віримо, що майстерність - в деталях: у комірці зі стічкою, за яку легко потягнути та дістати мобільний телефон, у невидимих магнітах, що легко відстібуються та надійно тримають, у принтах, що зроблені вручну стародавнім мистецтвом вибійки.

Ми не маємо наміру опанувати весь світ, бо знаємо, що своє до свого лине. Але відчуваємо, що наші вироби відгукнуться саме тим, для кого вони народилися.","Про нас","","publish","open","open","","pro-nas","","","2018-03-21 20:22:29","2018-03-21 18:22:29","","0","http://golubika.local/?p=274","0","post","","0");
INSERT INTO `gol_posts` VALUES("275","3","2018-03-21 19:49:26","2018-03-21 17:49:26","","Про нас","","inherit","closed","closed","","274-revision-v1","","","2018-03-21 19:49:26","2018-03-21 17:49:26","","274","http://golubika.local/274-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("276","3","2018-03-21 19:49:26","2018-03-21 17:49:26","<p id=\"aboutFirstLine\">- is felt bags and accessories brand created with love and inspiration to make something unique specially for you.</p>
We strive to combine a sense of beauty and ease of use by making our products comfortable and designed for life.

Here we believe that excellence is in details: like in a small belt strap with ribbon which helps you to easily get out your mobile phone, in invisible magnets that hold securely and could be easily detached, in our hand-made prints inspired by the ancient art of embossing technique.

We do not intend to seize the whole world cause we know everything has its own way. At the same time, we realize our crafts will be found everywhere by people whom they were created for.","About us","","publish","open","open","","about-us","","","2018-03-22 13:10:25","2018-03-22 11:10:25","","0","http://golubika.local/?p=276","0","post","","0");
INSERT INTO `gol_posts` VALUES("278","3","2018-03-21 19:50:37","2018-03-21 17:50:37","","About us","","inherit","closed","closed","","276-revision-v1","","","2018-03-21 19:50:37","2018-03-21 17:50:37","","276","http://golubika.local/276-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("279","3","2018-03-21 20:12:29","2018-03-21 18:12:29","<p id=\"aboutFirstLine\">- це сумки та аксесуари з фетру, які створені з любов\'ю та натхненням зробити щось унікальне саме для вас.</p>
Ми прагнемо поєднати відчуття краси та практичність у користуванні, зробити наші вироби зручними та створеними для життя.

Ми віримо, що майстерність - в деталях: у комірці зі стічкою, за яку легко потягнути та дістати мобільний телефон, у невидимих магнітах, що легко відстібуються та надійно тримають, у принтах, що зроблені вручну стародавнім мистецтвом вибійки.

Ми не маємо наміру опанувати весь світ, бо знаємо, що своє до свого лине. Але відчуваємо, що наші вироби відгукнуться саме тим, для кого вони народилися.","Про нас","","inherit","closed","closed","","274-autosave-v1","","","2018-03-21 20:12:29","2018-03-21 18:12:29","","274","http://golubika.local/274-autosave-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("280","3","2018-03-21 20:12:39","2018-03-21 18:12:39","<p id=\"aboutFirstLine\">- це сумки та аксесуари з фетру, які створені з любов\'ю та натхненням зробити щось унікальне саме для вас.</p>
Ми прагнемо поєднати відчуття краси та практичність у користуванні, зробити наші вироби зручними та створеними для життя.

Ми віримо, що майстерність - в деталях: у комірці зі стічкою, за яку легко потягнути та дістати мобільний телефон, у невидимих магнітах, що легко відстібуються та надійно тримають, у принтах, що зроблені вручну стародавнім мистецтвом вибійки.

Ми не маємо наміру опанувати весь світ, бо знаємо, що своє до свого лине. Але відчуваємо, що наші вироби відгукнуться саме тим, для кого вони народилися.","Про нас","","inherit","closed","closed","","274-revision-v1","","","2018-03-21 20:12:39","2018-03-21 18:12:39","","274","http://golubika.local/274-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("281","3","2018-03-22 13:06:13","2018-03-22 11:06:13","<p id=\"aboutFirstLine\">- are felt bags and accessories created with love and inspiration to make something unique specially for you.</p>
							<p>We strive to combine a sense of beauty and ease of use by making our products comfortable and designed for life. </p>
							<p>Here we believe that excellence is in details: like in a small belt strap with ribbon which helps you to easily get out your mobile phone, in invisible magnets that hold securely and could be easily detached, in our hand-made prints inspired by the ancient art of embossing technique. </p>
							<p>We do not intend to seize the whole world cause we know everything has its own way. At the same time, we realize our crafts will be found everywhere by people whom were born for.</p>","About us","","inherit","closed","closed","","276-autosave-v1","","","2018-03-22 13:06:13","2018-03-22 11:06:13","","276","http://golubika.local/276-autosave-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("282","3","2018-03-21 20:19:09","2018-03-21 18:19:09","Should be translated","About us","","inherit","closed","closed","","276-revision-v1","","","2018-03-21 20:19:09","2018-03-21 18:19:09","","276","http://golubika.local/276-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("283","3","2018-03-21 20:22:12","2018-03-21 18:22:12","","test","","inherit","open","closed","","test","","","2018-03-21 20:22:12","2018-03-21 18:22:12","","274","http://golubika.local/wp-content/uploads/2018/03/test.jpg","0","attachment","image/jpeg","0");
INSERT INTO `gol_posts` VALUES("284","3","2018-03-22 13:07:33","2018-03-22 11:07:33","<p id=\"aboutFirstLine\">- are felt bags and accessories created with love and inspiration to make something unique specially for you.</p>
We strive to combine a sense of beauty and ease of use by making our products comfortable and designed for life.

Here we believe that excellence is in details: like in a small belt strap with ribbon which helps you to easily get out your mobile phone, in invisible magnets that hold securely and could be easily detached, in our hand-made prints inspired by the ancient art of embossing technique.

We do not intend to seize the whole world cause we know everything has its own way. At the same time, we realize our crafts will be found everywhere by people whom they were born for.","About us","","inherit","closed","closed","","276-revision-v1","","","2018-03-22 13:07:33","2018-03-22 11:07:33","","276","http://golubika.local/276-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("285","3","2018-03-22 13:10:25","2018-03-22 11:10:25","<p id=\"aboutFirstLine\">- is felt bags and accessories brand created with love and inspiration to make something unique specially for you.</p>
We strive to combine a sense of beauty and ease of use by making our products comfortable and designed for life.

Here we believe that excellence is in details: like in a small belt strap with ribbon which helps you to easily get out your mobile phone, in invisible magnets that hold securely and could be easily detached, in our hand-made prints inspired by the ancient art of embossing technique.

We do not intend to seize the whole world cause we know everything has its own way. At the same time, we realize our crafts will be found everywhere by people whom they were created for.","About us","","inherit","closed","closed","","276-revision-v1","","","2018-03-22 13:10:25","2018-03-22 11:10:25","","276","http://golubika.local/276-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("309","3","2018-03-24 18:46:38","2018-03-24 16:46:38","","Контакты","","publish","open","open","","kontakty","","","2018-03-24 18:46:38","2018-03-24 16:46:38","","0","http://golubika.local/?p=309","0","post","","0");
INSERT INTO `gol_posts` VALUES("310","3","2018-03-24 18:46:38","2018-03-24 16:46:38","","Контакты","","inherit","closed","closed","","309-revision-v1","","","2018-03-24 18:46:38","2018-03-24 16:46:38","","309","http://golubika.local/309-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("311","3","2018-03-24 18:46:38","2018-03-24 16:46:38","","Contacts","","publish","open","open","","contacts","","","2018-03-24 19:10:21","2018-03-24 17:10:21","","0","http://golubika.local/?p=311","0","post","","0");
INSERT INTO `gol_posts` VALUES("312","3","2018-03-24 19:10:21","2018-03-24 17:10:21","","Contacts","","inherit","closed","closed","","311-revision-v1","","","2018-03-24 19:10:21","2018-03-24 17:10:21","","311","http://golubika.local/311-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("313","3","2018-03-26 12:43:42","2018-03-26 09:43:42","","Тестовий запис","","publish","open","open","","testovij-zapis","","","2018-03-26 12:43:42","2018-03-26 09:43:42","","0","http://golubika.local/?p=313","0","post","","0");
INSERT INTO `gol_posts` VALUES("314","3","2018-03-26 12:43:42","2018-03-26 09:43:42","","Тестовий запис","","inherit","closed","closed","","313-revision-v1","","","2018-03-26 12:43:42","2018-03-26 09:43:42","","313","http://golubika.local/313-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("315","3","2018-03-26 12:43:42","2018-03-26 09:43:42","","Test post","","publish","open","open","","test-post","","","2018-03-27 12:33:42","2018-03-27 09:33:42","","0","http://golubika.local/?p=315","0","post","","0");
INSERT INTO `gol_posts` VALUES("316","3","2018-03-27 12:33:33","2018-03-27 09:33:33","","Processed with VSCO with a6 preset","Processed with VSCO with a6 preset","inherit","open","closed","","processed-with-vsco-with-a6-preset-2","","","2018-03-27 12:33:33","2018-03-27 09:33:33","","315","http://golubika.local/wp-content/uploads/2018/03/Individual_order-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `gol_posts` VALUES("317","3","2018-03-27 12:33:42","2018-03-27 09:33:42","","Test post","","inherit","closed","closed","","315-revision-v1","","","2018-03-27 12:33:42","2018-03-27 09:33:42","","315","http://golubika.local/315-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("319","3","2018-04-01 18:39:01","2018-04-01 15:39:01","","Ще один тестовий запис","","publish","open","open","","shhe-odin-testovij-zapis","","","2018-04-01 18:39:01","2018-04-01 15:39:01","","0","http://golubika.local/?p=319","0","post","","0");
INSERT INTO `gol_posts` VALUES("320","3","2018-04-01 18:39:01","2018-04-01 15:39:01","","Ще один тестовий запис","","inherit","closed","closed","","319-revision-v1","","","2018-04-01 18:39:01","2018-04-01 15:39:01","","319","http://golubika.local/319-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("321","3","2018-04-01 18:39:01","2018-04-01 15:39:01","","Another test post","","publish","open","open","","another-test-post","","","2018-04-01 18:40:04","2018-04-01 15:40:04","","0","http://golubika.local/?p=321","0","post","","0");
INSERT INTO `gol_posts` VALUES("322","3","2018-04-01 18:40:04","2018-04-01 15:40:04","","Another test post","","inherit","closed","closed","","321-revision-v1","","","2018-04-01 18:40:04","2018-04-01 15:40:04","","321","http://golubika.local/321-revision-v1/","0","revision","","0");
INSERT INTO `gol_posts` VALUES("323","3","2018-04-16 20:40:11","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2018-04-16 20:40:11","0000-00-00 00:00:00","","0","http://golubika.local/?p=323","0","post","","0");
INSERT INTO `gol_posts` VALUES("324","3","2018-04-17 17:17:29","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2018-04-17 17:17:29","0000-00-00 00:00:00","","0","http://golubika.local/?p=324","0","post","","0");
INSERT INTO `gol_posts` VALUES("325","3","2018-04-18 18:41:42","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2018-04-18 18:41:42","0000-00-00 00:00:00","","0","http://golubika.local/?p=325","0","post","","0");
INSERT INTO `gol_posts` VALUES("326","3","2018-04-18 19:22:03","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2018-04-18 19:22:03","0000-00-00 00:00:00","","0","http://golubika.local/?p=326","0","post","","0");


DROP TABLE IF EXISTS `gol_term_relationships`;

CREATE TABLE `gol_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `gol_term_relationships` VALUES("1","6","0");
INSERT INTO `gol_term_relationships` VALUES("1","50","0");
INSERT INTO `gol_term_relationships` VALUES("4","6","0");
INSERT INTO `gol_term_relationships` VALUES("4","40","0");
INSERT INTO `gol_term_relationships` VALUES("45","9","0");
INSERT INTO `gol_term_relationships` VALUES("45","40","0");
INSERT INTO `gol_term_relationships` VALUES("73","6","0");
INSERT INTO `gol_term_relationships` VALUES("73","74","0");
INSERT INTO `gol_term_relationships` VALUES("75","9","0");
INSERT INTO `gol_term_relationships` VALUES("75","74","0");
INSERT INTO `gol_term_relationships` VALUES("80","6","0");
INSERT INTO `gol_term_relationships` VALUES("80","81","0");
INSERT INTO `gol_term_relationships` VALUES("82","9","0");
INSERT INTO `gol_term_relationships` VALUES("82","81","0");
INSERT INTO `gol_term_relationships` VALUES("85","6","0");
INSERT INTO `gol_term_relationships` VALUES("85","86","0");
INSERT INTO `gol_term_relationships` VALUES("87","9","0");
INSERT INTO `gol_term_relationships` VALUES("87","86","0");
INSERT INTO `gol_term_relationships` VALUES("89","6","0");
INSERT INTO `gol_term_relationships` VALUES("89","90","0");
INSERT INTO `gol_term_relationships` VALUES("91","9","0");
INSERT INTO `gol_term_relationships` VALUES("91","90","0");
INSERT INTO `gol_term_relationships` VALUES("93","6","0");
INSERT INTO `gol_term_relationships` VALUES("93","94","0");
INSERT INTO `gol_term_relationships` VALUES("95","9","0");
INSERT INTO `gol_term_relationships` VALUES("95","94","0");
INSERT INTO `gol_term_relationships` VALUES("101","6","0");
INSERT INTO `gol_term_relationships` VALUES("101","102","0");
INSERT INTO `gol_term_relationships` VALUES("103","9","0");
INSERT INTO `gol_term_relationships` VALUES("103","102","0");
INSERT INTO `gol_term_relationships` VALUES("107","6","0");
INSERT INTO `gol_term_relationships` VALUES("107","108","0");
INSERT INTO `gol_term_relationships` VALUES("109","9","0");
INSERT INTO `gol_term_relationships` VALUES("109","108","0");
INSERT INTO `gol_term_relationships` VALUES("110","6","0");
INSERT INTO `gol_term_relationships` VALUES("110","111","0");
INSERT INTO `gol_term_relationships` VALUES("112","9","0");
INSERT INTO `gol_term_relationships` VALUES("112","111","0");
INSERT INTO `gol_term_relationships` VALUES("125","9","0");
INSERT INTO `gol_term_relationships` VALUES("125","50","0");
INSERT INTO `gol_term_relationships` VALUES("129","6","0");
INSERT INTO `gol_term_relationships` VALUES("129","130","0");
INSERT INTO `gol_term_relationships` VALUES("131","9","0");
INSERT INTO `gol_term_relationships` VALUES("131","130","0");
INSERT INTO `gol_term_relationships` VALUES("244","5","0");
INSERT INTO `gol_term_relationships` VALUES("244","110","0");
INSERT INTO `gol_term_relationships` VALUES("244","114","0");
INSERT INTO `gol_term_relationships` VALUES("246","8","0");
INSERT INTO `gol_term_relationships` VALUES("246","112","0");
INSERT INTO `gol_term_relationships` VALUES("246","114","0");
INSERT INTO `gol_term_relationships` VALUES("253","5","0");
INSERT INTO `gol_term_relationships` VALUES("253","110","0");
INSERT INTO `gol_term_relationships` VALUES("253","115","0");
INSERT INTO `gol_term_relationships` VALUES("255","8","0");
INSERT INTO `gol_term_relationships` VALUES("255","112","0");
INSERT INTO `gol_term_relationships` VALUES("255","115","0");
INSERT INTO `gol_term_relationships` VALUES("260","5","0");
INSERT INTO `gol_term_relationships` VALUES("260","110","0");
INSERT INTO `gol_term_relationships` VALUES("260","118","0");
INSERT INTO `gol_term_relationships` VALUES("262","8","0");
INSERT INTO `gol_term_relationships` VALUES("262","112","0");
INSERT INTO `gol_term_relationships` VALUES("262","118","0");
INSERT INTO `gol_term_relationships` VALUES("266","1","0");
INSERT INTO `gol_term_relationships` VALUES("266","5","0");
INSERT INTO `gol_term_relationships` VALUES("266","123","0");
INSERT INTO `gol_term_relationships` VALUES("268","8","0");
INSERT INTO `gol_term_relationships` VALUES("268","123","0");
INSERT INTO `gol_term_relationships` VALUES("268","125","0");
INSERT INTO `gol_term_relationships` VALUES("273","5","0");
INSERT INTO `gol_term_relationships` VALUES("273","133","0");
INSERT INTO `gol_term_relationships` VALUES("274","1","0");
INSERT INTO `gol_term_relationships` VALUES("274","5","0");
INSERT INTO `gol_term_relationships` VALUES("274","127","0");
INSERT INTO `gol_term_relationships` VALUES("276","8","0");
INSERT INTO `gol_term_relationships` VALUES("276","125","0");
INSERT INTO `gol_term_relationships` VALUES("276","127","0");
INSERT INTO `gol_term_relationships` VALUES("283","5","0");
INSERT INTO `gol_term_relationships` VALUES("309","1","0");
INSERT INTO `gol_term_relationships` VALUES("309","5","0");
INSERT INTO `gol_term_relationships` VALUES("309","134","0");
INSERT INTO `gol_term_relationships` VALUES("311","8","0");
INSERT INTO `gol_term_relationships` VALUES("311","125","0");
INSERT INTO `gol_term_relationships` VALUES("311","134","0");
INSERT INTO `gol_term_relationships` VALUES("313","5","0");
INSERT INTO `gol_term_relationships` VALUES("313","73","0");
INSERT INTO `gol_term_relationships` VALUES("313","135","0");
INSERT INTO `gol_term_relationships` VALUES("315","8","0");
INSERT INTO `gol_term_relationships` VALUES("315","75","0");
INSERT INTO `gol_term_relationships` VALUES("315","135","0");
INSERT INTO `gol_term_relationships` VALUES("316","8","0");
INSERT INTO `gol_term_relationships` VALUES("319","5","0");
INSERT INTO `gol_term_relationships` VALUES("319","73","0");
INSERT INTO `gol_term_relationships` VALUES("319","136","0");
INSERT INTO `gol_term_relationships` VALUES("321","8","0");
INSERT INTO `gol_term_relationships` VALUES("321","75","0");
INSERT INTO `gol_term_relationships` VALUES("321","136","0");
INSERT INTO `gol_term_relationships` VALUES("323","5","0");
INSERT INTO `gol_term_relationships` VALUES("324","5","0");
INSERT INTO `gol_term_relationships` VALUES("325","5","0");
INSERT INTO `gol_term_relationships` VALUES("326","5","0");


DROP TABLE IF EXISTS `gol_term_taxonomy`;

CREATE TABLE `gol_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `gol_term_taxonomy` VALUES("1","1","category","","0","3");
INSERT INTO `gol_term_taxonomy` VALUES("4","4","category","","129","0");
INSERT INTO `gol_term_taxonomy` VALUES("5","5","language","a:3:{s:6:\"locale\";s:2:\"uk\";s:3:\"rtl\";i:0;s:9:\"flag_code\";s:0:\"\";}","0","10");
INSERT INTO `gol_term_taxonomy` VALUES("6","6","term_language","","0","11");
INSERT INTO `gol_term_taxonomy` VALUES("7","7","term_translations","a:2:{s:2:\"uk\";i:1;s:2:\"en\";i:10;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("8","8","language","a:3:{s:6:\"locale\";s:5:\"en_GB\";s:3:\"rtl\";i:0;s:9:\"flag_code\";s:0:\"\";}","0","9");
INSERT INTO `gol_term_taxonomy` VALUES("9","9","term_language","","0","11");
INSERT INTO `gol_term_taxonomy` VALUES("16","16","term_translations","a:2:{s:2:\"uk\";i:4;s:2:\"en\";i:22;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("30","30","product_visibility","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("31","31","product_visibility","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("32","32","product_visibility","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("33","33","product_visibility","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("34","34","product_visibility","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("35","35","product_visibility","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("36","36","product_visibility","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("37","37","product_visibility","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("38","38","product_visibility","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("40","40","term_translations","a:2:{s:2:\"uk\";i:4;s:2:\"en\";i:45;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("45","45","category","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("50","50","term_translations","a:2:{s:2:\"uk\";i:1;s:2:\"en\";i:125;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("73","73","category","","129","2");
INSERT INTO `gol_term_taxonomy` VALUES("74","74","term_translations","a:2:{s:2:\"uk\";i:73;s:2:\"en\";i:75;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("75","75","category","","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("80","80","category","","129","0");
INSERT INTO `gol_term_taxonomy` VALUES("81","81","term_translations","a:2:{s:2:\"uk\";i:80;s:2:\"en\";i:82;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("82","82","category","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("85","85","category","","129","0");
INSERT INTO `gol_term_taxonomy` VALUES("86","86","term_translations","a:2:{s:2:\"uk\";i:85;s:2:\"en\";i:87;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("87","87","category","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("89","89","category","","85","0");
INSERT INTO `gol_term_taxonomy` VALUES("90","90","term_translations","a:2:{s:2:\"uk\";i:89;s:2:\"en\";i:91;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("91","91","category","","87","0");
INSERT INTO `gol_term_taxonomy` VALUES("93","93","category","","85","0");
INSERT INTO `gol_term_taxonomy` VALUES("94","94","term_translations","a:2:{s:2:\"uk\";i:93;s:2:\"en\";i:95;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("95","95","category","","87","0");
INSERT INTO `gol_term_taxonomy` VALUES("101","101","category","","129","0");
INSERT INTO `gol_term_taxonomy` VALUES("102","102","term_translations","a:2:{s:2:\"uk\";i:101;s:2:\"en\";i:103;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("103","103","category","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("107","107","category","","129","0");
INSERT INTO `gol_term_taxonomy` VALUES("108","108","term_translations","a:2:{s:2:\"uk\";i:107;s:2:\"en\";i:109;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("109","109","category","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("110","110","category","","0","3");
INSERT INTO `gol_term_taxonomy` VALUES("111","111","term_translations","a:2:{s:2:\"uk\";i:110;s:2:\"en\";i:112;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("112","112","category","","0","3");
INSERT INTO `gol_term_taxonomy` VALUES("114","114","post_translations","a:2:{s:2:\"en\";i:246;s:2:\"uk\";i:244;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("115","115","post_translations","a:2:{s:2:\"en\";i:255;s:2:\"uk\";i:253;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("118","118","post_translations","a:2:{s:2:\"en\";i:262;s:2:\"uk\";i:260;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("123","123","post_translations","a:2:{s:2:\"en\";i:268;s:2:\"uk\";i:266;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("125","125","category","","0","3");
INSERT INTO `gol_term_taxonomy` VALUES("127","127","post_translations","a:2:{s:2:\"en\";i:276;s:2:\"uk\";i:274;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("129","129","category","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("130","130","term_translations","a:2:{s:2:\"uk\";i:129;s:2:\"en\";i:131;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("131","131","category","","0","0");
INSERT INTO `gol_term_taxonomy` VALUES("133","133","post_translations","a:1:{s:2:\"uk\";i:273;}","0","1");
INSERT INTO `gol_term_taxonomy` VALUES("134","134","post_translations","a:2:{s:2:\"en\";i:311;s:2:\"uk\";i:309;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("135","135","post_translations","a:2:{s:2:\"en\";i:315;s:2:\"uk\";i:313;}","0","2");
INSERT INTO `gol_term_taxonomy` VALUES("136","136","post_translations","a:2:{s:2:\"en\";i:321;s:2:\"uk\";i:319;}","0","2");


DROP TABLE IF EXISTS `gol_termmeta`;

CREATE TABLE `gol_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `gol_terms`;

CREATE TABLE `gol_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `gol_terms` VALUES("1","Без рубрики","bez-rubriki","0");
INSERT INTO `gol_terms` VALUES("4","Наші історії","stories_ua","0");
INSERT INTO `gol_terms` VALUES("5","Українська","uk","1");
INSERT INTO `gol_terms` VALUES("6","Українська","pll_uk","0");
INSERT INTO `gol_terms` VALUES("7","pll_5a7edfb6083fb","pll_5a7edfb6083fb","0");
INSERT INTO `gol_terms` VALUES("8","English","en","0");
INSERT INTO `gol_terms` VALUES("9","English","pll_en","0");
INSERT INTO `gol_terms` VALUES("16","pll_5a7efc3aad5c2","pll_5a7efc3aad5c2","0");
INSERT INTO `gol_terms` VALUES("30","exclude-from-search","exclude-from-search","0");
INSERT INTO `gol_terms` VALUES("31","exclude-from-catalog","exclude-from-catalog","0");
INSERT INTO `gol_terms` VALUES("32","featured","featured","0");
INSERT INTO `gol_terms` VALUES("33","outofstock","outofstock","0");
INSERT INTO `gol_terms` VALUES("34","rated-1","rated-1","0");
INSERT INTO `gol_terms` VALUES("35","rated-2","rated-2","0");
INSERT INTO `gol_terms` VALUES("36","rated-3","rated-3","0");
INSERT INTO `gol_terms` VALUES("37","rated-4","rated-4","0");
INSERT INTO `gol_terms` VALUES("38","rated-5","rated-5","0");
INSERT INTO `gol_terms` VALUES("40","pll_5a917a8052009","pll_5a917a8052009","0");
INSERT INTO `gol_terms` VALUES("45","Our stories","stories_en","0");
INSERT INTO `gol_terms` VALUES("50","pll_5a91bf402f65d","pll_5a91bf402f65d","0");
INSERT INTO `gol_terms` VALUES("73","Нова колекція","new_collection_ua","0");
INSERT INTO `gol_terms` VALUES("74","pll_5a9fd5f9b3eaa","pll_5a9fd5f9b3eaa","0");
INSERT INTO `gol_terms` VALUES("75","New collection","new_collection_en","0");
INSERT INTO `gol_terms` VALUES("80","Сумки","bags_ua","0");
INSERT INTO `gol_terms` VALUES("81","pll_5aa957ec26175","pll_5aa957ec26175","0");
INSERT INTO `gol_terms` VALUES("82","Bags","bags_en","0");
INSERT INTO `gol_terms` VALUES("85","Аксесуари","accessories_main_ua","0");
INSERT INTO `gol_terms` VALUES("86","pll_5aaa6bde608ed","pll_5aaa6bde608ed","0");
INSERT INTO `gol_terms` VALUES("87","Accessories","accessories_main_en","0");
INSERT INTO `gol_terms` VALUES("89","Аксесуари великі","accessories_big_ua","0");
INSERT INTO `gol_terms` VALUES("90","pll_5aaa701dc9668","pll_5aaa701dc9668","0");
INSERT INTO `gol_terms` VALUES("91","Accessories big","accessories_big_en","0");
INSERT INTO `gol_terms` VALUES("93","Аксесуари дрібні","accessories_small_ua","0");
INSERT INTO `gol_terms` VALUES("94","pll_5aaa7211a4d04","pll_5aaa7211a4d04","0");
INSERT INTO `gol_terms` VALUES("95","Accessories small","accessories_small_en","0");
INSERT INTO `gol_terms` VALUES("101","Чоловікам","for_men_ua","0");
INSERT INTO `gol_terms` VALUES("102","pll_5aae69bab637f","pll_5aae69bab637f","0");
INSERT INTO `gol_terms` VALUES("103","For men","for_men_en","0");
INSERT INTO `gol_terms` VALUES("107","Розпродаж","sale_ua","0");
INSERT INTO `gol_terms` VALUES("108","pll_5aae94f979aef","pll_5aae94f979aef","0");
INSERT INTO `gol_terms` VALUES("109","Sale","sale_en","0");
INSERT INTO `gol_terms` VALUES("110","Як замовити","how_to_order_ua","0");
INSERT INTO `gol_terms` VALUES("111","pll_5ab25b7433b5d","pll_5ab25b7433b5d","0");
INSERT INTO `gol_terms` VALUES("112","How to order","how_to_order_en","0");
INSERT INTO `gol_terms` VALUES("114","pll_5ab25ea98726a","pll_5ab25ea98726a","0");
INSERT INTO `gol_terms` VALUES("115","pll_5ab26f522e4d5","pll_5ab26f522e4d5","0");
INSERT INTO `gol_terms` VALUES("118","pll_5ab27228ee6ce","pll_5ab27228ee6ce","0");
INSERT INTO `gol_terms` VALUES("123","pll_5ab284039efb9","pll_5ab284039efb9","0");
INSERT INTO `gol_terms` VALUES("125","Without category","bez-rubriki_en","0");
INSERT INTO `gol_terms` VALUES("127","pll_5ab29b6d63111","pll_5ab29b6d63111","0");
INSERT INTO `gol_terms` VALUES("129","Каталог","catalog_ua","0");
INSERT INTO `gol_terms` VALUES("130","pll_5ab3a1ba57abe","pll_5ab3a1ba57abe","0");
INSERT INTO `gol_terms` VALUES("131","Catalog","catalog_en","0");
INSERT INTO `gol_terms` VALUES("133","pll_5ab67d9d9a5c7","pll_5ab67d9d9a5c7","0");
INSERT INTO `gol_terms` VALUES("134","pll_5ab6867cd4108","pll_5ab6867cd4108","0");
INSERT INTO `gol_terms` VALUES("135","pll_5aba0ff6261cc","pll_5aba0ff6261cc","0");
INSERT INTO `gol_terms` VALUES("136","pll_5ac0fd53d647d","pll_5ac0fd53d647d","0");


DROP TABLE IF EXISTS `gol_usermeta`;

CREATE TABLE `gol_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `gol_usermeta` VALUES("53","3","nickname","sergdidyk_golbags");
INSERT INTO `gol_usermeta` VALUES("54","3","first_name","");
INSERT INTO `gol_usermeta` VALUES("55","3","last_name","");
INSERT INTO `gol_usermeta` VALUES("56","3","description","");
INSERT INTO `gol_usermeta` VALUES("57","3","rich_editing","true");
INSERT INTO `gol_usermeta` VALUES("58","3","syntax_highlighting","true");
INSERT INTO `gol_usermeta` VALUES("59","3","comment_shortcuts","false");
INSERT INTO `gol_usermeta` VALUES("60","3","admin_color","fresh");
INSERT INTO `gol_usermeta` VALUES("61","3","use_ssl","0");
INSERT INTO `gol_usermeta` VALUES("62","3","show_admin_bar_front","true");
INSERT INTO `gol_usermeta` VALUES("63","3","locale","");
INSERT INTO `gol_usermeta` VALUES("64","3","gol_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `gol_usermeta` VALUES("65","3","gol_user_level","10");
INSERT INTO `gol_usermeta` VALUES("66","3","dismissed_wp_pointers","pll_lgt");
INSERT INTO `gol_usermeta` VALUES("67","3","session_tokens","a:1:{s:64:\"8d134bbcc4fada9e088e800c2c1a5ac366a794e7730ec20e4a54e3a286b2790e\";a:4:{s:10:\"expiration\";i:1524241322;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36\";s:5:\"login\";i:1524068522;}}");
INSERT INTO `gol_usermeta` VALUES("68","3","last_login_time","2018-04-18 19:22:02");
INSERT INTO `gol_usermeta` VALUES("69","3","gol_dashboard_quick_press_last_post_id","326");
INSERT INTO `gol_usermeta` VALUES("70","3","community-events-location","a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}");


DROP TABLE IF EXISTS `gol_users`;

CREATE TABLE `gol_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `gol_users` VALUES("3","sergdidyk_golbags","$P$Bx3.7lpIvv64hVK7WF.wIAUMuQdZvK0","sergdidyk_golbags","serg.didyk@gmail.com","","2018-04-18 16:21:12","1524068473:$P$BUUTvq1E49f6nXpRzoWQJVrmj/hvD8/","0","sergdidyk_golbags");


DROP TABLE IF EXISTS `gol_wc_download_log`;

CREATE TABLE `gol_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `gol_wc_webhooks`;

CREATE TABLE `gol_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `gol_woocommerce_log`;

CREATE TABLE `gol_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



