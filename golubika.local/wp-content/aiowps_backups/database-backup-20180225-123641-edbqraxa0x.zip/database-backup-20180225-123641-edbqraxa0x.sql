-- All In One WP Security & Firewall 4.3.2
-- MySQL dump
-- 2018-02-25 10:36:41

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp_UPCP_Catalogue_Items`;

CREATE TABLE `wp_UPCP_Catalogue_Items` (
  `Catalogue_Item_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Catalogue_ID` mediumint(9) DEFAULT '0',
  `Item_ID` mediumint(9) DEFAULT '0',
  `Category_ID` mediumint(9) DEFAULT '0',
  `SubCategory_ID` mediumint(9) DEFAULT '0',
  `Position` mediumint(9) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`Catalogue_Item_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_UPCP_Catalogues`;

CREATE TABLE `wp_UPCP_Catalogues` (
  `Catalogue_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Catalogue_Name` text NOT NULL,
  `Catalogue_Description` text NOT NULL,
  `Catalogue_Layout_Format` text NOT NULL,
  `Catalogue_Custom_CSS` text NOT NULL,
  `Catalogue_Item_Count` mediumint(9) NOT NULL DEFAULT '0',
  `Catalogue_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  UNIQUE KEY `id` (`Catalogue_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `wp_UPCP_Catalogues` VALUES("1","Sample Catalogue","This is where your description of this catalogue would go.","","","0","0000-00-00 00:00:00");


DROP TABLE IF EXISTS `wp_UPCP_Categories`;

CREATE TABLE `wp_UPCP_Categories` (
  `Category_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Category_Name` text NOT NULL,
  `Category_Description` text NOT NULL,
  `Category_Image` text NOT NULL,
  `Category_Item_Count` mediumint(9) DEFAULT '0',
  `Category_Sidebar_Order` mediumint(9) DEFAULT '9999',
  `Category_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Category_WC_ID` mediumint(9) DEFAULT '0',
  UNIQUE KEY `id` (`Category_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `wp_UPCP_Categories` VALUES("1","Sample Category","This is where your description of this category would go.","","1","9999","0000-00-00 00:00:00","0");


DROP TABLE IF EXISTS `wp_UPCP_Custom_Fields`;

CREATE TABLE `wp_UPCP_Custom_Fields` (
  `Field_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Field_Name` text NOT NULL,
  `Field_Slug` text NOT NULL,
  `Field_Type` text NOT NULL,
  `Field_Description` text NOT NULL,
  `Field_Values` text NOT NULL,
  `Field_Displays` text NOT NULL,
  `Field_Searchable` text NOT NULL,
  `Field_Sidebar_Order` mediumint(9) DEFAULT '9999',
  `Field_Display_Tabbed` text NOT NULL,
  `Field_Control_Type` text NOT NULL,
  `Field_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Field_WC_ID` mediumint(9) DEFAULT '0',
  UNIQUE KEY `id` (`Field_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_UPCP_Fields_Meta`;

CREATE TABLE `wp_UPCP_Fields_Meta` (
  `Meta_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Field_ID` mediumint(9) DEFAULT '0',
  `Item_ID` mediumint(9) DEFAULT '0',
  `Meta_Value` text NOT NULL,
  UNIQUE KEY `id` (`Meta_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_UPCP_Item_Images`;

CREATE TABLE `wp_UPCP_Item_Images` (
  `Item_Image_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Item_ID` mediumint(9) NOT NULL DEFAULT '0',
  `Item_Image_URL` text,
  `Item_Image_Description` text,
  `Item_Image_Order` mediumint(9) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`Item_Image_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_UPCP_Items`;

CREATE TABLE `wp_UPCP_Items` (
  `Item_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Item_Name` text NOT NULL,
  `Item_Slug` text NOT NULL,
  `Item_Description` text,
  `Item_Price` text NOT NULL,
  `Item_Sale_Price` text NOT NULL,
  `Item_Sale_Mode` text NOT NULL,
  `Item_Link` text,
  `Item_Photo_URL` text,
  `Category_ID` mediumint(9) DEFAULT '0',
  `Category_Name` text,
  `Global_Item_ID` mediumint(9) DEFAULT '0',
  `Item_Special_Attr` text,
  `SubCategory_ID` mediumint(9) DEFAULT '0',
  `SubCategory_Name` text,
  `Item_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Item_Views` mediumint(9) DEFAULT '0',
  `Item_Display_Status` text,
  `Item_Related_Products` text,
  `Item_Next_Previous` text,
  `Item_SEO_Description` text,
  `Item_Category_Product_Order` mediumint(9) DEFAULT '9999',
  `Item_WC_ID` mediumint(9) DEFAULT '0',
  UNIQUE KEY `id` (`Item_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `wp_UPCP_Items` VALUES("1","Sample Item","","This is where your description of this product would go.","9.99","","","","http://golubika.local/wp-content/plugins/ultimate-product-catalogue/images/sample_image.jpg","1","Sample Category","0","","0","","0000-00-00 00:00:00","0","","","","","9999","0");


DROP TABLE IF EXISTS `wp_UPCP_SubCategories`;

CREATE TABLE `wp_UPCP_SubCategories` (
  `SubCategory_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Category_ID` mediumint(9) NOT NULL DEFAULT '0',
  `Category_Name` text NOT NULL,
  `SubCategory_Name` text NOT NULL,
  `SubCategory_Description` text NOT NULL,
  `SubCategory_Image` text NOT NULL,
  `SubCategory_Item_Count` mediumint(9) NOT NULL DEFAULT '0',
  `SubCategory_Sidebar_Order` mediumint(9) DEFAULT '9999',
  `SubCategory_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `SubCategory_WC_ID` mediumint(9) DEFAULT '0',
  UNIQUE KEY `id` (`SubCategory_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_UPCP_Tag_Groups`;

CREATE TABLE `wp_UPCP_Tag_Groups` (
  `Tag_Group_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Tag_Group_Name` text NOT NULL,
  `Tag_Group_Description` text NOT NULL,
  `Display_Tag_Group` text NOT NULL,
  `Tag_Group_Order` mediumint(9) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`Tag_Group_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_UPCP_Tagged_Items`;

CREATE TABLE `wp_UPCP_Tagged_Items` (
  `Tagged_Item_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Tag_ID` mediumint(9) NOT NULL DEFAULT '0',
  `Item_ID` mediumint(9) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`Tagged_Item_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_UPCP_Tags`;

CREATE TABLE `wp_UPCP_Tags` (
  `Tag_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Tag_Name` text NOT NULL,
  `Tag_Description` text NOT NULL,
  `Tag_Item_Count` text NOT NULL,
  `Tag_Group_ID` mediumint(9) NOT NULL DEFAULT '0',
  `Tag_Sidebar_Order` mediumint(9) DEFAULT '9999',
  `Tag_Date_Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Tag_WC_ID` mediumint(9) DEFAULT '0',
  UNIQUE KEY `id` (`Tag_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_UPCP_Videos`;

CREATE TABLE `wp_UPCP_Videos` (
  `Item_Video_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `Item_ID` mediumint(9) NOT NULL DEFAULT '0',
  `Item_Video_URL` text,
  `Item_Video_Type` text,
  `Item_Video_Order` mediumint(9) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`Item_Video_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_aiowps_login_activity` VALUES("1","1","admin","2018-02-11 16:38:23","0000-00-00 00:00:00","127.0.0.1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("2","1","admin","2018-02-19 18:31:48","0000-00-00 00:00:00","127.0.0.1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("3","1","admin","2018-02-24 16:32:10","0000-00-00 00:00:00","127.0.0.1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("4","1","admin","2018-02-24 20:43:31","0000-00-00 00:00:00","127.0.0.1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("5","1","admin","2018-02-24 20:43:31","0000-00-00 00:00:00","127.0.0.1","","");


DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=799 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://golubika.local","yes");
INSERT INTO `wp_options` VALUES("2","home","http://golubika.local","yes");
INSERT INTO `wp_options` VALUES("3","blogname","Golubika","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","Felt bags&amp;accessories","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","serg.didyk@gmail.com","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("23","date_format","d.m.Y","yes");
INSERT INTO `wp_options` VALUES("24","time_format","H:i","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","d.m.Y H:i","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/%postname%/","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:3:{i:0;s:21:\"polylang/polylang.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:22:\"cyr3lat/cyr-to-lat.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("37","gmt_offset","","yes");
INSERT INTO `wp_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("39","recently_edited","","no");
INSERT INTO `wp_options` VALUES("40","template","Golubika","yes");
INSERT INTO `wp_options` VALUES("41","stylesheet","Golubika","yes");
INSERT INTO `wp_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `wp_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("48","db_version","38590","yes");
INSERT INTO `wp_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("50","upload_path","","yes");
INSERT INTO `wp_options` VALUES("51","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("53","show_on_front","posts","yes");
INSERT INTO `wp_options` VALUES("54","tag_base","","yes");
INSERT INTO `wp_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `wp_options` VALUES("67","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("68","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `wp_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("73","page_comments","0","yes");
INSERT INTO `wp_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("79","widget_text","a:5:{i:2;a:4:{s:5:\"title\";s:21:\"Найдите нас\";s:4:\"text\";s:226:\"<strong>Адрес</strong>
123 Мейн стрит
Нью Йорк, NY 10001

<strong>Часы</strong>
Понедельник&mdash;пятница: 9:00&ndash;17:00
Суббота и воскресенье: 11:00&ndash;15:00\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:3;a:4:{s:5:\"title\";s:13:\"О сайте\";s:4:\"text\";s:205:\"Здесь может быть отличное место для того, чтобы представить себя, свой сайт или выразить какие-то благодарности.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:4;a:4:{s:5:\"title\";s:21:\"Найдите нас\";s:4:\"text\";s:226:\"<strong>Адрес</strong>
123 Мейн стрит
Нью Йорк, NY 10001

<strong>Часы</strong>
Понедельник&mdash;пятница: 9:00&ndash;17:00
Суббота и воскресенье: 11:00&ndash;15:00\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:5;a:4:{s:5:\"title\";s:13:\"О сайте\";s:4:\"text\";s:205:\"Здесь может быть отличное место для того, чтобы представить себя, свой сайт или выразить какие-то благодарности.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("81","uninstall_plugins","a:0:{}","no");
INSERT INTO `wp_options` VALUES("82","timezone_string","Europe/Kiev","yes");
INSERT INTO `wp_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("84","page_on_front","0","yes");
INSERT INTO `wp_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("88","site_icon","0","yes");
INSERT INTO `wp_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("91","initial_db_version","38590","yes");
INSERT INTO `wp_options` VALUES("92","wp_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("93","fresh_site","0","yes");
INSERT INTO `wp_options` VALUES("94","WPLANG","ru_RU","yes");
INSERT INTO `wp_options` VALUES("95","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("96","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("97","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("98","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("99","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("100","sidebars_widgets","a:5:{s:19:\"wp_inactive_widgets\";a:10:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:6:\"text-4\";i:3;s:6:\"text-5\";i:4;s:8:\"search-2\";i:5;s:14:\"recent-posts-2\";i:6;s:17:\"recent-comments-2\";i:7;s:10:\"archives-2\";i:8;s:12:\"categories-2\";i:9;s:6:\"meta-2\";}s:8:\"logo_nav\";a:1:{i:0;s:13:\"custom_html-4\";}s:10:\"logo_about\";a:1:{i:0;s:13:\"custom_html-5\";}s:11:\"logo_footer\";a:1:{i:0;s:13:\"custom_html-6\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("101","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("102","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("103","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("104","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("105","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("106","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("107","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("108","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("109","widget_custom_html","a:4:{i:4;a:2:{s:5:\"title\";s:17:\"Лого меню\";s:7:\"content\";s:12031:\"<svg class=\"logo_nav\"
	        xmlns=\"http://www.w3.org/2000/svg\"
	 				viewbox=\"0 0 3133.6245 931.25458\"
	 				id=\"svg4485\"
	 				version=\"1.1\">
	 				<path
	   				id=\"path4495\"
	   				d=\"m 629.30122,842.7541 v -88.5 h 66 66 v 9 9 h -57 -57 v 26.5 26.5 h 35 35 v 9 9 h -35 -35 v 44 44 h -9 -9 z m 211.65975,87.52067 c -34.47599,-6.27297 -61.7046,-31.47756 -70.78222,-65.52067 -3.05474,-11.45594 -3.0869,-30.63469 -0.0718,-42.80135 8.12584,-32.78951 32.23466,-56.92548 65.19425,-65.26768 10.60111,-2.68319 28.61274,-2.47821 39.5,0.44952 16.38958,4.40738 29.65943,12.31595 41.5329,24.75279 11.794,12.35361 17.93771,23.7875 22.12701,41.17996 2.54057,10.54752 2.78654,27.3125 0.55317,37.70328 -7.08298,32.95362 -30.77549,58.39031 -62.88671,67.51628 -8.27874,2.35281 -27.26305,3.42594 -35.16662,1.98787 z m 30.47728,-19.55037 c 23.03887,-5.94895 42.76883,-26.14244 48.87705,-50.02536 2.41886,-9.45766 2.63029,-25.08622 0.4637,-34.27658 -2.02121,-8.57371 -7.19606,-19.37624 -12.86636,-26.8586 -20.76794,-27.40477 -58.43637,-34.73226 -88.35297,-17.18694 -3.16715,1.85745 -9.13825,6.75218 -13.26912,10.87718 -15.25585,15.2342 -22.58907,36.73121 -19.89473,58.32056 2.09163,16.75991 8.00647,28.72546 20.4054,41.27955 6.56501,6.64716 9.70669,8.94417 17.51467,12.8057 15.22329,7.52886 31.00831,9.22535 47.12236,5.06449 z m 110.10757,-67.7203 0.2554,-88.25 h 53.99998 54 l 7.8663,2.78197 c 18.3397,6.48598 28.9164,19.00064 31.877,37.71803 3.5016,22.13717 -10.9925,45.27 -33.5707,53.57957 -3.3949,1.24945 -6.0631,2.74616 -5.9293,3.32601 0.1338,0.57986 11.1009,18.05082 24.3713,38.82436 13.2704,20.77353 24.3465,38.33256 24.6137,39.02006 0.3696,0.95137 -2.0173,1.25 -9.9912,1.25 h -10.4768 l -25.2351,-39.5 -25.2351,-39.5 h -33.895 -33.8951 v 39.5 39.5 h -9.50538 -9.5055 z m 109.32728,-11.42139 c 6.7739,-2.29738 16.4593,-11.98282 18.7567,-18.75675 4.3048,-12.69281 0.8926,-26.4589 -8.2111,-33.12678 -9.3365,-6.83832 -8.9232,-6.78639 -57.3675,-7.21035 l -43.75,-0.38288 v 30.57408 30.57407 h 42.8219 c 37.383,0 43.4477,-0.21228 47.75,-1.67139 z m 186.4281,11.11706 v -88.55433 l 55.25,0.33131 c 53.883,0.32312 55.4126,0.38595 61.8221,2.53957 32.8507,11.03794 42.7686,46.25641 20.6676,73.39049 l -4.5506,5.58691 5.9625,4.20488 c 24.2118,17.07465 26.0959,53.09112 3.9277,75.0822 -3.6186,3.58969 -9.2793,7.9393 -12.5793,9.66581 -11.9617,6.25819 -12.5432,6.30749 -74.3943,6.30749 h -56.1057 z m 120.0125,67.34404 c 7.4446,-3.66016 13.6594,-9.99596 17.2401,-17.57573 2.4441,-5.1736 2.9696,-7.57262 2.9696,-13.55633 0,-13.00668 -5.7326,-21.72251 -18.1022,-27.52248 l -5.62,-2.63517 -49.25,-0.29407 -49.25,-0.29407 v 32.58893 32.58892 l 48.25,-0.29485 48.25,-0.29486 z m -7.8925,-82.92488 c 12.424,-5.8255 18.8958,-15.19817 18.858,-27.31117 -0.038,-12.06431 -5.6201,-19.88527 -17.5972,-24.65309 -5.8052,-2.31094 -6.4562,-2.34557 -50.6308,-2.69356 l -44.75,-0.35252 v 29.13812 29.13813 l 44.25,-0.31537 44.25,-0.31537 z m 88.88,15.62823 v -88.50694 l 68.25,0.25694 68.25,0.25694 0.2889,8.75 0.289,8.75 h -59.539 -59.5389 v 26.5 26.5 h 34 34 v 9 9 h -34 -34 v 35 35 h 59.5 59.5 v 9 9 h -68.5 -68.5 z m 176,0.007 v -88.5 h 9 9 v 79.5 79.5 h 56.5 56.5 v 9 9 h -65.5 -65.5 z m 206.6597,87.52067 c -40.6013,-7.38749 -69.2764,-39.34307 -73.1521,-81.52067 -0.8242,-8.96916 0.8654,-22.39373 4.1295,-32.81167 8.4218,-26.87906 28.9199,-47.9344 55.2005,-56.70092 18.7746,-6.26273 35.653,-6.23866 54.513,0.0777 25.5622,8.56102 45.823,29.12558 54.512,55.32939 16.0956,48.54016 -10.9221,99.6801 -60.0362,113.63827 -8.2788,2.35281 -27.2631,3.42594 -35.1667,1.98787 z m 25.8403,-18.51184 c 25.0727,-4.45459 46.934,-25.33602 53.5315,-51.13213 2.6544,-10.37845 2.6529,-25.38084 0,-35.76728 -8.5763,-33.53307 -40.5094,-55.75313 -74.0758,-51.54426 -15.8282,1.98469 -28.1141,8.12743 -39.9714,19.98495 -13.4625,13.46277 -19.9808,29.74149 -19.9808,49.89969 0,13.03651 1.5762,19.62446 7.6627,32.02841 6.5477,13.34361 16.9396,23.75154 30.3737,30.42059 14.3197,7.10869 26.7642,8.8993 42.4636,6.11003 z m 280.5,-69.00889 v -88.5 h 68 68 v 9 9 h -59 -59 v 26.5 26.5 h 33.5 33.5 v 9 9 h -33.5 -33.5 v 35 35 h 59 59 v 9 9 h -68 -68 z m 171,-0.0754 v -88.57544 l 42.75,0.39029 c 39.6891,0.36235 43.2937,0.54095 50.3434,2.49448 40.9455,11.3463 68.0273,48.83229 65.5741,90.76611 -1.2744,21.78433 -9.6336,41.15337 -24.5071,56.78542 -12.7536,13.40405 -30.6584,22.75483 -49.1604,25.67395 -3.6241,0.57178 -23.8662,1.02886 -45.75,1.03308 l -39.25,0.008 v -88.57544 z m 92.5,67.22277 c 18.6951,-6.53035 32.2899,-18.31088 40.5601,-35.14733 5.6081,-11.41693 7.3357,-18.95299 7.3357,-32 0,-20.32672 -6.1511,-35.28046 -20.4149,-49.62977 -7.2538,-7.29732 -10.0376,-9.33032 -18.0296,-13.16695 -5.1982,-2.49544 -11.7013,-5.07161 -14.4513,-5.72483 -3.0427,-0.72273 -17.6246,-1.38252 -37.25,-1.68545 l -32.25,-0.49781 v 70.68426 70.68426 l 33.25,-0.36096 33.25,-0.36096 z m -419.7527,-67.14884 c -24.061,-48.12583 -43.7473,-87.72583 -43.7473,-88 0,-0.27417 4.3901,-0.49849 9.7559,-0.49849 h 9.7559 l 33.9882,68 c 18.6935,37.4 34.2159,67.99979 34.4941,67.99953 0.2783,-2.5e-4 15.8059,-30.48775 34.5059,-67.75 l 34,-67.74953 9.75,-0.28621 c 5.3625,-0.15742 9.75,-0.0456 9.75,0.24849 0,1.00865 -87.4943,175.53768 -88,175.53768 -0.2779,0 -20.1916,-39.37568 -44.2527,-87.50151 z M 283.80122,626.15401 C 190.30382,618.48508 106.14663,568.84201 53.408914,490.24901 25.294784,448.3516 8.0728705,401.5317 1.7237915,349.73663 -0.55815853,331.12074 -0.57757653,295.75602 1.6839925,277.2541 c 7.288285,-59.62553 30.2179095,-115.08049 66.5705915,-161 9.80603,-12.38666 36.979346,-39.750343 49.046636,-49.390233 46.10469,-36.830497 103.73334,-60.13958 162.5,-65.726433 17.40461,-1.654628 54.43455,-0.59276 71.73659,2.057114 39.24618,6.010704 76.54032,19.42445 111.01341,39.928685 l 7.75,4.609614 v 27.26063 c 0,14.99334 -0.17813,27.260623 -0.39585,27.260623 -0.21772,0 -4.68567,-2.696203 -9.92878,-5.991563 -35.64742,-22.40485 -82.67362,-40.01442 -123.17537,-46.12463 -25.8293,-3.89668 -57.27056,-2.52074 -85.5,3.74168 -36.0596,7.99946 -75.75914,27.31223 -105.60496,51.374013 -11.55788,9.31799 -32.75994,31.03263 -41.5078,42.51129 -30.042046,39.42018 -47.807126,81.91376 -54.552966,130.48921 -2.61517,18.83129 -2.35724,54.86022 0.52778,73.723 4.52303,29.57235 12.0274,53.87008 24.63917,79.777 12.92168,26.54355 27.205226,46.88287 47.998776,68.34876 22.24315,22.96236 42.62812,37.93879 71.15449,52.27578 34.04231,17.10923 66.4153,25.21665 105.84551,26.50772 27.31239,0.89429 50.64318,-2.01173 77.98585,-9.71372 l 11.51415,-3.24335 V 439.5917 313.2541 h 24 24 v 142.36989 142.3699 l -15.25,6.04867 c -8.3875,3.32677 -19.75,7.4705 -25.25,9.20828 -35.63555,11.25945 -76.354,15.90898 -113,12.90317 z m 528.5,0.44109 c -61.55586,-4.23488 -116.66567,-24.45112 -164.49055,-60.341 -39.90613,-29.94731 -70.64413,-67.11625 -93.03534,-112.5 -10.67508,-21.63685 -16.81941,-37.99888 -22.46554,-59.82454 -8.08761,-31.26344 -10.45363,-52.67338 -9.73253,-88.06926 0.73798,-36.22483 4.68225,-59.47753 15.70844,-92.6062 15.43445,-46.37346 38.83257,-85.10347 72.28542,-119.651263 49.14854,-50.757207 109.5119,-81.252209 181.2301,-91.555738 5.77541,-0.829735 19.39035,-1.279402 38,-1.255044 24.95696,0.03267 30.9829,0.34896 43.223,2.268716 80.435,12.615562 151.00658,54.915966 199.85098,119.790129 30.5686,40.60072 51.3856,89.5552 59.394,139.67472 5.9473,37.22054 5.2119,77.55367 -2.0731,113.70179 -21.8186,108.263 -99.0925,198.03572 -200.972,233.47864 -38.34384,13.33946 -80.34099,19.40578 -116.92288,16.88905 z m 53,-49.81839 c 117.1819,-17.60456 207.46848,-112.23595 221.49618,-232.15514 1.9166,-16.38404 1.9303,-46.23364 0.029,-62.48947 C 1076.2408,191.64051 1021.1676,113.06315 940.80122,73.786687 920.34224,63.788027 902.34077,57.488047 882.2526,53.296427 765.09086,28.849305 648.38949,87.538157 595.94211,197.28131 c -33.59144,70.28818 -35.06183,152.62085 -3.99767,223.84567 24.27657,55.66204 66.58383,101.3414 119.54258,129.07074 28.77564,15.06699 60.76034,24.66613 93.3142,28.00512 12.62529,1.29496 47.9265,0.46282 60.5,-1.42613 z m 346.66668,49.81072 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 289.500003 289.5 h 90.5 90.5 v 24 24 h -113.8333 c -62.6084,0 -114.1334,-0.3 -114.5,-0.66667 z m 419.9228,-0.43324 c -45.3584,-4.7814 -86.6078,-28.49326 -114.4401,-65.78502 -13.9989,-18.75669 -25.1058,-44.96228 -29.1953,-68.88367 -1.9016,-11.12305 -1.9541,-17.87554 -1.9541,-251.33077 V 0.254097 h 23.4801 23.4801 l 0.3026,239.750003 c 0.2807,222.45253 0.4263,240.25411 2.0173,246.73716 5.9717,24.33382 15.8836,42.62139 31.7199,58.52356 32.0114,32.14457 79.6172,42.51235 122.1164,26.59498 40.2071,-15.05895 69.0021,-52.14101 73.8514,-95.1057 0.6589,-5.83817 1.0187,-91.1198 1.024,-242.75 l 0.01,-233.750003 h 24.0331 24.033 l -0.3446,240.250003 -0.3447,240.25 -2.1564,11.16964 c -6.3773,33.03181 -21.6776,62.79398 -44.0473,85.68092 -35.0332,35.84331 -84.2913,53.74562 -133.5836,48.54953 z m 617.0772,0.43324 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 313.500003 313.5 h -23.3333 c -12.8334,0 -23.6334,-0.3 -24,-0.66667 z M 2405.3012,313.7541 V 0.254097 h 24 24 v 313.500003 313.5 h -24 -24 z m 324.3796,276.75 c 2.4308,-128.43371 14.0844,-225.18511 37.0098,-307.26529 24.3126,-87.0469 57.8679,-152.16089 116.457,-225.984713 13.8125,-17.403997 47.2531,-57 48.1392,-57 1.2031,0 37.89,43.652953 54.2073,64.5 64.8551,82.859253 102.0762,165.810333 124.2931,277.000003 14.0907,70.51984 21.3293,148.19289 23.1621,248.5385 l 0.6751,36.9615 h -24.0006 -24.0006 l -0.6451,-40.25 c -0.8728,-54.45747 -3.2294,-97.37808 -7.7552,-141.25 -2.0157,-19.53876 -5.5649,-48.26034 -6.4568,-52.25 l -0.503,-2.25 h -138.9015 -138.9015 l -0.5737,2.75 c -1.3048,6.25497 -5.6037,42.23877 -7.4966,62.75 -4.1897,45.40108 -5.8724,78.08226 -6.758,131.25 l -0.6537,39.25 h -23.9965 -23.9964 z m 329.9901,-257.5 c -16.2344,-75.39296 -44.3576,-142.31154 -84.8247,-201.83821 -14.6478,-21.54687 -41.7256,-56.911793 -43.5754,-56.911793 -0.9462,0 -17.0989,20.3312 -30.1903,38.000003 -41.3759,55.84305 -70.8145,117.14692 -89.7989,187 -4.4541,16.38903 -9.9804,40.25799 -9.9804,43.1072 0,1.84739 3.1285,1.8928 130.3961,1.8928 h 130.3961 z M 1909.3012,313.12705 V 0 l 28.75,0.545379 c 17.9216,0.339968 32.5164,1.11895 38.75,2.068238 49.7522,7.576561 85.9285,24.147722 113.9522,52.19778 12.4706,12.48242 21.7636,25.36226 29.5404,40.9427 21.2693,42.611433 24.3464,94.029103 8.5077,142.162463 -6.3556,19.31469 -11.5913,29.57928 -25.0003,49.0135 -0.7465,1.08188 -0.3662,1.95829 1.5,3.45676 14.1948,11.39799 25.2886,24.1977 34.6589,39.98836 24.0771,40.57424 32.4157,95.7704 21.7183,143.7621 -16.6222,74.57234 -71.742,126.3476 -153.8772,144.54032 -23.5242,5.21055 -47.5765,7.55118 -77.75,7.56618 l -20.75,0.0103 z m 67.0296,262.68603 c 76.2213,-10.14858 125.4273,-50.12555 139.1595,-113.05898 2.8851,-13.22248 3.5837,-41.39321 1.3952,-56.26475 -7.6001,-51.6453 -39.0273,-90.16381 -87.8883,-107.71956 l -8.8039,-3.16327 4.3039,-1.92621 c 8.6623,-3.87675 22.4588,-13.8852 30.7894,-22.33564 20.7256,-21.02389 32.3393,-47.80952 35.1972,-81.17828 2.6177,-30.56363 -3.3016,-57.78392 -17.8905,-82.27023 -6.1953,-10.398453 -22.0413,-26.645363 -32.7921,-33.621833 -20.4272,-13.25571 -46.3837,-21.8786 -74.75,-24.83229 l -7.75,-0.80699 V 312.94458 577.2541 l 4.25,-0.0195 c 2.3375,-0.0107 8.9883,-0.65041 14.7796,-1.4215 z m 709.8989,48.91102 c -54.2863,-8.46314 -107.5748,-44.21736 -148.5323,-99.65857 -36.799,-49.81226 -57.332,-112.54974 -57.3859,-175.33969 l -0.01,-12.02826 10.0146,-5.3032 c 5.508,-2.91675 13.9455,-7.89048 18.75,-11.05272 53.4162,-35.15792 97.2057,-103.2045 120.2758,-186.90192 10.4228,-37.814683 17.9593,-90.590529 17.9593,-125.765195 V 0.254097 h 24 24 l -0.014,6.25 c -0.024,10.561015 -1.8792,39.47964 -3.5126,54.75 -8.8899,83.111443 -36.952,162.700163 -78.2523,221.937063 -21.4625,30.78363 -50.9331,60.30689 -77.4119,77.55035 l -7.6586,4.98741 0.4809,5.01259 c 3.2211,33.5697 12.0172,63.4558 27.5226,93.51259 32.7718,63.52705 89.9499,109.46939 141.5954,113.77113 l 8.7506,0.72887 0.2681,23.75 0.2681,23.75 -6.2681,-0.0969 c -3.4475,-0.0533 -10.1253,-0.69818 -14.8396,-1.43314 z\"/>
				</svg>\";}i:5;a:2:{s:5:\"title\";s:18:\"Лого О НАС\";s:7:\"content\";s:12058:\"<svg class=\"logo_about\"
				        xmlns=\"http://www.w3.org/2000/svg\"
				 				viewbox=\"0 0 3133.6245 931.25458\"
				 				id=\"svg4485\"
				 				version=\"1.1\">
				 				<path
				   				id=\"path4495\"
				   				d=\"m 629.30122,842.7541 v -88.5 h 66 66 v 9 9 h -57 -57 v 26.5 26.5 h 35 35 v 9 9 h -35 -35 v 44 44 h -9 -9 z m 211.65975,87.52067 c -34.47599,-6.27297 -61.7046,-31.47756 -70.78222,-65.52067 -3.05474,-11.45594 -3.0869,-30.63469 -0.0718,-42.80135 8.12584,-32.78951 32.23466,-56.92548 65.19425,-65.26768 10.60111,-2.68319 28.61274,-2.47821 39.5,0.44952 16.38958,4.40738 29.65943,12.31595 41.5329,24.75279 11.794,12.35361 17.93771,23.7875 22.12701,41.17996 2.54057,10.54752 2.78654,27.3125 0.55317,37.70328 -7.08298,32.95362 -30.77549,58.39031 -62.88671,67.51628 -8.27874,2.35281 -27.26305,3.42594 -35.16662,1.98787 z m 30.47728,-19.55037 c 23.03887,-5.94895 42.76883,-26.14244 48.87705,-50.02536 2.41886,-9.45766 2.63029,-25.08622 0.4637,-34.27658 -2.02121,-8.57371 -7.19606,-19.37624 -12.86636,-26.8586 -20.76794,-27.40477 -58.43637,-34.73226 -88.35297,-17.18694 -3.16715,1.85745 -9.13825,6.75218 -13.26912,10.87718 -15.25585,15.2342 -22.58907,36.73121 -19.89473,58.32056 2.09163,16.75991 8.00647,28.72546 20.4054,41.27955 6.56501,6.64716 9.70669,8.94417 17.51467,12.8057 15.22329,7.52886 31.00831,9.22535 47.12236,5.06449 z m 110.10757,-67.7203 0.2554,-88.25 h 53.99998 54 l 7.8663,2.78197 c 18.3397,6.48598 28.9164,19.00064 31.877,37.71803 3.5016,22.13717 -10.9925,45.27 -33.5707,53.57957 -3.3949,1.24945 -6.0631,2.74616 -5.9293,3.32601 0.1338,0.57986 11.1009,18.05082 24.3713,38.82436 13.2704,20.77353 24.3465,38.33256 24.6137,39.02006 0.3696,0.95137 -2.0173,1.25 -9.9912,1.25 h -10.4768 l -25.2351,-39.5 -25.2351,-39.5 h -33.895 -33.8951 v 39.5 39.5 h -9.50538 -9.5055 z m 109.32728,-11.42139 c 6.7739,-2.29738 16.4593,-11.98282 18.7567,-18.75675 4.3048,-12.69281 0.8926,-26.4589 -8.2111,-33.12678 -9.3365,-6.83832 -8.9232,-6.78639 -57.3675,-7.21035 l -43.75,-0.38288 v 30.57408 30.57407 h 42.8219 c 37.383,0 43.4477,-0.21228 47.75,-1.67139 z m 186.4281,11.11706 v -88.55433 l 55.25,0.33131 c 53.883,0.32312 55.4126,0.38595 61.8221,2.53957 32.8507,11.03794 42.7686,46.25641 20.6676,73.39049 l -4.5506,5.58691 5.9625,4.20488 c 24.2118,17.07465 26.0959,53.09112 3.9277,75.0822 -3.6186,3.58969 -9.2793,7.9393 -12.5793,9.66581 -11.9617,6.25819 -12.5432,6.30749 -74.3943,6.30749 h -56.1057 z m 120.0125,67.34404 c 7.4446,-3.66016 13.6594,-9.99596 17.2401,-17.57573 2.4441,-5.1736 2.9696,-7.57262 2.9696,-13.55633 0,-13.00668 -5.7326,-21.72251 -18.1022,-27.52248 l -5.62,-2.63517 -49.25,-0.29407 -49.25,-0.29407 v 32.58893 32.58892 l 48.25,-0.29485 48.25,-0.29486 z m -7.8925,-82.92488 c 12.424,-5.8255 18.8958,-15.19817 18.858,-27.31117 -0.038,-12.06431 -5.6201,-19.88527 -17.5972,-24.65309 -5.8052,-2.31094 -6.4562,-2.34557 -50.6308,-2.69356 l -44.75,-0.35252 v 29.13812 29.13813 l 44.25,-0.31537 44.25,-0.31537 z m 88.88,15.62823 v -88.50694 l 68.25,0.25694 68.25,0.25694 0.2889,8.75 0.289,8.75 h -59.539 -59.5389 v 26.5 26.5 h 34 34 v 9 9 h -34 -34 v 35 35 h 59.5 59.5 v 9 9 h -68.5 -68.5 z m 176,0.007 v -88.5 h 9 9 v 79.5 79.5 h 56.5 56.5 v 9 9 h -65.5 -65.5 z m 206.6597,87.52067 c -40.6013,-7.38749 -69.2764,-39.34307 -73.1521,-81.52067 -0.8242,-8.96916 0.8654,-22.39373 4.1295,-32.81167 8.4218,-26.87906 28.9199,-47.9344 55.2005,-56.70092 18.7746,-6.26273 35.653,-6.23866 54.513,0.0777 25.5622,8.56102 45.823,29.12558 54.512,55.32939 16.0956,48.54016 -10.9221,99.6801 -60.0362,113.63827 -8.2788,2.35281 -27.2631,3.42594 -35.1667,1.98787 z m 25.8403,-18.51184 c 25.0727,-4.45459 46.934,-25.33602 53.5315,-51.13213 2.6544,-10.37845 2.6529,-25.38084 0,-35.76728 -8.5763,-33.53307 -40.5094,-55.75313 -74.0758,-51.54426 -15.8282,1.98469 -28.1141,8.12743 -39.9714,19.98495 -13.4625,13.46277 -19.9808,29.74149 -19.9808,49.89969 0,13.03651 1.5762,19.62446 7.6627,32.02841 6.5477,13.34361 16.9396,23.75154 30.3737,30.42059 14.3197,7.10869 26.7642,8.8993 42.4636,6.11003 z m 280.5,-69.00889 v -88.5 h 68 68 v 9 9 h -59 -59 v 26.5 26.5 h 33.5 33.5 v 9 9 h -33.5 -33.5 v 35 35 h 59 59 v 9 9 h -68 -68 z m 171,-0.0754 v -88.57544 l 42.75,0.39029 c 39.6891,0.36235 43.2937,0.54095 50.3434,2.49448 40.9455,11.3463 68.0273,48.83229 65.5741,90.76611 -1.2744,21.78433 -9.6336,41.15337 -24.5071,56.78542 -12.7536,13.40405 -30.6584,22.75483 -49.1604,25.67395 -3.6241,0.57178 -23.8662,1.02886 -45.75,1.03308 l -39.25,0.008 v -88.57544 z m 92.5,67.22277 c 18.6951,-6.53035 32.2899,-18.31088 40.5601,-35.14733 5.6081,-11.41693 7.3357,-18.95299 7.3357,-32 0,-20.32672 -6.1511,-35.28046 -20.4149,-49.62977 -7.2538,-7.29732 -10.0376,-9.33032 -18.0296,-13.16695 -5.1982,-2.49544 -11.7013,-5.07161 -14.4513,-5.72483 -3.0427,-0.72273 -17.6246,-1.38252 -37.25,-1.68545 l -32.25,-0.49781 v 70.68426 70.68426 l 33.25,-0.36096 33.25,-0.36096 z m -419.7527,-67.14884 c -24.061,-48.12583 -43.7473,-87.72583 -43.7473,-88 0,-0.27417 4.3901,-0.49849 9.7559,-0.49849 h 9.7559 l 33.9882,68 c 18.6935,37.4 34.2159,67.99979 34.4941,67.99953 0.2783,-2.5e-4 15.8059,-30.48775 34.5059,-67.75 l 34,-67.74953 9.75,-0.28621 c 5.3625,-0.15742 9.75,-0.0456 9.75,0.24849 0,1.00865 -87.4943,175.53768 -88,175.53768 -0.2779,0 -20.1916,-39.37568 -44.2527,-87.50151 z M 283.80122,626.15401 C 190.30382,618.48508 106.14663,568.84201 53.408914,490.24901 25.294784,448.3516 8.0728705,401.5317 1.7237915,349.73663 -0.55815853,331.12074 -0.57757653,295.75602 1.6839925,277.2541 c 7.288285,-59.62553 30.2179095,-115.08049 66.5705915,-161 9.80603,-12.38666 36.979346,-39.750343 49.046636,-49.390233 46.10469,-36.830497 103.73334,-60.13958 162.5,-65.726433 17.40461,-1.654628 54.43455,-0.59276 71.73659,2.057114 39.24618,6.010704 76.54032,19.42445 111.01341,39.928685 l 7.75,4.609614 v 27.26063 c 0,14.99334 -0.17813,27.260623 -0.39585,27.260623 -0.21772,0 -4.68567,-2.696203 -9.92878,-5.991563 -35.64742,-22.40485 -82.67362,-40.01442 -123.17537,-46.12463 -25.8293,-3.89668 -57.27056,-2.52074 -85.5,3.74168 -36.0596,7.99946 -75.75914,27.31223 -105.60496,51.374013 -11.55788,9.31799 -32.75994,31.03263 -41.5078,42.51129 -30.042046,39.42018 -47.807126,81.91376 -54.552966,130.48921 -2.61517,18.83129 -2.35724,54.86022 0.52778,73.723 4.52303,29.57235 12.0274,53.87008 24.63917,79.777 12.92168,26.54355 27.205226,46.88287 47.998776,68.34876 22.24315,22.96236 42.62812,37.93879 71.15449,52.27578 34.04231,17.10923 66.4153,25.21665 105.84551,26.50772 27.31239,0.89429 50.64318,-2.01173 77.98585,-9.71372 l 11.51415,-3.24335 V 439.5917 313.2541 h 24 24 v 142.36989 142.3699 l -15.25,6.04867 c -8.3875,3.32677 -19.75,7.4705 -25.25,9.20828 -35.63555,11.25945 -76.354,15.90898 -113,12.90317 z m 528.5,0.44109 c -61.55586,-4.23488 -116.66567,-24.45112 -164.49055,-60.341 -39.90613,-29.94731 -70.64413,-67.11625 -93.03534,-112.5 -10.67508,-21.63685 -16.81941,-37.99888 -22.46554,-59.82454 -8.08761,-31.26344 -10.45363,-52.67338 -9.73253,-88.06926 0.73798,-36.22483 4.68225,-59.47753 15.70844,-92.6062 15.43445,-46.37346 38.83257,-85.10347 72.28542,-119.651263 49.14854,-50.757207 109.5119,-81.252209 181.2301,-91.555738 5.77541,-0.829735 19.39035,-1.279402 38,-1.255044 24.95696,0.03267 30.9829,0.34896 43.223,2.268716 80.435,12.615562 151.00658,54.915966 199.85098,119.790129 30.5686,40.60072 51.3856,89.5552 59.394,139.67472 5.9473,37.22054 5.2119,77.55367 -2.0731,113.70179 -21.8186,108.263 -99.0925,198.03572 -200.972,233.47864 -38.34384,13.33946 -80.34099,19.40578 -116.92288,16.88905 z m 53,-49.81839 c 117.1819,-17.60456 207.46848,-112.23595 221.49618,-232.15514 1.9166,-16.38404 1.9303,-46.23364 0.029,-62.48947 C 1076.2408,191.64051 1021.1676,113.06315 940.80122,73.786687 920.34224,63.788027 902.34077,57.488047 882.2526,53.296427 765.09086,28.849305 648.38949,87.538157 595.94211,197.28131 c -33.59144,70.28818 -35.06183,152.62085 -3.99767,223.84567 24.27657,55.66204 66.58383,101.3414 119.54258,129.07074 28.77564,15.06699 60.76034,24.66613 93.3142,28.00512 12.62529,1.29496 47.9265,0.46282 60.5,-1.42613 z m 346.66668,49.81072 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 289.500003 289.5 h 90.5 90.5 v 24 24 h -113.8333 c -62.6084,0 -114.1334,-0.3 -114.5,-0.66667 z m 419.9228,-0.43324 c -45.3584,-4.7814 -86.6078,-28.49326 -114.4401,-65.78502 -13.9989,-18.75669 -25.1058,-44.96228 -29.1953,-68.88367 -1.9016,-11.12305 -1.9541,-17.87554 -1.9541,-251.33077 V 0.254097 h 23.4801 23.4801 l 0.3026,239.750003 c 0.2807,222.45253 0.4263,240.25411 2.0173,246.73716 5.9717,24.33382 15.8836,42.62139 31.7199,58.52356 32.0114,32.14457 79.6172,42.51235 122.1164,26.59498 40.2071,-15.05895 69.0021,-52.14101 73.8514,-95.1057 0.6589,-5.83817 1.0187,-91.1198 1.024,-242.75 l 0.01,-233.750003 h 24.0331 24.033 l -0.3446,240.250003 -0.3447,240.25 -2.1564,11.16964 c -6.3773,33.03181 -21.6776,62.79398 -44.0473,85.68092 -35.0332,35.84331 -84.2913,53.74562 -133.5836,48.54953 z m 617.0772,0.43324 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 313.500003 313.5 h -23.3333 c -12.8334,0 -23.6334,-0.3 -24,-0.66667 z M 2405.3012,313.7541 V 0.254097 h 24 24 v 313.500003 313.5 h -24 -24 z m 324.3796,276.75 c 2.4308,-128.43371 14.0844,-225.18511 37.0098,-307.26529 24.3126,-87.0469 57.8679,-152.16089 116.457,-225.984713 13.8125,-17.403997 47.2531,-57 48.1392,-57 1.2031,0 37.89,43.652953 54.2073,64.5 64.8551,82.859253 102.0762,165.810333 124.2931,277.000003 14.0907,70.51984 21.3293,148.19289 23.1621,248.5385 l 0.6751,36.9615 h -24.0006 -24.0006 l -0.6451,-40.25 c -0.8728,-54.45747 -3.2294,-97.37808 -7.7552,-141.25 -2.0157,-19.53876 -5.5649,-48.26034 -6.4568,-52.25 l -0.503,-2.25 h -138.9015 -138.9015 l -0.5737,2.75 c -1.3048,6.25497 -5.6037,42.23877 -7.4966,62.75 -4.1897,45.40108 -5.8724,78.08226 -6.758,131.25 l -0.6537,39.25 h -23.9965 -23.9964 z m 329.9901,-257.5 c -16.2344,-75.39296 -44.3576,-142.31154 -84.8247,-201.83821 -14.6478,-21.54687 -41.7256,-56.911793 -43.5754,-56.911793 -0.9462,0 -17.0989,20.3312 -30.1903,38.000003 -41.3759,55.84305 -70.8145,117.14692 -89.7989,187 -4.4541,16.38903 -9.9804,40.25799 -9.9804,43.1072 0,1.84739 3.1285,1.8928 130.3961,1.8928 h 130.3961 z M 1909.3012,313.12705 V 0 l 28.75,0.545379 c 17.9216,0.339968 32.5164,1.11895 38.75,2.068238 49.7522,7.576561 85.9285,24.147722 113.9522,52.19778 12.4706,12.48242 21.7636,25.36226 29.5404,40.9427 21.2693,42.611433 24.3464,94.029103 8.5077,142.162463 -6.3556,19.31469 -11.5913,29.57928 -25.0003,49.0135 -0.7465,1.08188 -0.3662,1.95829 1.5,3.45676 14.1948,11.39799 25.2886,24.1977 34.6589,39.98836 24.0771,40.57424 32.4157,95.7704 21.7183,143.7621 -16.6222,74.57234 -71.742,126.3476 -153.8772,144.54032 -23.5242,5.21055 -47.5765,7.55118 -77.75,7.56618 l -20.75,0.0103 z m 67.0296,262.68603 c 76.2213,-10.14858 125.4273,-50.12555 139.1595,-113.05898 2.8851,-13.22248 3.5837,-41.39321 1.3952,-56.26475 -7.6001,-51.6453 -39.0273,-90.16381 -87.8883,-107.71956 l -8.8039,-3.16327 4.3039,-1.92621 c 8.6623,-3.87675 22.4588,-13.8852 30.7894,-22.33564 20.7256,-21.02389 32.3393,-47.80952 35.1972,-81.17828 2.6177,-30.56363 -3.3016,-57.78392 -17.8905,-82.27023 -6.1953,-10.398453 -22.0413,-26.645363 -32.7921,-33.621833 -20.4272,-13.25571 -46.3837,-21.8786 -74.75,-24.83229 l -7.75,-0.80699 V 312.94458 577.2541 l 4.25,-0.0195 c 2.3375,-0.0107 8.9883,-0.65041 14.7796,-1.4215 z m 709.8989,48.91102 c -54.2863,-8.46314 -107.5748,-44.21736 -148.5323,-99.65857 -36.799,-49.81226 -57.332,-112.54974 -57.3859,-175.33969 l -0.01,-12.02826 10.0146,-5.3032 c 5.508,-2.91675 13.9455,-7.89048 18.75,-11.05272 53.4162,-35.15792 97.2057,-103.2045 120.2758,-186.90192 10.4228,-37.814683 17.9593,-90.590529 17.9593,-125.765195 V 0.254097 h 24 24 l -0.014,6.25 c -0.024,10.561015 -1.8792,39.47964 -3.5126,54.75 -8.8899,83.111443 -36.952,162.700163 -78.2523,221.937063 -21.4625,30.78363 -50.9331,60.30689 -77.4119,77.55035 l -7.6586,4.98741 0.4809,5.01259 c 3.2211,33.5697 12.0172,63.4558 27.5226,93.51259 32.7718,63.52705 89.9499,109.46939 141.5954,113.77113 l 8.7506,0.72887 0.2681,23.75 0.2681,23.75 -6.2681,-0.0969 c -3.4475,-0.0533 -10.1253,-0.69818 -14.8396,-1.43314 z\"/>
							</svg> \";}i:6;a:2:{s:5:\"title\";s:19:\"Лого футер\";s:7:\"content\";s:12050:\"<svg class=\"footer_logo\"
			        xmlns=\"http://www.w3.org/2000/svg\"
			 				viewbox=\"0 0 3133.6245 931.25458\"
			 				id=\"svg4485\"
			 				version=\"1.1\">
			 				<path
			   				id=\"path4495\"
			   				d=\"m 629.30122,842.7541 v -88.5 h 66 66 v 9 9 h -57 -57 v 26.5 26.5 h 35 35 v 9 9 h -35 -35 v 44 44 h -9 -9 z m 211.65975,87.52067 c -34.47599,-6.27297 -61.7046,-31.47756 -70.78222,-65.52067 -3.05474,-11.45594 -3.0869,-30.63469 -0.0718,-42.80135 8.12584,-32.78951 32.23466,-56.92548 65.19425,-65.26768 10.60111,-2.68319 28.61274,-2.47821 39.5,0.44952 16.38958,4.40738 29.65943,12.31595 41.5329,24.75279 11.794,12.35361 17.93771,23.7875 22.12701,41.17996 2.54057,10.54752 2.78654,27.3125 0.55317,37.70328 -7.08298,32.95362 -30.77549,58.39031 -62.88671,67.51628 -8.27874,2.35281 -27.26305,3.42594 -35.16662,1.98787 z m 30.47728,-19.55037 c 23.03887,-5.94895 42.76883,-26.14244 48.87705,-50.02536 2.41886,-9.45766 2.63029,-25.08622 0.4637,-34.27658 -2.02121,-8.57371 -7.19606,-19.37624 -12.86636,-26.8586 -20.76794,-27.40477 -58.43637,-34.73226 -88.35297,-17.18694 -3.16715,1.85745 -9.13825,6.75218 -13.26912,10.87718 -15.25585,15.2342 -22.58907,36.73121 -19.89473,58.32056 2.09163,16.75991 8.00647,28.72546 20.4054,41.27955 6.56501,6.64716 9.70669,8.94417 17.51467,12.8057 15.22329,7.52886 31.00831,9.22535 47.12236,5.06449 z m 110.10757,-67.7203 0.2554,-88.25 h 53.99998 54 l 7.8663,2.78197 c 18.3397,6.48598 28.9164,19.00064 31.877,37.71803 3.5016,22.13717 -10.9925,45.27 -33.5707,53.57957 -3.3949,1.24945 -6.0631,2.74616 -5.9293,3.32601 0.1338,0.57986 11.1009,18.05082 24.3713,38.82436 13.2704,20.77353 24.3465,38.33256 24.6137,39.02006 0.3696,0.95137 -2.0173,1.25 -9.9912,1.25 h -10.4768 l -25.2351,-39.5 -25.2351,-39.5 h -33.895 -33.8951 v 39.5 39.5 h -9.50538 -9.5055 z m 109.32728,-11.42139 c 6.7739,-2.29738 16.4593,-11.98282 18.7567,-18.75675 4.3048,-12.69281 0.8926,-26.4589 -8.2111,-33.12678 -9.3365,-6.83832 -8.9232,-6.78639 -57.3675,-7.21035 l -43.75,-0.38288 v 30.57408 30.57407 h 42.8219 c 37.383,0 43.4477,-0.21228 47.75,-1.67139 z m 186.4281,11.11706 v -88.55433 l 55.25,0.33131 c 53.883,0.32312 55.4126,0.38595 61.8221,2.53957 32.8507,11.03794 42.7686,46.25641 20.6676,73.39049 l -4.5506,5.58691 5.9625,4.20488 c 24.2118,17.07465 26.0959,53.09112 3.9277,75.0822 -3.6186,3.58969 -9.2793,7.9393 -12.5793,9.66581 -11.9617,6.25819 -12.5432,6.30749 -74.3943,6.30749 h -56.1057 z m 120.0125,67.34404 c 7.4446,-3.66016 13.6594,-9.99596 17.2401,-17.57573 2.4441,-5.1736 2.9696,-7.57262 2.9696,-13.55633 0,-13.00668 -5.7326,-21.72251 -18.1022,-27.52248 l -5.62,-2.63517 -49.25,-0.29407 -49.25,-0.29407 v 32.58893 32.58892 l 48.25,-0.29485 48.25,-0.29486 z m -7.8925,-82.92488 c 12.424,-5.8255 18.8958,-15.19817 18.858,-27.31117 -0.038,-12.06431 -5.6201,-19.88527 -17.5972,-24.65309 -5.8052,-2.31094 -6.4562,-2.34557 -50.6308,-2.69356 l -44.75,-0.35252 v 29.13812 29.13813 l 44.25,-0.31537 44.25,-0.31537 z m 88.88,15.62823 v -88.50694 l 68.25,0.25694 68.25,0.25694 0.2889,8.75 0.289,8.75 h -59.539 -59.5389 v 26.5 26.5 h 34 34 v 9 9 h -34 -34 v 35 35 h 59.5 59.5 v 9 9 h -68.5 -68.5 z m 176,0.007 v -88.5 h 9 9 v 79.5 79.5 h 56.5 56.5 v 9 9 h -65.5 -65.5 z m 206.6597,87.52067 c -40.6013,-7.38749 -69.2764,-39.34307 -73.1521,-81.52067 -0.8242,-8.96916 0.8654,-22.39373 4.1295,-32.81167 8.4218,-26.87906 28.9199,-47.9344 55.2005,-56.70092 18.7746,-6.26273 35.653,-6.23866 54.513,0.0777 25.5622,8.56102 45.823,29.12558 54.512,55.32939 16.0956,48.54016 -10.9221,99.6801 -60.0362,113.63827 -8.2788,2.35281 -27.2631,3.42594 -35.1667,1.98787 z m 25.8403,-18.51184 c 25.0727,-4.45459 46.934,-25.33602 53.5315,-51.13213 2.6544,-10.37845 2.6529,-25.38084 0,-35.76728 -8.5763,-33.53307 -40.5094,-55.75313 -74.0758,-51.54426 -15.8282,1.98469 -28.1141,8.12743 -39.9714,19.98495 -13.4625,13.46277 -19.9808,29.74149 -19.9808,49.89969 0,13.03651 1.5762,19.62446 7.6627,32.02841 6.5477,13.34361 16.9396,23.75154 30.3737,30.42059 14.3197,7.10869 26.7642,8.8993 42.4636,6.11003 z m 280.5,-69.00889 v -88.5 h 68 68 v 9 9 h -59 -59 v 26.5 26.5 h 33.5 33.5 v 9 9 h -33.5 -33.5 v 35 35 h 59 59 v 9 9 h -68 -68 z m 171,-0.0754 v -88.57544 l 42.75,0.39029 c 39.6891,0.36235 43.2937,0.54095 50.3434,2.49448 40.9455,11.3463 68.0273,48.83229 65.5741,90.76611 -1.2744,21.78433 -9.6336,41.15337 -24.5071,56.78542 -12.7536,13.40405 -30.6584,22.75483 -49.1604,25.67395 -3.6241,0.57178 -23.8662,1.02886 -45.75,1.03308 l -39.25,0.008 v -88.57544 z m 92.5,67.22277 c 18.6951,-6.53035 32.2899,-18.31088 40.5601,-35.14733 5.6081,-11.41693 7.3357,-18.95299 7.3357,-32 0,-20.32672 -6.1511,-35.28046 -20.4149,-49.62977 -7.2538,-7.29732 -10.0376,-9.33032 -18.0296,-13.16695 -5.1982,-2.49544 -11.7013,-5.07161 -14.4513,-5.72483 -3.0427,-0.72273 -17.6246,-1.38252 -37.25,-1.68545 l -32.25,-0.49781 v 70.68426 70.68426 l 33.25,-0.36096 33.25,-0.36096 z m -419.7527,-67.14884 c -24.061,-48.12583 -43.7473,-87.72583 -43.7473,-88 0,-0.27417 4.3901,-0.49849 9.7559,-0.49849 h 9.7559 l 33.9882,68 c 18.6935,37.4 34.2159,67.99979 34.4941,67.99953 0.2783,-2.5e-4 15.8059,-30.48775 34.5059,-67.75 l 34,-67.74953 9.75,-0.28621 c 5.3625,-0.15742 9.75,-0.0456 9.75,0.24849 0,1.00865 -87.4943,175.53768 -88,175.53768 -0.2779,0 -20.1916,-39.37568 -44.2527,-87.50151 z M 283.80122,626.15401 C 190.30382,618.48508 106.14663,568.84201 53.408914,490.24901 25.294784,448.3516 8.0728705,401.5317 1.7237915,349.73663 -0.55815853,331.12074 -0.57757653,295.75602 1.6839925,277.2541 c 7.288285,-59.62553 30.2179095,-115.08049 66.5705915,-161 9.80603,-12.38666 36.979346,-39.750343 49.046636,-49.390233 46.10469,-36.830497 103.73334,-60.13958 162.5,-65.726433 17.40461,-1.654628 54.43455,-0.59276 71.73659,2.057114 39.24618,6.010704 76.54032,19.42445 111.01341,39.928685 l 7.75,4.609614 v 27.26063 c 0,14.99334 -0.17813,27.260623 -0.39585,27.260623 -0.21772,0 -4.68567,-2.696203 -9.92878,-5.991563 -35.64742,-22.40485 -82.67362,-40.01442 -123.17537,-46.12463 -25.8293,-3.89668 -57.27056,-2.52074 -85.5,3.74168 -36.0596,7.99946 -75.75914,27.31223 -105.60496,51.374013 -11.55788,9.31799 -32.75994,31.03263 -41.5078,42.51129 -30.042046,39.42018 -47.807126,81.91376 -54.552966,130.48921 -2.61517,18.83129 -2.35724,54.86022 0.52778,73.723 4.52303,29.57235 12.0274,53.87008 24.63917,79.777 12.92168,26.54355 27.205226,46.88287 47.998776,68.34876 22.24315,22.96236 42.62812,37.93879 71.15449,52.27578 34.04231,17.10923 66.4153,25.21665 105.84551,26.50772 27.31239,0.89429 50.64318,-2.01173 77.98585,-9.71372 l 11.51415,-3.24335 V 439.5917 313.2541 h 24 24 v 142.36989 142.3699 l -15.25,6.04867 c -8.3875,3.32677 -19.75,7.4705 -25.25,9.20828 -35.63555,11.25945 -76.354,15.90898 -113,12.90317 z m 528.5,0.44109 c -61.55586,-4.23488 -116.66567,-24.45112 -164.49055,-60.341 -39.90613,-29.94731 -70.64413,-67.11625 -93.03534,-112.5 -10.67508,-21.63685 -16.81941,-37.99888 -22.46554,-59.82454 -8.08761,-31.26344 -10.45363,-52.67338 -9.73253,-88.06926 0.73798,-36.22483 4.68225,-59.47753 15.70844,-92.6062 15.43445,-46.37346 38.83257,-85.10347 72.28542,-119.651263 49.14854,-50.757207 109.5119,-81.252209 181.2301,-91.555738 5.77541,-0.829735 19.39035,-1.279402 38,-1.255044 24.95696,0.03267 30.9829,0.34896 43.223,2.268716 80.435,12.615562 151.00658,54.915966 199.85098,119.790129 30.5686,40.60072 51.3856,89.5552 59.394,139.67472 5.9473,37.22054 5.2119,77.55367 -2.0731,113.70179 -21.8186,108.263 -99.0925,198.03572 -200.972,233.47864 -38.34384,13.33946 -80.34099,19.40578 -116.92288,16.88905 z m 53,-49.81839 c 117.1819,-17.60456 207.46848,-112.23595 221.49618,-232.15514 1.9166,-16.38404 1.9303,-46.23364 0.029,-62.48947 C 1076.2408,191.64051 1021.1676,113.06315 940.80122,73.786687 920.34224,63.788027 902.34077,57.488047 882.2526,53.296427 765.09086,28.849305 648.38949,87.538157 595.94211,197.28131 c -33.59144,70.28818 -35.06183,152.62085 -3.99767,223.84567 24.27657,55.66204 66.58383,101.3414 119.54258,129.07074 28.77564,15.06699 60.76034,24.66613 93.3142,28.00512 12.62529,1.29496 47.9265,0.46282 60.5,-1.42613 z m 346.66668,49.81072 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 289.500003 289.5 h 90.5 90.5 v 24 24 h -113.8333 c -62.6084,0 -114.1334,-0.3 -114.5,-0.66667 z m 419.9228,-0.43324 c -45.3584,-4.7814 -86.6078,-28.49326 -114.4401,-65.78502 -13.9989,-18.75669 -25.1058,-44.96228 -29.1953,-68.88367 -1.9016,-11.12305 -1.9541,-17.87554 -1.9541,-251.33077 V 0.254097 h 23.4801 23.4801 l 0.3026,239.750003 c 0.2807,222.45253 0.4263,240.25411 2.0173,246.73716 5.9717,24.33382 15.8836,42.62139 31.7199,58.52356 32.0114,32.14457 79.6172,42.51235 122.1164,26.59498 40.2071,-15.05895 69.0021,-52.14101 73.8514,-95.1057 0.6589,-5.83817 1.0187,-91.1198 1.024,-242.75 l 0.01,-233.750003 h 24.0331 24.033 l -0.3446,240.250003 -0.3447,240.25 -2.1564,11.16964 c -6.3773,33.03181 -21.6776,62.79398 -44.0473,85.68092 -35.0332,35.84331 -84.2913,53.74562 -133.5836,48.54953 z m 617.0772,0.43324 c -0.3667,-0.36666 -0.6667,-141.44166 -0.6667,-313.5 V 0.254097 h 24 24 v 313.500003 313.5 h -23.3333 c -12.8334,0 -23.6334,-0.3 -24,-0.66667 z M 2405.3012,313.7541 V 0.254097 h 24 24 v 313.500003 313.5 h -24 -24 z m 324.3796,276.75 c 2.4308,-128.43371 14.0844,-225.18511 37.0098,-307.26529 24.3126,-87.0469 57.8679,-152.16089 116.457,-225.984713 13.8125,-17.403997 47.2531,-57 48.1392,-57 1.2031,0 37.89,43.652953 54.2073,64.5 64.8551,82.859253 102.0762,165.810333 124.2931,277.000003 14.0907,70.51984 21.3293,148.19289 23.1621,248.5385 l 0.6751,36.9615 h -24.0006 -24.0006 l -0.6451,-40.25 c -0.8728,-54.45747 -3.2294,-97.37808 -7.7552,-141.25 -2.0157,-19.53876 -5.5649,-48.26034 -6.4568,-52.25 l -0.503,-2.25 h -138.9015 -138.9015 l -0.5737,2.75 c -1.3048,6.25497 -5.6037,42.23877 -7.4966,62.75 -4.1897,45.40108 -5.8724,78.08226 -6.758,131.25 l -0.6537,39.25 h -23.9965 -23.9964 z m 329.9901,-257.5 c -16.2344,-75.39296 -44.3576,-142.31154 -84.8247,-201.83821 -14.6478,-21.54687 -41.7256,-56.911793 -43.5754,-56.911793 -0.9462,0 -17.0989,20.3312 -30.1903,38.000003 -41.3759,55.84305 -70.8145,117.14692 -89.7989,187 -4.4541,16.38903 -9.9804,40.25799 -9.9804,43.1072 0,1.84739 3.1285,1.8928 130.3961,1.8928 h 130.3961 z M 1909.3012,313.12705 V 0 l 28.75,0.545379 c 17.9216,0.339968 32.5164,1.11895 38.75,2.068238 49.7522,7.576561 85.9285,24.147722 113.9522,52.19778 12.4706,12.48242 21.7636,25.36226 29.5404,40.9427 21.2693,42.611433 24.3464,94.029103 8.5077,142.162463 -6.3556,19.31469 -11.5913,29.57928 -25.0003,49.0135 -0.7465,1.08188 -0.3662,1.95829 1.5,3.45676 14.1948,11.39799 25.2886,24.1977 34.6589,39.98836 24.0771,40.57424 32.4157,95.7704 21.7183,143.7621 -16.6222,74.57234 -71.742,126.3476 -153.8772,144.54032 -23.5242,5.21055 -47.5765,7.55118 -77.75,7.56618 l -20.75,0.0103 z m 67.0296,262.68603 c 76.2213,-10.14858 125.4273,-50.12555 139.1595,-113.05898 2.8851,-13.22248 3.5837,-41.39321 1.3952,-56.26475 -7.6001,-51.6453 -39.0273,-90.16381 -87.8883,-107.71956 l -8.8039,-3.16327 4.3039,-1.92621 c 8.6623,-3.87675 22.4588,-13.8852 30.7894,-22.33564 20.7256,-21.02389 32.3393,-47.80952 35.1972,-81.17828 2.6177,-30.56363 -3.3016,-57.78392 -17.8905,-82.27023 -6.1953,-10.398453 -22.0413,-26.645363 -32.7921,-33.621833 -20.4272,-13.25571 -46.3837,-21.8786 -74.75,-24.83229 l -7.75,-0.80699 V 312.94458 577.2541 l 4.25,-0.0195 c 2.3375,-0.0107 8.9883,-0.65041 14.7796,-1.4215 z m 709.8989,48.91102 c -54.2863,-8.46314 -107.5748,-44.21736 -148.5323,-99.65857 -36.799,-49.81226 -57.332,-112.54974 -57.3859,-175.33969 l -0.01,-12.02826 10.0146,-5.3032 c 5.508,-2.91675 13.9455,-7.89048 18.75,-11.05272 53.4162,-35.15792 97.2057,-103.2045 120.2758,-186.90192 10.4228,-37.814683 17.9593,-90.590529 17.9593,-125.765195 V 0.254097 h 24 24 l -0.014,6.25 c -0.024,10.561015 -1.8792,39.47964 -3.5126,54.75 -8.8899,83.111443 -36.952,162.700163 -78.2523,221.937063 -21.4625,30.78363 -50.9331,60.30689 -77.4119,77.55035 l -7.6586,4.98741 0.4809,5.01259 c 3.2211,33.5697 12.0172,63.4558 27.5226,93.51259 32.7718,63.52705 89.9499,109.46939 141.5954,113.77113 l 8.7506,0.72887 0.2681,23.75 0.2681,23.75 -6.2681,-0.0969 c -3.4475,-0.0533 -10.1253,-0.69818 -14.8396,-1.43314 z\"/>
						</svg>\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("110","cron","a:6:{i:1519534290;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1519556580;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1519560069;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1519577559;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1519578180;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("111","theme_mods_twentyseventeen","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1516563638;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("125","can_compress_scripts","1","no");
INSERT INTO `wp_options` VALUES("139","recently_activated","a:1:{s:27:\"woocommerce/woocommerce.php\";i:1519483001;}","yes");
INSERT INTO `wp_options` VALUES("163","polylang","a:15:{s:7:\"browser\";b:0;s:7:\"rewrite\";i:1;s:12:\"hide_default\";i:1;s:10:\"force_lang\";i:1;s:13:\"redirect_lang\";i:0;s:13:\"media_support\";i:1;s:9:\"uninstall\";i:0;s:4:\"sync\";a:11:{i:0;s:10:\"taxonomies\";i:1;s:9:\"post_meta\";i:2;s:14:\"comment_status\";i:3;s:11:\"ping_status\";i:4;s:12:\"sticky_posts\";i:5;s:9:\"post_date\";i:6;s:11:\"post_format\";i:7;s:11:\"post_parent\";i:8;s:17:\"_wp_page_template\";i:9;s:10:\"menu_order\";i:10;s:13:\"_thumbnail_id\";}s:10:\"post_types\";a:0:{}s:10:\"taxonomies\";a:0:{}s:7:\"domains\";a:0:{}s:7:\"version\";s:5:\"2.3.1\";s:16:\"previous_version\";s:3:\"2.3\";s:12:\"default_lang\";s:2:\"uk\";s:9:\"nav_menus\";a:1:{s:8:\"Golubika\";a:3:{s:3:\"top\";a:0:{}s:6:\"bottom\";a:2:{s:2:\"en\";i:0;s:2:\"uk\";i:0;}s:4:\"menu\";a:1:{s:2:\"uk\";i:0;}}}}","yes");
INSERT INTO `wp_options` VALUES("164","polylang_wpml_strings","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("165","widget_polylang","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("166","UPCP_Currency_Symbol_Location","Before","yes");
INSERT INTO `wp_options` VALUES("167","UPCP_Price_Filter","No","yes");
INSERT INTO `wp_options` VALUES("168","UPCP_Sale_Mode","Individual","yes");
INSERT INTO `wp_options` VALUES("169","UPCP_Product_Sort","a:2:{i:0;s:4:\"Name\";i:1;s:5:\"Price\";}","yes");
INSERT INTO `wp_options` VALUES("170","UPCP_Product_Search","name","yes");
INSERT INTO `wp_options` VALUES("171","UPCP_Custom_Product_Page","No","yes");
INSERT INTO `wp_options` VALUES("172","UPCP_Sidebar_Order","Normal","yes");
INSERT INTO `wp_options` VALUES("173","UPCP_Apply_Contents_Filter","Yes","yes");
INSERT INTO `wp_options` VALUES("174","UPCP_Maintain_Filtering","Yes","yes");
INSERT INTO `wp_options` VALUES("175","UPCP_Thumbnail_Support","No","yes");
INSERT INTO `wp_options` VALUES("176","UPCP_Show_Category_Descriptions","No","yes");
INSERT INTO `wp_options` VALUES("177","UPCP_Show_Catalogue_Information","None","yes");
INSERT INTO `wp_options` VALUES("178","UPCP_Display_Category_Image","No","yes");
INSERT INTO `wp_options` VALUES("179","UPCP_Display_SubCategory_Image","No","yes");
INSERT INTO `wp_options` VALUES("180","UPCP_Overview_Mode","None","yes");
INSERT INTO `wp_options` VALUES("181","UPCP_Inner_Filter","No","yes");
INSERT INTO `wp_options` VALUES("182","UPCP_Breadcrumbs","None","yes");
INSERT INTO `wp_options` VALUES("183","UPCP_Product_Comparison","No","yes");
INSERT INTO `wp_options` VALUES("184","UPCP_Product_Inquiry_Form","No","yes");
INSERT INTO `wp_options` VALUES("185","UPCP_Product_Inquiry_Cart","No","yes");
INSERT INTO `wp_options` VALUES("186","UPCP_Inquiry_Form_Email","0","yes");
INSERT INTO `wp_options` VALUES("187","UPCP_Product_Reviews","No","yes");
INSERT INTO `wp_options` VALUES("188","UPCP_Catalog_Display_Reviews","No","yes");
INSERT INTO `wp_options` VALUES("189","UPCP_Lightbox","No","yes");
INSERT INTO `wp_options` VALUES("190","UPCP_Lightbox_Mode","No","yes");
INSERT INTO `wp_options` VALUES("191","UPCP_Hidden_Drop_Down_Sidebar_On_Mobile","No","yes");
INSERT INTO `wp_options` VALUES("192","UPCP_Infinite_Scroll","No","yes");
INSERT INTO `wp_options` VALUES("193","UPCP_Products_Per_Page","1000000","yes");
INSERT INTO `wp_options` VALUES("194","UPCP_Pagination_Location","Top","yes");
INSERT INTO `wp_options` VALUES("195","UPCP_CF_Conversion","No","yes");
INSERT INTO `wp_options` VALUES("196","UPCP_Access_Role","administrator","yes");
INSERT INTO `wp_options` VALUES("197","UPCP_PP_Grid_Width","90","yes");
INSERT INTO `wp_options` VALUES("198","UPCP_PP_Grid_Height","35","yes");
INSERT INTO `wp_options` VALUES("199","UPCP_Top_Bottom_Padding","10","yes");
INSERT INTO `wp_options` VALUES("200","UPCP_Left_Right_Padding","10","yes");
INSERT INTO `wp_options` VALUES("201","UPCP_WooCommerce_Sync","No","yes");
INSERT INTO `wp_options` VALUES("202","UPCP_WooCommerce_Show_Cart_Count","No","yes");
INSERT INTO `wp_options` VALUES("203","UPCP_WooCommerce_Checkout","No","yes");
INSERT INTO `wp_options` VALUES("204","UPCP_WooCommerce_Cart_Page","Checkout","yes");
INSERT INTO `wp_options` VALUES("205","UPCP_WooCommerce_Product_Page","No","yes");
INSERT INTO `wp_options` VALUES("206","UPCP_WooCommerce_Back_Link","No","yes");
INSERT INTO `wp_options` VALUES("207","UPCP_SEO_Option","None","yes");
INSERT INTO `wp_options` VALUES("208","UPCP_SEO_Integration","Add","yes");
INSERT INTO `wp_options` VALUES("209","UPCP_SEO_Title","[page-title] | [product-name]","yes");
INSERT INTO `wp_options` VALUES("210","UPCP_Update_Breadcrumbs","No","yes");
INSERT INTO `wp_options` VALUES("211","UPCP_List_View_Click_Action","Expand","yes");
INSERT INTO `wp_options` VALUES("212","UPCP_Details_Icon_Type","Default","yes");
INSERT INTO `wp_options` VALUES("213","UPCP_Pagination_Background","None","yes");
INSERT INTO `wp_options` VALUES("214","UPCP_Pagination_Border","none","yes");
INSERT INTO `wp_options` VALUES("215","UPCP_Pagination_Shadow","shadow-none","yes");
INSERT INTO `wp_options` VALUES("216","UPCP_Pagination_Gradient","gradient-none","yes");
INSERT INTO `wp_options` VALUES("217","UPCP_Pagination_Font","none","yes");
INSERT INTO `wp_options` VALUES("218","UPCP_Sidebar_Title_Collapse","no","yes");
INSERT INTO `wp_options` VALUES("219","UPCP_Sidebar_Start_Collapsed","no","yes");
INSERT INTO `wp_options` VALUES("220","UPCP_Sidebar_Title_Hover","none","yes");
INSERT INTO `wp_options` VALUES("221","UPCP_Sidebar_Checkbox_Style","none","yes");
INSERT INTO `wp_options` VALUES("222","UPCP_Categories_Control_Type","Checkbox","yes");
INSERT INTO `wp_options` VALUES("223","UPCP_SubCategories_Control_Type","Checkbox","yes");
INSERT INTO `wp_options` VALUES("224","UPCP_Tags_Control_Type","Checkbox","yes");
INSERT INTO `wp_options` VALUES("225","UPCP_Installed_Skins","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("227","UPCP_Full_Version","No","yes");
INSERT INTO `wp_options` VALUES("228","UPCP_Color_Scheme","Blue","yes");
INSERT INTO `wp_options` VALUES("229","UPCP_Product_Links","Same","yes");
INSERT INTO `wp_options` VALUES("230","UPCP_Tag_Logic","AND","yes");
INSERT INTO `wp_options` VALUES("231","UPCP_Read_More","Yes","yes");
INSERT INTO `wp_options` VALUES("232","UPCP_Pretty_Links","No","yes");
INSERT INTO `wp_options` VALUES("233","UPCP_Mobile_SS","No","yes");
INSERT INTO `wp_options` VALUES("234","UPCP_Install_Flag","No","yes");
INSERT INTO `wp_options` VALUES("235","UPCP_First_Install_Version","3.6","yes");
INSERT INTO `wp_options` VALUES("236","UPCP_Desc_Chars","240","yes");
INSERT INTO `wp_options` VALUES("237","UPCP_Case_Insensitive_Search","Yes","yes");
INSERT INTO `wp_options` VALUES("238","UPCP_Run_Tutorial","Yes","yes");
INSERT INTO `wp_options` VALUES("239","plugin_error","","yes");
INSERT INTO `wp_options` VALUES("240","UPCP_Product_Import","None","yes");
INSERT INTO `wp_options` VALUES("241","widget_upcp_product_list_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("242","widget_upcp_random_products_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("243","widget_upcp_recent_products_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("244","widget_upcp_popular_products_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("245","widget_upcp_search_bar_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("246","UPCP_Blog_Content","<h3>Filter WooCommerce Products by Attribute!</h3>
<p>Want visitors to easily search WooCommerce products by attributes, price, tags and more?</p>
<p><a target=\'_blank\' href=\'http://www.etoilewebdesign.com/product-catalog-woocommerce-sync-tips/\'>Read our tips on making your products filterable with the Ultimate Product Catalog plugin!</a></p>","yes");
INSERT INTO `wp_options` VALUES("247","UPCP_Dash_Cache","1517753705","yes");
INSERT INTO `wp_options` VALUES("248","UPCP_Hide_Dash_Review_Ask","No","yes");
INSERT INTO `wp_options` VALUES("249","UPCP_Changelog_Content","
<h3>4.3.3</h3>
<br />- New product page style (Shop Style)
<br />- New sidebar style (Contemporary)
<br />- Removed references to JS and CSS files that are no longer used and that were appearing in the console

<h3>4.3.2</h3>
<br />- Added in an option to delete many items from a catalog at once
<br />- Fixed an error where YouTube videos wouldn\'t play correctly for https sites

","yes");
INSERT INTO `wp_options` VALUES("250","UPCP_Update_Flag","No","yes");
INSERT INTO `wp_options` VALUES("253","current_theme","Golubika Theme","yes");
INSERT INTO `wp_options` VALUES("254","theme_mods_Golubika","a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:5:{s:8:\"top___en\";i:0;s:3:\"top\";i:0;s:11:\"bottom___en\";i:0;s:6:\"bottom\";i:0;s:4:\"menu\";i:0;}s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `wp_options` VALUES("255","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("301","new_admin_email","serg.didyk@gmail.com","yes");
INSERT INTO `wp_options` VALUES("354","dismissed_update_core","a:0:{}","no");
INSERT INTO `wp_options` VALUES("388","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:20:\"serg.didyk@gmail.com\";s:7:\"version\";s:5:\"4.9.4\";s:9:\"timestamp\";i:1518107208;}","no");
INSERT INTO `wp_options` VALUES("448","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("474","rewrite_rules","a:256:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:52:\"(en)/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?lang=$matches[1]&category_name=$matches[2]&feed=$matches[3]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:47:\"(en)/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?lang=$matches[1]&category_name=$matches[2]&feed=$matches[3]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:28:\"(en)/category/(.+?)/embed/?$\";s:63:\"index.php?lang=$matches[1]&category_name=$matches[2]&embed=true\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:40:\"(en)/category/(.+?)/page/?([0-9]{1,})/?$\";s:70:\"index.php?lang=$matches[1]&category_name=$matches[2]&paged=$matches[3]\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:22:\"(en)/category/(.+?)/?$\";s:52:\"index.php?lang=$matches[1]&category_name=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:49:\"(en)/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?lang=$matches[1]&tag=$matches[2]&feed=$matches[3]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:44:\"(en)/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?lang=$matches[1]&tag=$matches[2]&feed=$matches[3]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:25:\"(en)/tag/([^/]+)/embed/?$\";s:53:\"index.php?lang=$matches[1]&tag=$matches[2]&embed=true\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:37:\"(en)/tag/([^/]+)/page/?([0-9]{1,})/?$\";s:60:\"index.php?lang=$matches[1]&tag=$matches[2]&paged=$matches[3]\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:19:\"(en)/tag/([^/]+)/?$\";s:42:\"index.php?lang=$matches[1]&tag=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:50:\"(en)/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:67:\"index.php?lang=$matches[1]&post_format=$matches[2]&feed=$matches[3]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:58:\"index.php?lang=uk&post_format=$matches[1]&feed=$matches[2]\";s:45:\"(en)/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:67:\"index.php?lang=$matches[1]&post_format=$matches[2]&feed=$matches[3]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:58:\"index.php?lang=uk&post_format=$matches[1]&feed=$matches[2]\";s:26:\"(en)/type/([^/]+)/embed/?$\";s:61:\"index.php?lang=$matches[1]&post_format=$matches[2]&embed=true\";s:21:\"type/([^/]+)/embed/?$\";s:52:\"index.php?lang=uk&post_format=$matches[1]&embed=true\";s:38:\"(en)/type/([^/]+)/page/?([0-9]{1,})/?$\";s:68:\"index.php?lang=$matches[1]&post_format=$matches[2]&paged=$matches[3]\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:59:\"index.php?lang=uk&post_format=$matches[1]&paged=$matches[2]\";s:20:\"(en)/type/([^/]+)/?$\";s:50:\"index.php?lang=$matches[1]&post_format=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:41:\"index.php?lang=uk&post_format=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:37:\"(en)/category/(.+?)/wc-api(/(.*))?/?$\";s:71:\"index.php?lang=$matches[1]&category_name=$matches[2]&wc-api=$matches[4]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:34:\"(en)/tag/([^/]+)/wc-api(/(.*))?/?$\";s:61:\"index.php?lang=$matches[1]&tag=$matches[2]&wc-api=$matches[4]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:37:\"(en)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?lang=$matches[1]&&feed=$matches[2]\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:35:\"index.php?lang=uk&&feed=$matches[1]\";s:32:\"(en)/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?lang=$matches[1]&&feed=$matches[2]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:35:\"index.php?lang=uk&&feed=$matches[1]\";s:13:\"(en)/embed/?$\";s:38:\"index.php?lang=$matches[1]&&embed=true\";s:8:\"embed/?$\";s:29:\"index.php?lang=uk&&embed=true\";s:25:\"(en)/page/?([0-9]{1,})/?$\";s:45:\"index.php?lang=$matches[1]&&paged=$matches[2]\";s:20:\"page/?([0-9]{1,})/?$\";s:36:\"index.php?lang=uk&&paged=$matches[1]\";s:22:\"(en)/wc-api(/(.*))?/?$\";s:46:\"index.php?lang=$matches[1]&&wc-api=$matches[3]\";s:17:\"wc-api(/(.*))?/?$\";s:37:\"index.php?lang=uk&&wc-api=$matches[2]\";s:7:\"(en)/?$\";s:26:\"index.php?lang=$matches[1]\";s:46:\"(en)/comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?lang=$matches[1]&&feed=$matches[2]&withcomments=1\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?lang=uk&&feed=$matches[1]&withcomments=1\";s:41:\"(en)/comments/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?lang=$matches[1]&&feed=$matches[2]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?lang=uk&&feed=$matches[1]&withcomments=1\";s:22:\"(en)/comments/embed/?$\";s:38:\"index.php?lang=$matches[1]&&embed=true\";s:17:\"comments/embed/?$\";s:29:\"index.php?lang=uk&&embed=true\";s:31:\"(en)/comments/wc-api(/(.*))?/?$\";s:46:\"index.php?lang=$matches[1]&&wc-api=$matches[3]\";s:26:\"comments/wc-api(/(.*))?/?$\";s:37:\"index.php?lang=uk&&wc-api=$matches[2]\";s:49:\"(en)/search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?lang=$matches[1]&s=$matches[2]&feed=$matches[3]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?lang=uk&s=$matches[1]&feed=$matches[2]\";s:44:\"(en)/search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?lang=$matches[1]&s=$matches[2]&feed=$matches[3]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?lang=uk&s=$matches[1]&feed=$matches[2]\";s:25:\"(en)/search/(.+)/embed/?$\";s:51:\"index.php?lang=$matches[1]&s=$matches[2]&embed=true\";s:20:\"search/(.+)/embed/?$\";s:42:\"index.php?lang=uk&s=$matches[1]&embed=true\";s:37:\"(en)/search/(.+)/page/?([0-9]{1,})/?$\";s:58:\"index.php?lang=$matches[1]&s=$matches[2]&paged=$matches[3]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:49:\"index.php?lang=uk&s=$matches[1]&paged=$matches[2]\";s:34:\"(en)/search/(.+)/wc-api(/(.*))?/?$\";s:59:\"index.php?lang=$matches[1]&s=$matches[2]&wc-api=$matches[4]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:50:\"index.php?lang=uk&s=$matches[1]&wc-api=$matches[3]\";s:19:\"(en)/search/(.+)/?$\";s:40:\"index.php?lang=$matches[1]&s=$matches[2]\";s:14:\"search/(.+)/?$\";s:31:\"index.php?lang=uk&s=$matches[1]\";s:52:\"(en)/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:67:\"index.php?lang=$matches[1]&author_name=$matches[2]&feed=$matches[3]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:58:\"index.php?lang=uk&author_name=$matches[1]&feed=$matches[2]\";s:47:\"(en)/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:67:\"index.php?lang=$matches[1]&author_name=$matches[2]&feed=$matches[3]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:58:\"index.php?lang=uk&author_name=$matches[1]&feed=$matches[2]\";s:28:\"(en)/author/([^/]+)/embed/?$\";s:61:\"index.php?lang=$matches[1]&author_name=$matches[2]&embed=true\";s:23:\"author/([^/]+)/embed/?$\";s:52:\"index.php?lang=uk&author_name=$matches[1]&embed=true\";s:40:\"(en)/author/([^/]+)/page/?([0-9]{1,})/?$\";s:68:\"index.php?lang=$matches[1]&author_name=$matches[2]&paged=$matches[3]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:59:\"index.php?lang=uk&author_name=$matches[1]&paged=$matches[2]\";s:37:\"(en)/author/([^/]+)/wc-api(/(.*))?/?$\";s:69:\"index.php?lang=$matches[1]&author_name=$matches[2]&wc-api=$matches[4]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:60:\"index.php?lang=uk&author_name=$matches[1]&wc-api=$matches[3]\";s:22:\"(en)/author/([^/]+)/?$\";s:50:\"index.php?lang=$matches[1]&author_name=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:41:\"index.php?lang=uk&author_name=$matches[1]\";s:74:\"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&feed=$matches[5]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:88:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:69:\"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&feed=$matches[5]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:88:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:50:\"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:91:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&embed=true\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:82:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:62:\"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:98:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&paged=$matches[5]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:89:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:59:\"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:99:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&wc-api=$matches[6]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:90:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:44:\"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:80:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:71:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:61:\"(en)/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:81:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&feed=$matches[4]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:72:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:56:\"(en)/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:81:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&feed=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:72:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:37:\"(en)/([0-9]{4})/([0-9]{1,2})/embed/?$\";s:75:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&embed=true\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:66:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&embed=true\";s:49:\"(en)/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:82:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&paged=$matches[4]\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:73:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:46:\"(en)/([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:83:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&wc-api=$matches[5]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:74:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:31:\"(en)/([0-9]{4})/([0-9]{1,2})/?$\";s:64:\"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:55:\"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]\";s:48:\"(en)/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:60:\"index.php?lang=$matches[1]&year=$matches[2]&feed=$matches[3]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?lang=uk&year=$matches[1]&feed=$matches[2]\";s:43:\"(en)/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:60:\"index.php?lang=$matches[1]&year=$matches[2]&feed=$matches[3]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?lang=uk&year=$matches[1]&feed=$matches[2]\";s:24:\"(en)/([0-9]{4})/embed/?$\";s:54:\"index.php?lang=$matches[1]&year=$matches[2]&embed=true\";s:19:\"([0-9]{4})/embed/?$\";s:45:\"index.php?lang=uk&year=$matches[1]&embed=true\";s:36:\"(en)/([0-9]{4})/page/?([0-9]{1,})/?$\";s:61:\"index.php?lang=$matches[1]&year=$matches[2]&paged=$matches[3]\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:52:\"index.php?lang=uk&year=$matches[1]&paged=$matches[2]\";s:33:\"(en)/([0-9]{4})/wc-api(/(.*))?/?$\";s:62:\"index.php?lang=$matches[1]&year=$matches[2]&wc-api=$matches[4]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:53:\"index.php?lang=uk&year=$matches[1]&wc-api=$matches[3]\";s:18:\"(en)/([0-9]{4})/?$\";s:43:\"index.php?lang=$matches[1]&year=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:34:\"index.php?lang=uk&year=$matches[1]\";s:32:\"(en)/.?.+?/attachment/([^/]+)/?$\";s:49:\"index.php?lang=$matches[1]&attachment=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"(en)/.?.+?/attachment/([^/]+)/trackback/?$\";s:54:\"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"(en)/.?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"(en)/.?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"(en)/.?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:67:\"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"(en)/.?.+?/attachment/([^/]+)/embed/?$\";s:60:\"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"(en)/(.?.+?)/embed/?$\";s:58:\"index.php?lang=$matches[1]&pagename=$matches[2]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:25:\"(en)/(.?.+?)/trackback/?$\";s:52:\"index.php?lang=$matches[1]&pagename=$matches[2]&tb=1\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:45:\"(en)/(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?lang=$matches[1]&pagename=$matches[2]&feed=$matches[3]\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:40:\"(en)/(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?lang=$matches[1]&pagename=$matches[2]&feed=$matches[3]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:33:\"(en)/(.?.+?)/page/?([0-9]{1,})/?$\";s:65:\"index.php?lang=$matches[1]&pagename=$matches[2]&paged=$matches[3]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:40:\"(en)/(.?.+?)/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?lang=$matches[1]&pagename=$matches[2]&cpage=$matches[3]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:33:\"(en)/(.?.+?)/order-pay(/(.*))?/?$\";s:69:\"index.php?lang=$matches[1]&pagename=$matches[2]&order-pay=$matches[4]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:38:\"(en)/(.?.+?)/order-received(/(.*))?/?$\";s:74:\"index.php?lang=$matches[1]&pagename=$matches[2]&order-received=$matches[4]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:30:\"(en)/(.?.+?)/orders(/(.*))?/?$\";s:66:\"index.php?lang=$matches[1]&pagename=$matches[2]&orders=$matches[4]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:34:\"(en)/(.?.+?)/view-order(/(.*))?/?$\";s:70:\"index.php?lang=$matches[1]&pagename=$matches[2]&view-order=$matches[4]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:33:\"(en)/(.?.+?)/downloads(/(.*))?/?$\";s:69:\"index.php?lang=$matches[1]&pagename=$matches[2]&downloads=$matches[4]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:36:\"(en)/(.?.+?)/edit-account(/(.*))?/?$\";s:72:\"index.php?lang=$matches[1]&pagename=$matches[2]&edit-account=$matches[4]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:36:\"(en)/(.?.+?)/edit-address(/(.*))?/?$\";s:72:\"index.php?lang=$matches[1]&pagename=$matches[2]&edit-address=$matches[4]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:39:\"(en)/(.?.+?)/payment-methods(/(.*))?/?$\";s:75:\"index.php?lang=$matches[1]&pagename=$matches[2]&payment-methods=$matches[4]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:37:\"(en)/(.?.+?)/lost-password(/(.*))?/?$\";s:73:\"index.php?lang=$matches[1]&pagename=$matches[2]&lost-password=$matches[4]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:39:\"(en)/(.?.+?)/customer-logout(/(.*))?/?$\";s:75:\"index.php?lang=$matches[1]&pagename=$matches[2]&customer-logout=$matches[4]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:42:\"(en)/(.?.+?)/add-payment-method(/(.*))?/?$\";s:78:\"index.php?lang=$matches[1]&pagename=$matches[2]&add-payment-method=$matches[4]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:45:\"(en)/(.?.+?)/delete-payment-method(/(.*))?/?$\";s:81:\"index.php?lang=$matches[1]&pagename=$matches[2]&delete-payment-method=$matches[4]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:50:\"(en)/(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:86:\"index.php?lang=$matches[1]&pagename=$matches[2]&set-default-payment-method=$matches[4]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:30:\"(en)/(.?.+?)/wc-api(/(.*))?/?$\";s:66:\"index.php?lang=$matches[1]&pagename=$matches[2]&wc-api=$matches[4]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:36:\"(en)/.?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:68:\"index.php?lang=$matches[1]&attachment=$matches[2]&wc-api=$matches[4]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:47:\"(en)/.?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:68:\"index.php?lang=$matches[1]&attachment=$matches[2]&wc-api=$matches[4]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:29:\"(en)/(.?.+?)(?:/([0-9]+))?/?$\";s:64:\"index.php?lang=$matches[1]&pagename=$matches[2]&page=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:32:\"(en)/[^/]+/attachment/([^/]+)/?$\";s:49:\"index.php?lang=$matches[1]&attachment=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"(en)/[^/]+/attachment/([^/]+)/trackback/?$\";s:54:\"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"(en)/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"(en)/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"(en)/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:67:\"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"(en)/[^/]+/attachment/([^/]+)/embed/?$\";s:60:\"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"(en)/([^/]+)/embed/?$\";s:54:\"index.php?lang=$matches[1]&name=$matches[2]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:25:\"(en)/([^/]+)/trackback/?$\";s:48:\"index.php?lang=$matches[1]&name=$matches[2]&tb=1\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:45:\"(en)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:60:\"index.php?lang=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:40:\"(en)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:60:\"index.php?lang=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:33:\"(en)/([^/]+)/page/?([0-9]{1,})/?$\";s:61:\"index.php?lang=$matches[1]&name=$matches[2]&paged=$matches[3]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:40:\"(en)/([^/]+)/comment-page-([0-9]{1,})/?$\";s:61:\"index.php?lang=$matches[1]&name=$matches[2]&cpage=$matches[3]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:30:\"(en)/([^/]+)/wc-api(/(.*))?/?$\";s:62:\"index.php?lang=$matches[1]&name=$matches[2]&wc-api=$matches[4]\";s:25:\"([^/]+)/wc-api(/(.*))?/?$\";s:45:\"index.php?name=$matches[1]&wc-api=$matches[3]\";s:36:\"(en)/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:68:\"index.php?lang=$matches[1]&attachment=$matches[2]&wc-api=$matches[4]\";s:31:\"[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:47:\"(en)/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:68:\"index.php?lang=$matches[1]&attachment=$matches[2]&wc-api=$matches[4]\";s:42:\"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:29:\"(en)/([^/]+)(?:/([0-9]+))?/?$\";s:60:\"index.php?lang=$matches[1]&name=$matches[2]&page=$matches[3]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:21:\"(en)/[^/]+/([^/]+)/?$\";s:49:\"index.php?lang=$matches[1]&attachment=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\"(en)/[^/]+/([^/]+)/trackback/?$\";s:54:\"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\"(en)/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"(en)/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"(en)/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:67:\"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"(en)/[^/]+/([^/]+)/embed/?$\";s:60:\"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `wp_options` VALUES("596","current_theme_supports_woocommerce","no","yes");
INSERT INTO `wp_options` VALUES("598","_transient_wc_attribute_taxonomies","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("599","product_cat_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("600","default_product_cat","39","yes");
INSERT INTO `wp_options` VALUES("606","_transient_woocommerce_webhook_ids","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("607","widget_woocommerce_widget_cart","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("608","widget_woocommerce_layered_nav_filters","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("609","widget_woocommerce_layered_nav","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("610","widget_woocommerce_price_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("611","widget_woocommerce_product_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("612","widget_woocommerce_product_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("613","widget_woocommerce_product_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("614","widget_woocommerce_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("615","widget_woocommerce_recently_viewed_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("616","widget_woocommerce_top_rated_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("617","widget_woocommerce_recent_reviews","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("618","widget_woocommerce_rating_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("620","_transient_wc_count_comments","O:8:\"stdClass\":7:{s:14:\"total_comments\";i:0;s:3:\"all\";i:0;s:9:\"moderated\";i:0;s:8:\"approved\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("628","_transient_timeout_wc_low_stock_count","1520873432","no");
INSERT INTO `wp_options` VALUES("629","_transient_wc_low_stock_count","0","no");
INSERT INTO `wp_options` VALUES("630","_transient_timeout_wc_outofstock_count","1520873432","no");
INSERT INTO `wp_options` VALUES("631","_transient_wc_outofstock_count","0","no");
INSERT INTO `wp_options` VALUES("645","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp_options` VALUES("646","aio_wp_security_configs","a:87:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:1:\"1\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:60;s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"9boae3otjbi5x7b7q6kf\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"y9t13745ja38h0dirf5q\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:2;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:1;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:31:\"aiowps_enable_pingback_firewall\";s:1:\"1\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:1:\"1\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:1:\"1\";s:30:\"aiowps_disable_trace_and_track\";s:1:\"1\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:1:\"1\";s:34:\"aiowps_advanced_char_string_filter\";s:1:\"1\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:1:\"1\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:1:\"1\";s:32:\"aiowps_prevent_users_enumeration\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2018-02-11 09:19:21\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";}","yes");
INSERT INTO `wp_options` VALUES("698","_site_transient_timeout_browser_2502d8a009196a678ffa1eb36d6bb2e0","1519662710","no");
INSERT INTO `wp_options` VALUES("699","_site_transient_browser_2502d8a009196a678ffa1eb36d6bb2e0","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"64.0.3282.167\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("735","_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e","1519525935","no");
INSERT INTO `wp_options` VALUES("736","_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e","a:2:{s:8:\"location\";a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}s:6:\"events\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("737","_transient_timeout_feed_126d1ca39d75da07beec8b892738427b","1519525936","no");
INSERT INTO `wp_options` VALUES("738","_transient_feed_126d1ca39d75da07beec8b892738427b","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Блог — Русский\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://ru.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Русский\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"
	Thu, 22 Feb 2018 17:59:21 +0000	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"ru-RU\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.0-alpha-42730\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"Выпуск WordPress 4.9.4 (требуется ручное обновление)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"https://ru.wordpress.org/news/2018/02/%d0%b2%d1%8b%d0%bf%d1%83%d1%81%d0%ba-wordpress-4-9-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 06 Feb 2018 16:46:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:22:\"Исправления\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:12:\"Релизы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1886\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:661:\"Доступна версия WordPress 4.9.4, исправляющая внесенную в выпуске 4.9.3 ошибку с автообновлением. Если вы успели (возможно автоматически) обновить свой сайт (или сайты) до 4.9.3, то вам нужно обновить WordPress  до версии 4.9.4, используя кнопку в Консоль &#62; Обновления, либо иным удобным вам способом (wp-cli, через ftp или ssh). Скачать архив дистрибутива можно здесь. Детали ошибки [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:905:\"<p>Доступна версия WordPress 4.9.4, исправляющая внесенную в выпуске 4.9.3 ошибку с автообновлением. Если вы успели (возможно автоматически) обновить свой сайт (или сайты) до 4.9.3, то вам нужно обновить WordPress  до версии 4.9.4, используя кнопку в <em>Консоль &gt; Обновления, </em>либо иным удобным вам способом (wp-cli, через ftp или ssh). Скачать архив дистрибутива можно <a href=\"https://ru.wordpress.org/releases/\">здесь</a>.</p>
<p>Детали ошибки <a href=\"https://make.wordpress.org/core/2018/02/06/wordpress-4-9-4-release-the-technical-details/\" target=\"_blank\" rel=\"noopener\">доступны</a> в блоге Make WordPress.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"Всемирный день перевода WordPress 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://ru.wordpress.org/news/2017/09/wp-translation-day-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 Sep 2017 18:55:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1841\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:655:\"Всемирный день перевода — это мероприятие, которое проходит по всему миру в один день в формате вебинаров или митапов, когда каждый может принять участие в переводе плагинов, тем, документации и ядра WordPress на свой родной язык. Быть разработчиком для этого совсем не обязательно, участвовать может любой желающий. Если вы давно хотели внести свой вклад в [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4393:\"<p><a href=\"https://wptranslationday.org/\">Всемирный день перевода</a> — это мероприятие, которое проходит по всему миру в один день в формате вебинаров или митапов, когда каждый может принять участие в переводе плагинов, тем, документации и ядра WordPress на свой родной язык.</p>
<p><a href=\"https://wptranslationday.org/\"><img class=\"alignnone wp-image-1842 size-full\" src=\"https://ru.wordpress.org/files/2017/09/4by3.jpg\" alt=\"\" width=\"1024\" height=\"768\" srcset=\"https://ru.wordpress.org/files/2017/09/4by3.jpg 1024w, https://ru.wordpress.org/files/2017/09/4by3-300x225.jpg 300w, https://ru.wordpress.org/files/2017/09/4by3-768x576.jpg 768w, https://ru.wordpress.org/files/2017/09/4by3-440x330.jpg 440w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /></a></p>
<p>Быть разработчиком для этого совсем не обязательно, участвовать может любой желающий. Если вы давно хотели внести свой вклад в развитие WordPress — сейчас самое время!</p>
<p>В России в рамках мероприятия планируется встреча в Ростове-на-Дону, а также вебинар для тех, кто будет переводить у себя дома.</p>
<p><strong>Когда</strong></p>
<p>День перевода WordPress пройдёт в субботу, 30 сентября.</p>
<p><strong>Где</strong></p>
<ul>
<li>Ростов-на-Дону: ул. Большая Садовая, д. 81/31 (кафе Starbucks). Начало в 12:00.</li>
<li>Вебинар: <a href=\"https://www.crowdcast.io/e/gwtd3/22\">https://www.crowdcast.io/e/gwtd3/22</a>, начало в 20:00 по московскому времени. Вы узнаете, как переводить WordPress, плагины и темы на русский язык, сможете выбрать проект и приступить к переводу.</li>
</ul>
<p>Расписание всех вебинаров мероприятия: <a href=\"https://wptranslationday.org/#primary\">https://wptranslationday.org/#primary</a>.</p>
<p><strong>Полезные ресурсы</strong></p>
<ul>
<li><a href=\"https://ru.wordpress.org/support/topic/%D0%BA%D0%B0%D0%BA-%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%B5%D1%81%D1%82%D0%B8-%D1%82%D0%B5%D0%BC%D1%83-%D0%B8%D0%BB%D0%B8-%D0%BF%D0%BB%D0%B0%D0%B3%D0%B8%D0%BD/\">Как перевести тему или плагин?</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.A1.D1.82.D0.B8.D0.BB.D1.8C_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.D0.B0\">Рекомендации по стилю перевода</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.9A.D0.B0.D0.BA_.D1.81.D0.B4.D0.B5.D0.BB.D0.B0.D1.82.D1.8C_.D1.85.D0.BE.D1.80.D0.BE.D1.88.D0.B8.D0.B9_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.3F\">Как сделать хороший перевод</a></li>
<li><a href=\"https://translate.wordpress.org/locale/ru/default/glossary\">Словарь терминов</a></li>
<li><a href=\"https://make.wordpress.org/polyglots/handbook/about/get-involved/first-steps/\">Первые шаги переводчика</a></li>
<li><a href=\"https://make.wordpress.org/polyglots/handbook/tools/glotpress-translate-wordpress-org/\">Как работать с сайтом translate.wordpress.org (GlotPress)</a></li>
</ul>
<p>Для координации и обсуждения вопросов стоит зарегистрироваться в <a href=\"https://ruwp.slack.com/\">Slack-группе русскоязычного сообщества WordPress</a> и зайти на канал <code>#translations</code>. При регистрации введите адрес вида <code>username@chat.wordpress.org</code> (он же используется и в <a href=\"https://make.wordpress.org/chat/\">английском Slack</a>), где <code>username</code> — ваш логин на WordPress.org.</p>
<p>Да пребудут с нами понятные интерфейсы и качественная локализация!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"Всемирный день перевода WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ru.wordpress.org/news/2016/11/wp-translation-day/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 09 Nov 2016 16:35:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1751\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:655:\"Всемирный день перевода — это мероприятие, которое проходит по всему миру в один день в формате вебинаров или митапов, когда каждый может принять участие в переводе плагинов, тем, документации и ядра WordPress на свой родной язык. Быть разработчиком для этого совсем не обязательно, участвовать может любой желающий. Если вы давно хотели внести свой вклад в [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Sergey Biryukov\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4653:\"<p><a href=\"https://wptranslationday.org/\">Всемирный день перевода</a> — это мероприятие, которое проходит по всему миру в один день в формате вебинаров или митапов, когда каждый может принять участие в переводе плагинов, тем, документации и ядра WordPress на свой родной язык.</p>
<p><img class=\"alignnone wp-image-1764 size-large\" src=\"https://ru.wordpress.org/files/2016/11/global-wordpress-translation-day-2-1024x579.jpg\" width=\"692\" height=\"391\" srcset=\"https://ru.wordpress.org/files/2016/11/global-wordpress-translation-day-2-1024x579.jpg 1024w, https://ru.wordpress.org/files/2016/11/global-wordpress-translation-day-2-300x170.jpg 300w, https://ru.wordpress.org/files/2016/11/global-wordpress-translation-day-2-768x434.jpg 768w, https://ru.wordpress.org/files/2016/11/global-wordpress-translation-day-2.jpg 1200w\" sizes=\"(max-width: 692px) 100vw, 692px\" /></p>
<p>Быть разработчиком для этого совсем не обязательно, участвовать может любой желающий. Если вы давно хотели внести свой вклад в развитие WordPress — сейчас самое время!</p>
<p>В России в рамках мероприятия планируются встречи в Москве и Ростове-на-Дону, а также вебинар для тех, кто будет переводить у себя дома.</p>
<p><strong>Когда</strong></p>
<p>День перевода WordPress пройдёт в субботу, 12 ноября.</p>
<p><strong>Где</strong></p>
<ul>
<li><a href=\"https://wpmag.ru/2016/global-translation-day-moscow/\">Москва</a>: метро Краснопресненская, БЦ «Трехгорная мануфактура», ул. Рочдельская, д. 15 стр. 10, 2 этаж (офис компании Setka). Начало в 12:00.</li>
<li>Ростов-на-Дону: ул. Большая Садовая, д. 81/31 (кафе Starbucks). Начало в 12:00.</li>
<li>Вебинар: <a href=\"https://www.crowdcast.io/e/gwtd2/14\">https://www.crowdcast.io/e/gwtd2/14</a>, начало в 16:00 по московскому времени. Вы узнаете, как переводить WordPress, плагины и темы на русский язык, сможете выбрать проект и приступить к переводу.</li>
</ul>
<p>Расписание всех вебинаров мероприятия: <a href=\"https://wptranslationday.org/#schedule\">https://wptranslationday.org/#schedule</a>.</p>
<p><strong>Полезные ресурсы</strong></p>
<ul>
<li><a href=\"https://make.wordpress.org/polyglots/handbook/about/get-involved/first-steps/\">Первые шаги переводчика</a></li>
<li><a href=\"https://make.wordpress.org/polyglots/handbook/tools/glotpress-translate-wordpress-org/\">Как работать с сайтом translate.wordpress.org (GlotPress)</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.A1.D1.82.D0.B8.D0.BB.D1.8C_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.D0.B0\">Рекомендации по стилю перевода</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.9A.D0.B0.D0.BA_.D1.81.D0.B4.D0.B5.D0.BB.D0.B0.D1.82.D1.8C_.D1.85.D0.BE.D1.80.D0.BE.D1.88.D0.B8.D0.B9_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.3F\">Как сделать хороший перевод</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.A1.D0.BB.D0.BE.D0.B2.D0.B0.D1.80.D1.8C_.D1.82.D0.B5.D1.80.D0.BC.D0.B8.D0.BD.D0.BE.D0.B2\">Словарь терминов</a></li>
</ul>
<p>Для координации и обсуждения вопросов стоит зарегистрироваться в <a href=\"https://ruwp.slack.com/\">Slack-группе русскоязычного сообщества WordPress</a> и зайти на канал <code>#translations</code>. При регистрации введите адрес вида <code>username@chat.wordpress.org</code> (он же используется и в <a href=\"https://make.wordpress.org/chat/\">английском Slack</a>), где <code>username</code> — ваш логин на WordPress.org.</p>
<p>Да пребудут с нами понятные интерфейсы и качественная локализация!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"Конференция WordCamp Moscow 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://ru.wordpress.org/news/2016/07/wordcamp-moscow-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 26 Jul 2016 14:00:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1722\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:345:\"13 августа в Москве пройдёт конференция WordCamp Moscow 2016 в центре Digital October. Гостей ждет целый день лекций на интересные темы связанные с разработкой, дизайном, предпринимательством и блоггингом.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2961:\"<p>13 августа в Москве пройдёт конференция WordCamp Moscow 2016 в центре Digital October. Гостей ждет целый день лекций на интересные темы связанные с разработкой, дизайном, предпринимательством и блоггингом.</p>
<p><img src=\"https://ru.wordpress.org/files/2016/07/wordcamp-russia-2015-nikolay-1024x684.jpg\" alt=\"Николай Миронов на WordCamp Russia 2015\" width=\"692\" height=\"462\" class=\"alignnone size-large wp-image-1724\" srcset=\"https://ru.wordpress.org/files/2016/07/wordcamp-russia-2015-nikolay-1024x684.jpg 1024w, https://ru.wordpress.org/files/2016/07/wordcamp-russia-2015-nikolay-300x200.jpg 300w, https://ru.wordpress.org/files/2016/07/wordcamp-russia-2015-nikolay-768x513.jpg 768w\" sizes=\"(max-width: 692px) 100vw, 692px\" /></p>
<p>Cписок докладов находится на стадии утверждения, но некоторые темы уже определены:</p>
<ul>
<li>Как заказать разработку сайта у специалиста и остаться довольным</li>
<li>Как работает искусственный интеллект в поисковых системах</li>
<li>Откуда брать идеи для написания постов, плагинов и тем</li>
<li>Как опубликовать свою тему в директорию на WordPress.org</li>
<li>Чем может быть полезен стек Elasticsearch, Logstash и Kibana</li>
<li>Как держать потребление памяти в WordPress под контролем</li>
<li>Что такое A/B тестирование и как его проводить в WordPress</li>
<li>и многое другое</li>
</ul>
<p>В перерывах между докладами можно будет пообщаться с коллегами, задать вопросы опытным специалистам и поделиться своими идеями.</p>
<p>Приобрести билет можно на <a href=\"https://2016.moscow.wordcamp.org/tickets/\">сайте конференции</a> кредитной или дебетовой картой через PayPal, или при помощи системы Яндекс.Деньги.</p>
<p>После мероприятия всех ждёт afterparty, где участники смогут пообщаться в местном баре в неформальной обстановке. Ну и, конечно же, каждый из гостей получит футболку с символикой WordPress и унесет с собой столько наклеек и значков, сколько влезет в карманы.</p>
<p><a href=\"https://2016.moscow.wordcamp.org/tickets/\">Зарегистрироваться</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"Конференция WordCamp Russia 2015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://ru.wordpress.org/news/2015/07/wordcamp-russia-2015/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2015 10:08:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1660\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:282:\"Конференция WordCamp Russia 2015 пройдет в субботу, 15 августа в центре Digital October в Москве. Это третья официальная конференция посвященная самой популярной в мире CMS.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2883:\"<p>Конференция <a href=\"https://russia.wordcamp.org/2015/\">WordCamp Russia 2015</a> пройдет в субботу, 15 августа в центре Digital October в Москве. Это третья официальная конференция посвященная самой популярной в мире CMS.</p>
<p><img src=\"https://ru.wordpress.org/files/2015/07/wordcamp-russia-2-1024x683.jpg\" alt=\"WordCamp Russia\" width=\"692\" height=\"462\" class=\"alignnone size-large wp-image-1662\" srcset=\"https://ru.wordpress.org/files/2015/07/wordcamp-russia-2-1024x683.jpg 1024w, https://ru.wordpress.org/files/2015/07/wordcamp-russia-2-300x200.jpg 300w, https://ru.wordpress.org/files/2015/07/wordcamp-russia-2.jpg 1200w\" sizes=\"(max-width: 692px) 100vw, 692px\" /></p>
<p>В этом году на WordCamp вы сможете послушать интересные доклады от ведущих специалистов по WordPress в России, познакомиться с единомышленниками и поделиться своими идеями. Доклады разделены на два потока для пользователей и разработчиков WordPress, и охватывают дизайн, маркетинг, программирование, безопасность, производительность и поисковую оптимизацию.</p>
<h2>Программа</h2>
<p>На WordCamp Russia 2015 вы узнаете:</p>
<ul>
<li>Как создавать эффективные лендинги с помощью WordPress</li>
<li>Что такое поведенческие факторы и как они измеряются</li>
<li>Как создавать многоязычные сайты на WordPress</li>
<li>Самые распространенные причины медленных сайтов на WordPress</li>
<li>Как взламываются сайты на WordPress (на практике)</li>
<li>Что такое фильтры и события в WordPress</li>
<li>Чего ожидать от REST API в WordPress и как с ним работать</li>
<li>Почему следует участвовать в разработке ядра WordPress</li>
<li><a href=\"https://russia.wordcamp.org/2015/schedule/\">и многое другое</a></li>
</ul>
<p>Стоимость билета – $20. Сюда входит участие в конференции, обед и напитки, футболка с символикой мероприятия, значки, наклейки, подарки от спонсоров и целый день хорошего настроения.</p>
<p>Подробности и регистрация <a href=\"https://russia.wordcamp.org/2015/\">на сайте конференции &rarr;</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"WordPress 4.2.1 на русском\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://ru.wordpress.org/news/2015/04/wordpress-4-2-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Apr 2015 16:54:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Релизы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1636\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:766:\"Доступен WordPress 4.2.1. Это критическое обновление безопасности для всех предыдущих версий, и мы настоятельно рекомендуем вам обновить все свои сайты как можно скорее. Несколько часов назад команде WordPress стало известно об уязвимости межсайтового скриптинга, которая позволяла авторам комментариев получить доступ к сайту. Уязвимость обнаружил Йоуко Пиннонен. WordPress 4.2.1 уже устанавливается в фоновом режиме на сайты, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Sergey Biryukov\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1558:\"<p>Доступен WordPress 4.2.1. Это <strong>критическое обновление безопасности</strong> для всех предыдущих версий, и мы настоятельно рекомендуем вам обновить все свои сайты как можно скорее.</p>
<p>Несколько часов назад команде WordPress стало известно об уязвимости межсайтового скриптинга, которая позволяла авторам комментариев получить доступ к сайту. Уязвимость обнаружил <a href=\"http://klikki.fi/\">Йоуко Пиннонен</a>.</p>
<p>WordPress 4.2.1 уже устанавливается в фоновом режиме на сайты, которые <a href=\"http://https://wordpress.org/plugins/background-update-tester/\">поддерживают</a> автоматические фоновые обновления.</p>
<p>Дополнительную информацию можно найти в <a href=\"https://codex.wordpress.org/Version_4.2.1\">заметке о релизе</a> или в <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=32311&amp;stop_rev=32300\">списке изменений</a>.</p>
<p><a href=\"https://ru.wordpress.org/releases/\">Скачайте версию 4.2.1</a> или перейдите в меню «Консоль» → «Обновления» и нажмите кнопку «Обновить сейчас».</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"Конференция WordCamp Russia 2014\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://ru.wordpress.org/news/2014/07/wordcamp-russia-2014/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 03 Jul 2014 09:37:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://ru.wordpress.org/?p=1588\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:356:\"Конференция WordCamp Russia 2014 пройдет 9 августа в Москве. На мероприятии вы сможете пообщаться с профессионалами в сфере WordPress, поделиться своим опытом и узнать что-то новое о самой популярной в мире CMS.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1919:\"<p>Конференция <a href=\"http://2014.russia.wordcamp.org/\">WordCamp Russia 2014</a> пройдет 9 августа в Москве. На мероприятии вы сможете пообщаться с профессионалами в сфере WordPress, поделиться своим опытом и узнать что-то новое о самой популярной в мире CMS.</p>
<p>В этом году на WordCamp Russia планируется два отдельных потока для пользователей и разработчиков. С докладами на конференции выступят специалисты WordPress из России и из-за рубежа, включая разработчиков ядра WordPress. Среди подтвержденных докладов:</p>
<ul>
<li>Основы поисковой оптимизации WordPress</li>
<li>WordPress под нагрузкой: масштабирование и отказоустойчивость</li>
<li>Сайт глазами контентера: какой должна быть идеальная &#171;админка&#187;</li>
<li>Как не сойти с ума при разработке крупных проектов на WordPress</li>
<li>WordPress под прицелом хакеров. Что нужно знать, и как избежать проблем.</li>
<li>Все что вы хотели знать о WP_Query</li>
<li>Моделирование контента в WordPress: сильно больше, чем &#171;просто блог&#187;</li>
<li>Малоизвестные функции в ядре WordPress</li>
<li>Профилирование кода в WordPress</li>
</ul>
<p>Подробности и регистрация <a href=\"http://2014.russia.wordcamp.org/\">на сайте конференции &rarr;</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"WordPress 3.9 «Смит»\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://ru.wordpress.org/news/2014/04/3-9-smith/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Apr 2014 19:56:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Релизы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://ru.wordpress.org/?p=1516\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:710:\"Русская версия WordPress 3.9 &#171;Смит&#187; доступна для скачивания. Если вы уже используете WordPress, то вы можете выполнить обновление через панель администрирования в разделе «Консоль» → «Обновления». Это займет всего несколько секунд! Медиа и редактор В новой версии WordPress мы обновили визуальный редактор, который стал еще быстрее и надежнее, а также более удобным на мобильных устройствах. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5339:\"<p>Русская версия WordPress 3.9 &#171;Смит&#187; доступна для скачивания. Если вы уже используете WordPress, то вы можете выполнить обновление через панель администрирования в разделе «Консоль» → «Обновления». Это займет всего несколько секунд!</p>
<h3>Медиа и редактор</h3>
<p><img src=\"//wordpress.org/news/files/2014/04/editor1-300x233.jpg\" alt=\"editor\" width=\"228\" height=\"177\" /><img src=\"//wordpress.org/news/files/2014/04/image1-300x233.jpg\" alt=\"image\" width=\"228\" height=\"178\" /><img src=\"//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg\" alt=\"dragdrop\" width=\"228\" height=\"178\" /></p>
<p>В новой версии WordPress мы обновили визуальный редактор, который стал еще быстрее и надежнее, а также более удобным на мобильных устройствах. Вы теперь можете вставлять текст из таких программ, как Microsoft Word, и редактор автоматически преобразует их в чистую разметку.</p>
<p>Редактировать изображения (повернуть, перевернуть, обрезать) в медиатеке стало еще быстрее и приятнее в новой версии, а изменять размер вставленных изображений вы теперь можете прямо в самом редакторе.</p>
<p>Загружать новые файлы в библиотеку файлов также стало намного легче &#8212; теперь их достаточно просто перетащить с вашего компьютера (например, с рабочего стола) прямо в редактор WordPress.</p>
<p>При вставке галерей в визуальный редактор версии 3.9 вы теперь увидите полноценное превью ваших изображений. Предварительный просмотр элементов в редакторе также доступен для аудио, видео и плей-листов.</p>
<h3>Аудио и видео</h3>
<p>В WordPress 3.9 улучшена встроенная поддержка аудио- и видеофайлов. Мы обновили медиаплеер, а также добавили возможность легко создавать плей-листы для аудио и видео:</p>
<p><img class=\"alignnone size-large wp-image-1534\" src=\"//ru.wordpress.org/files/2014/04/wordpress-audio-playlist1.png\" alt=\"wordpress-audio-playlist\" width=\"641\" height=\"254\" srcset=\"https://ru.wordpress.org/files/2014/04/wordpress-audio-playlist1.png 641w, https://ru.wordpress.org/files/2014/04/wordpress-audio-playlist1-300x118.png 300w\" sizes=\"(max-width: 641px) 100vw, 641px\" /></p>
<h3>Работа с виджетами</h3>
<p>Виджетами теперь легко управлять прямо из конфигуратора тем WordPress. Для запуска конфигуратора зайдите в раздел «Внешний вид» → «Настроить». Любые изменения в этом режиме вступят в силу только после сохранения, так что не бойтесь экспериментировать!</p>
<p><img class=\"alignnone size-full wp-image-1536\" src=\"//ru.wordpress.org/files/2014/04/wordpress-3-9-widgets-screen.png\" alt=\"wordpress-3-9-widgets-screen\" srcset=\"https://ru.wordpress.org/files/2014/04/wordpress-3-9-widgets-screen.png 700w, https://ru.wordpress.org/files/2014/04/wordpress-3-9-widgets-screen-300x120.png 300w\" sizes=\"(max-width: 700px) 100vw, 700px\" /></p>
<h3>Поиск и установка тем</h3>
<p>В версии 3.9 изменился интерфейс для поиска и установки тем из официального каталога WordPress.org. Он стал чище, приятнее и намного быстрее:</p>
<p><img class=\"alignnone size-large wp-image-1539\" src=\"//ru.wordpress.org/files/2014/04/wordpress-3-9-themes-install.png\" alt=\"wordpress-3-9-themes-install\" srcset=\"https://ru.wordpress.org/files/2014/04/wordpress-3-9-themes-install.png 700w, https://ru.wordpress.org/files/2014/04/wordpress-3-9-themes-install-300x113.png 300w\" sizes=\"(max-width: 700px) 100vw, 700px\" /></p>
<p>В новой версии также произошло большое количество внутренних изменений, которые сделали WordPress 3.9 еще быстрее и надежнее. В разработке новой версии WordPress приняло участие более 250 человек из разных стран мира. Мы надеемся, что вам понравится данное обновление.</p>
<p>Если у вас возникнут проблемы с новой версией, обратитесь на <a href=\"https://ru.forums.wordpress.org/\">форум поддержки</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"WordPress 3.8 «Паркер»\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://ru.wordpress.org/news/2013/12/parker/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 13 Dec 2013 16:07:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Релизы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://ru.wordpress.org/?p=1478\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:749:\"Новая версия WordPress 3.8 &#171;Паркер&#187;, названная в честь джазового музыканта Чарли Паркера, доступна для скачивания или обновления через вашу консоль WordPress. Мы надеемся, что вы посчитаете данный релиз самым привлекательным. Совершенно новый внешний вид WordPress получил совершенно новый облик. Новая версия 3.8 полностью изменяет внешний вид панели администрирования, включая новый крупный шрифт Open Sans, плоские [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3736:\"<p>Новая версия WordPress 3.8 &#171;Паркер&#187;, названная в честь джазового музыканта Чарли Паркера, доступна для скачивания или обновления через вашу консоль WordPress. Мы надеемся, что вы посчитаете данный релиз самым привлекательным.</p>
<p><span id=\"more-1478\"></span></p>
<h2>Совершенно новый внешний вид</h2>
<p><img alt=\"Новый дизайн WordPress 3.8\"  src=\"//i0.wp.com/i0.wp.com/wpdotorg.files.wordpress.com/2013/12/overview.jpg?resize=623%2C193\" /></p>
<p>WordPress получил совершенно новый облик. Новая версия 3.8 полностью изменяет внешний вид панели администрирования, включая новый крупный шрифт Open Sans, плоские векторные иконки и восемь различных цветовых схем.</p>
<p><img alt=\"Цветовые схемы WordPress 3.8\"  src=\"//i0.wp.com/i0.wp.com/wpdotorg.files.wordpress.com/2013/12/colors.jpg?w=420\" /></p>
<p>Любителям писать &#171;на ходу&#187; будет интересно знать, что панель администрирования теперь стала адаптивной. Она автоматически подстраивается под необходимую ширину вашего экрана и безупречно работает как с крупными экранами настольных компьютеров, так и с мелкими экранами мобильных устройств и планшетов.</p>
<h2>Новый подход к работе с темами</h2>
<p>В новой версии WordPress стало намного проще и удобнее работать с темами оформления. Мы полностью переделали интерфейс для вашего удобства, включая возможность быстрого поиска по названию, описанию или автору темы, а также возможность &#171;листать&#187; темы с помощью клавиатуры.</p>
<p><img alt=\"Работа с темами в WordPress 3.8\"  src=\"//i0.wp.com/i0.wp.com/wpdotorg.files.wordpress.com/2013/12/themes.jpg?resize=360%2C344\" /></p>
<h2>Журнальная тема Twenty Fourteen</h2>
<p>Twenty Fourteen стала новой стандартной темой в WordPress 3.8. Темный лаконичный дизайн, адаптивная верстка, поддержка ряда форматов записей, несколько разделов для ваших виджетов и совершенно новый модуль &#171;Избранное содержимое&#187;, с помощью которого можно выделить ваши самые яркие записи в виде сетки или слайдера на главной странице.</p>
<p><img  src=\"//i0.wp.com/i0.wp.com/wpdotorg.files.wordpress.com/2013/12/twentyfourteen.jpg?resize=692%2C275\" alt=\"Тема Twenty Fourteen\" /></p>
<p>Скачать официальную русскую версию WordPress 3.8 вы можете по <a href=\"https://ru.wordpress.org/wordpress-3.8-ru_RU.zip\">этой ссылке</a>. Если вы уже пользуетесь WordPress, выполнить обновление можно в вашей панели администрирования в разделе Консоль → Обновления.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 3.7 «Бейси»\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://ru.wordpress.org/news/2013/10/wordpress-3-7/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 25 Oct 2013 08:47:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:12:\"Релизы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:3:\"3.7\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://ru.wordpress.org/?p=1464\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:741:\"WordPress 3.7 (названный в честь джазового музыканта Каунта Бейси) доступен для скачивания на русском языке. Данный релиз нацелен на некоторые улучшения архитектуры ядра: Автоматические обновления: с версией 3.7 вам больше не нужно беспокоиться об обновлении на технические релизы и релизы безопасности &#8212; WordPress самостоятельно выполнит необходимые обновления и сообщит вам об этом по электронной почте. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Konstantin Kovshenin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2380:\"<p>WordPress 3.7 (названный в честь джазового музыканта Каунта Бейси) доступен для скачивания на русском языке. Данный релиз нацелен на некоторые улучшения архитектуры ядра:</p>
<ul>
<li><strong>Автоматические обновления</strong>: с версией 3.7 вам больше не нужно беспокоиться об обновлении на технические релизы и релизы безопасности &#8212; WordPress самостоятельно выполнит необходимые обновления и сообщит вам об этом по электронной почте.</li>
<li><strong>Надёжные пароли</strong>: с новой библиотекой для проверки надёжности паролей в WordPress, пользователи и администраторы вашего сайта будут в безопасности. Индикатор надёжности теперь проверяет не только длину пароля, но и его содержимое. Например 1234567890, password, qwerty и даже h3ll0w0r1d теперь помечаются как &#171;очень слабые пароли&#187;.</li>
<li><strong>Улучшенная поддержка языковых пакетов</strong>: с новой версией, WordPress будет запрашивать и обновлять языковые пакеты для ядра и стандартных тем автоматически.</li>
</ul>
<p>Разработчики смогут управлять автоматическими обновлениями с помощью ряда новых фильтров и событий, выполнять комплексные запросы с датами с помощью нового класса <code>WP_Date_Query</code> и многое другое. Полный список изменений (более 400) вы можете посмотреть в <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.7\">баг-трэкере</a>. В данном релизе приняло участие более 200 разработчиков.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:35:\"https://ru.wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sat, 24 Feb 2018 14:32:13 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Sat, 24 Feb 2018 14:23:07 GMT\";s:4:\"link\";s:61:\"<https://ru.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";}}s:5:\"build\";s:14:\"20130911010210\";}","no");
INSERT INTO `wp_options` VALUES("739","_transient_timeout_feed_mod_126d1ca39d75da07beec8b892738427b","1519525936","no");
INSERT INTO `wp_options` VALUES("740","_transient_feed_mod_126d1ca39d75da07beec8b892738427b","1519482736","no");
INSERT INTO `wp_options` VALUES("741","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1519525937","no");
INSERT INTO `wp_options` VALUES("742","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: WordCamp Orange County Plugin-A-Palooza First Place Prize is $3,000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78153\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"https://wptavern.com/wordcamp-orange-county-plugin-a-palooza-first-place-prize-is-3000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2009:\"<p><a href=\"https://2018.oc.wordcamp.org/\">WordCamp Orange County</a>, CA, 2018 will take place June 9-10. In addition to the regular WordCamp format of speakers sharing their knowledge, there is also a mini-event called Plugin-A-Palooza. This year marks the fourth contest where plugin authors will compete for one of three prizes.</p>
<ul>
<li>First Place – <strong>$3,000</strong> cash and 1 Sucuri Business (VIP) license</li>
<li>Second Place – <strong>$1,500</strong> cash and 1 Sucuri Business (VIP) license</li>
<li>Third Place – <strong>$500</strong> cash</li>
</ul>
<p>Teams will be judged live based on the following criteria:</p>
<ul>
<li>Originality</li>
<li>User Experience/User Interface</li>
<li>Code Quality</li>
<li>Presentation of the plugin on WordPress.org.</li>
</ul>
<p>Teams can have up to three participants, are required to build their own plugin, and upload it to the WordPress plugin directory by May 18th. Teams will present their plugins to the judges and audience on June 10th.</p>
<p>Previous winners and plugins include:</p>
<ul>
<li>2015 Devin Walker- <a href=\"https://wordpress.org/plugins/wp-rollback/\">WP Rollback</a></li>
<li>2016 Robert Gillmer &#8211; <a href=\"https://wordpress.org/plugins/wp-documentor/\">WP Documentor</a></li>
<li>2017 Natalie MacLees &#8211; <a href=\"https://wordpress.org/plugins/simple-event-listing/\">Simple Event Listing</a></li>
</ul>
<p>Bridget Willard, WordCamp Orange County organizer, says the event encourages innovation and personal development which are important parts of WordCamps. &#8220;The first plugin that won was WPRollback by WordImpress,&#8221; she said. &#8220;It&#8217;s widely used in the community now. We&#8217;d love to see other camps doing this.&#8221;</p>
<p>If you&#8217;re interested in participating in Plugin-A-Palooza at WordCamp Orange County this year, you&#8217;ll need to fill out this <a href=\"https://goo.gl/forms/CpDCsXQRqNI0cil23\">entry form</a>. The deadline for submissions is March 5th.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 23 Feb 2018 22:46:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"Dev Blog: WordCamp Incubator 2.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5577\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wordpress.org/news/2018/02/wordcamp-incubator-2-0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2449:\"<p><a href=\"https://central.wordcamp.org/\">WordCamps</a> are informal, community-organized events that are put together by a team of local WordPress users who have a passion for growing their communities. They are born out of active WordPress meetup groups that meet regularly and are able to host an annual WordCamp event. This has worked very well in many communities, with over 120 WordCamps being hosted around the world in 2017.<br /></p>

<p>Sometimes though, passionate and enthusiastic community members can’t pull together enough people in their community to make a WordCamp happen. To address this, we introduced <a href=\"https://wordpress.org/news/2016/02/experiment-wordcamp-incubator/\">the WordCamp Incubator program</a> in 2016.<br /></p>

<p>The goal of the incubator program is <strong>to help spread WordPress to underserved areas by providing more significant organizing support for their first WordCamp event.</strong> In 2016, members of <a href=\"https://make.wordpress.org/community/\">the global community team</a> worked with volunteers in three cities — Denpasar, Harare and Medellín — giving direct, hands-on assistance in making local WordCamps possible. All three of these WordCamp incubators <a href=\"https://make.wordpress.org/community/2017/06/30/wordcamp-incubator-report/\">were a great success</a>, so we&#x27;re bringing the incubator program back for 2018.<br /></p>

<p>Where should the next WordCamp incubators be? If you have always wanted a WordCamp in your city but haven’t been able to get a community started, this is a great opportunity. We will be taking applications for the next few weeks, then will get in touch with everyone who applied to discuss the possibilities. We will announce the chosen cities by the end of March.<br /></p>

<p><strong>To apply, </strong><a href=\"https://wordcampcentral.polldaddy.com/s/wordcamp-incubator-program-2018-city-application\"><strong>fill in the application</strong></a><strong> by March 15, 2018.</strong> You don’t need to have any specific information handy, it’s just a form to let us know you’re interested. You can apply to nominate your city even if you don’t want to be the main organizer, but for this to work well we will need local liaisons and volunteers, so please only nominate cities where you live or work so that we have at least one local connection to begin.<br /></p>

<p>We&#x27;re looking forward to hearing from you!<br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 21 Feb 2018 22:53:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"HeroPress: How To Build A Company With WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2465\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:120:\"https://heropress.com/essays/build-company-wordpress/#utm_source=rss&utm_medium=rss&utm_campaign=build-company-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:16946:\"<img width=\"960\" height=\"480\" src=\"https://heropress.com/wp-content/uploads/2018/02/022118-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: If you keep showing up, you\'d be surprised what happens.\" />.embed-container { position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; } .embed-container iframe, .embed-container object, .embed-container embed { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }
<div class=\"embed-container\"></div>
<p>&nbsp;</p>
<h4>Full text of the above video</h4>
<p>Hey, y&#8217;all! Thanks for inviting me to come share my story on HeroPress. I&#8217;m so excited to be able to talk a little bit to the HeroPress community.</p>
<p>So, and I&#8217;m doing a video blog or vlog because this is what I do; I&#8217;m a YouTube person. I create YouTube videos every single Wednesday for what I call WordPress Wednesday to help you improve your online marketing inside of the WordPress world. So I&#8217;m used to doing videos, and I asked if I could do my HeroPress story in this format; and they said go for it, so I&#8217;m excited to talk to you at least in a face-to-face scenario.</p>
<p>I&#8217;m going to  share a little bit of my story and tell you how WordPress basically became my avenue for becoming a millionaire in just five short years.</p>
<h3>The Beginning</h3>
<p>So in 1998, I created my very first ever HTML website. My dad was actually doing websites at the time, and I needed a website for my band because that&#8217;s what I wanted to be is a rockstar; so I learned how to build a website, kind of, under his training and a little bit of self-taught stuff and had a lot of fun doing it that way in 1998.</p>
<p>And then in 2005, I started hearing about WordPress; but in 2008, as I was freelancing around, a client asked me to build him a website. And they said, &#8220;hey, Kori, can you, can you build me a website, but we absolutely have to have it on WordPress?&#8221; I was like, sure, no problem; straight to Google, &#8220;how do you build a WordPress website&#8221;, you know. And over the weekend I pretty much taught myself how to build out a WordPress website, and I loved it.</p>
<p>My mind was absolutely blown when I saw the drag and drop options inside of menus to create dropdowns, and a form builder; I was just blown away. So those of you who have struggled in the HTML CSS world, you know the magic or the majesty, if you will even, of WordPress and those environments and how easy it makes it. So when I saw that, I really just thought, oh my goodness, this is a full-circle moment for me.</p>
<blockquote><p>I really want to use WordPress now from here on forward.</p></blockquote>
<p>So I reached back out to my dad and said, &#8220;hey, dad, you know, this is a tool that our customers, all of our clients, have been asking us for&#8221;. They&#8217;ve been wanting access to their websites, and we&#8217;ve not been able to give it to them because, in the past, they had to download Dreamweaver, you know, Photoshop and an FTP program; and that was just too much nerd code for them. So we wanted to be able to give them something like this, and WordPress definitely was that solution.</p>
<p>So he and I worked back and forth for a few years learning, really truly learning, WordPress; and then in 2012, we decided to launch together, my mom, my dad and I, decided to launch WebTegrity in San Antonio, Texas. And it was a very small concept initially; you know, we just me, literally, the three of us, and me and my folks. And then we hired on a subcontractor who is a great graphic designer here in town to try to help us with the creative side of things, and we started to grow our team.</p>
<h3>Going Big Time</h3>
<p>So how did we, in five years, build it up in such a way that we were able to sell it for a deal of a million dollars&#8217; worth of shares, which ultimately is a $20 million value deal? How did we do that? I&#8217;m going to give you a little bit of insight on how we were able to accomplish that in such a short time.</p>
<p>So the very first thing I want you to realize is we did this in a saturated industry in San Antonio, Texas. When I did a search for web developer or web design firms back in 2012, I had over 700 results of different either freelancers or agencies or ad agencies or some solution out there that was either in the general area, or in the nearby area, that provided that service. So how did we, in six years, end up becoming number six in the entire city? We ranked in the top 10; how did we do that?</p>
<blockquote><p>One of the very first things we did, was we niched ourselves; and, thankfully, WordPress was that solution.</p></blockquote>
<p>In 2012, there was not an agency directly in San Antonio that was trying to be the go-to place for WordPress; and we purposely started stepping up and saying we are WordPress only, WordPress only, WordPress only. So if you were looking for a different type of CMS solution, we were not the right fit for you. And very, very quickly, we also started teaching it in the city; so we would teach other agencies. We provided on-site training; we provided weekend workshops. All for a price tag, of course; but that was one of our revenue streams. And, again, it set us as the authority in the city for WordPress; so really important that you understand how to niche yourselves and not try to be all things to all people.</p>
<blockquote><p>The second thing we tried to do was really build a culture.</p></blockquote>
<p>And you can see, I don&#8217;t work around boring walls. Everything that I do has to have creative juices flowing around me, right. We just want to create a great culture, a great environment. So we had to hire the right people. So that&#8217;s my next tip to you is be very, very careful on who you allow into your culture of your business, who you hire on, and certainly who you bring on as a leader in your culture in your community. So one of the things that we did right away was realize that we can&#8217;t teach passion, so you gotta find people that have a passion to nerd out on stuff like this.</p>
<p>And you have to find people who have great integrity to just do their best at all times, and you have to find people who love to be creative and love to solve problems for clients, right, who aren&#8217;t just salespeople, right? So if you can find those things, you can teach nerd code all day long; so be sure to just find people with the right hearts to join your community and then train them up the right way, be sure that you just grow and grow and grow your culture in a healthy way, right.</p>
<blockquote><p>And another thing that we did, so this is another tip, was understand how to really build a revenue stream that was going to be sustainable.</p></blockquote>
<p>All right, so wrap your heads around this one because this one&#8217;s key. Very early on in our model as we were selling WordPress websites, part of my pitch was, oh, it&#8217;s just five grand and no more after that. It&#8217;s a one-time fee and you&#8217;re done. That&#8217;s a horrible business strategy. We learned very early on, inside of WordPress world, that you have rain or shine, right; so there&#8217;s a lot of clients coming or there are no clients.</p>
<p>You&#8217;re either slammed working from home even in the evening trying to catch up, or you&#8217;re out on the golf course wondering if you&#8217;re going to get a paycheck next week. It&#8217;s really rain or shine. So how do you create a sustainable model in your business, in your small agency, in your startup; how do you do that, so that when those slow seasons come, you can still pay your team members, you can still keep your lights on?</p>
<p>Well, we were sitting at a WordCamp; and Jason Cohen from WP Engine was keynoting; and one of the things he said right away is, if you don&#8217;t understand how to create a reoccurring revenue stream in your small agency, you will turn your sign to closed in the next year or two. And he was so right; and it was such a light bulb moment for me that I went back straightaway from that weekend WordCamp up in Austin and I started writing out, okay, how can we create a reoccurring revenue stream? What would that look like inside of our industry?</p>
<p>And, of course, it was support packages. We didn&#8217;t call them maintenance plans. We certainly didn&#8217;t use retainer, which can have a sense of a negative connotation, right, because of lawyers; sorry! But, still, we didn&#8217;t want to use those words because we&#8217;re already almost creating a, uh, I don&#8217;t think I want to sign up for that type of attitude.</p>
<p>What we did is we called it support, and very easily, clients were signing up saying, oh, goodness, yes, I need that ongoing support. So use that phrasing, create a model structure where it&#8217;s required, at least for the first 12 months out of the gate as they launch that you are charging them something even as small as $99 a month. And don&#8217;t shortchange yourself on that; put together a great package that you give them that type of value.</p>
<p>If you were to check out WebTegrity.com, you would see our support plans and what they consist of and the pricing. We&#8217;re very transparent with that. That&#8217;s the way our revenue stream almost doubled our sales in one year and allowed us to keep our lights on when June and July roll around and nobody cares about their websites because they&#8217;re on the beach.</p>
<blockquote><p>All right, reputation was another huge part of it.</p></blockquote>
<p>That&#8217;s one of the reasons why we named ourselves WebTegrity, but reputation, understanding that that every client that signs up, whether they&#8217;re a $5,000 website or a $50,000 website gets the same type of boutique-style, white glove, handholding relationship, right? Every single project that you launch, you want to produce the absolute, absolute best. You&#8217;re not shortchanging them; you&#8217;re not, you&#8217;re not wiring something that you hand off to the client and hope to God it doesn&#8217;t break. You really are trying to find the absolute best solution.</p>
<p>One of the things that also kept us in high standing with our reputation, of course, was offering that training because what we don&#8217;t want to do is keep the veil covered where nobody can see what we&#8217;re doing, right. We really want to be transparent and train our clients the nerd lingo, train the clients what SEO is and what expectations should be. Having that type of open communication really just started to build together a relationship with our clients that they trusted us; and we met their expectation, right. So be sure to hold strongly to your core values for your reputation. Be sure that you&#8217;re asking people to give you great reviews because that&#8217;ll make a difference.</p>
<blockquote><p>And the last thing I want to talk about is give back.</p></blockquote>
<p>So at one of the WordCamp US&#8217;s that I went to, Matt himself said, listen, if you&#8217;re making a living with WordPress, you really need to try to figure out how to give back 5% of your time, just 5% of your time a week. How can you do that to give back to the community? Can you start a meet-up group, teach a meetup group; can you facilitate a meetup group where maybe you&#8217;re just the organizer and you never have to speak because you&#8217;re not a fan of speaking?</p>
<p>Can you organize a WordCamp, volunteer at a WordCamp? Can you write a tutorial and tell people how to do things? Can you teach a workshop; can you make a video?</p>
<p>And, again, I had a light bulb moment. Of course, I can make videos. So my giveback to the WordPress community is my YouTube channel; every single Wednesday, I&#8217;m creating a video and putting it out there for free to the WordPress world of how to improve your online marketing. That&#8217;s made a huge impact not only, thankfully, inside the WordPress community, but also in my own business model.</p>
<p>I actually go into WordCamps around the US and people are like, hey, aren&#8217;t you that WordPress girl; don&#8217;t you do videos? It&#8217;s a really cool feeling to be able to give back to the community because I&#8217;ve made my living using WordPress.</p>
<h3>Understanding</h3>
<p>So ultimately how did I turn five years into a multi-million dollar buyout? Because we have just recently sold; how did we do that? Ultimately, it was understanding that you have to be able to grow something of value. So as soon as you start your business, you should also be thinking about your exit strategy, right, even in how you name your company.</p>
<p>If I were to name this Ashton Agency, do you think that I could&#8217;ve just walked away and handed the keys to somebody else named Johnson; it wouldn&#8217;t have worked. Think even about your name; will it stand alone? Can that become a brand that you can hand off and sell as a holistic entity?</p>
<p>You also want to think about that revenue stream, right, and watch those sales margins. Be sure that your margins are healthy. Don&#8217;t hire until it hurts, until it absolutely hurts. Be sure that you&#8217;re structuring your offerings in such a way that you&#8217;re actually recouping your value. What does that mean? Just understand business better; watch Shark Tank, read more tutorials like this, watch more videos.</p>
<p>Get a hold of the WordPress community, the core leaders, the speakers that travel around to all the WordCamps. Start following them on Twitter and trying to understand what it is that they&#8217;re training and teaching. There&#8217;s a lot of resources out there for you to gain some ideas from, but ultimately it was me stepping out in the San Antonio community because it was a larger firm here in San Antonio who purchased us.</p>
<p>So we just kept hammering on the fact that we were the go-to place here in San Antonio for WordPress. We kept training; we kept doing free opportunities, going out and speaking at different events; and people kept seeing us. We kept showing up, so you&#8217;d be surprised what happens. If you keep giving back and you keep showing up to places, you keep establishing yourself as the authority, you keep learning and training and growing your own skill set and growing your team, before you know it, it can happen for you.</p>
<p>I hope this has been helpful. If you have questions about some of this though, if you&#8217;re trying to grow up your startup, or if you&#8217;re trying to learn how to improve your revenue margins, I&#8217;m always open to a quick twitter conversation or send me an email. I&#8217;d love to connect with you.</p>
<p>Thanks again for the opportunity to share this on HeroPress.</p>
<p>Bye, y&#8217;all; catch me over on YouTube. Bye!</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: How To Build A Company With WordPress\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=How%20To%20Build%20A%20Company%20With%20WordPress&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fbuild-company-wordpress%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: How To Build A Company With WordPress\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fbuild-company-wordpress%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fbuild-company-wordpress%2F&title=How+To+Build+A+Company+With+WordPress\" rel=\"nofollow\" target=\"_blank\" title=\"Share: How To Build A Company With WordPress\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/build-company-wordpress/&media=https://heropress.com/wp-content/uploads/2018/02/022118-150x150.jpg&description=How To Build A Company With WordPress\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: How To Build A Company With WordPress\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/build-company-wordpress/\" title=\"How To Build A Company With WordPress\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/build-company-wordpress/\">How To Build A Company With WordPress</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 21 Feb 2018 14:00:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Kori Ashton\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Matt: Commuting Time Saved\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47970\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"https://ma.tt/2018/02/commuting-time-saved/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:344:\"<p>On <a href=\"https://automattic.com/\">Automattic&#x27;s</a> internal <a href=\"https://buddypress.org/\">BuddyPress</a>-powered company directory, we allow people to fill out a field saying how far their previous daily commute was. 509 people have filled that out so far, and they are saving 12,324 kilometers of travel every work day. Wow!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 19 Feb 2018 18:14:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Akismet: Version 4.0.3 of the Akismet WordPress Plugin Is Now Available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://blog.akismet.com/?p=1985\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://blog.akismet.com/2018/02/19/version-4-0-3-of-the-akismet-wordpress-plugin-is-now-available/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:867:\"<p>Version 4.0.3 of <a href=\"http://wordpress.org/plugins/akismet/\">the Akismet plugin for WordPress</a> is now available.</p>
<p>4.0.3 contains a few helpful changes:</p>
<ul>
<li>Adds a new scheduled task to clear out old Akismet entries in the <code>wp_commentmeta</code> table that no longer have corresponding comments in <code>wp_comments</code>.  This should help reduce Akismet&#8217;s database usage for some users.</li>
<li>Adds a new <code>akismet_batch_delete_count</code> action so developers can optionally take action when Akismet comment data is cleaned up.</li>
</ul>
<p>To upgrade, visit the Updates page of your WordPress dashboard and follow the instructions. If you need to download the plugin zip file directly, links to all versions are available in <a href=\"http://wordpress.org/plugins/akismet/\">the WordPress plugins directory</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 19 Feb 2018 15:58:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Josh Smith\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"Mark Jaquith: Handling old WordPress and PHP versions in your plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://markjaquith.wordpress.com/?p=5544\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"https://markjaquith.wordpress.com/2018/02/19/handling-old-wordpress-and-php-versions-in-your-plugin/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3563:\"<p>New versions of WordPress are released about three times a year, and WordPress itself supports PHP versions all the way back to 5.2.4.</p>
<p>What does this mean for you as a plugin developer?</p>
<p>Honestly, many plugin developers spend too much time supporting old versions of WordPress and <strong>really</strong> old versions of PHP.</p>
<p>It doesn&#8217;t have to be this way. You don&#8217;t need to support every version of WordPress, and you don&#8217;t have to support every version of PHP. Feel free to do this for seemingly selfish reasons. Supporting old versions is hard. You have to &#8220;unlearn&#8221; new WordPress and PHP features and use their older equivalents, or even have code branches that do version/feature checks. It increases your development and testing time. It increases your support burden.</p>
<p>Economics might force your hand here&#8230; a bit. You can&#8217;t very well, even in 2018, require that everyone be running PHP 7.1 and the latest version of WordPress. But consider the following:</p>
<p>97% of WordPress installs are running PHP 5.3 or higher. This gives you namespaces, late static binding, closures, Nowdoc, <strong>__DIR</strong><strong>__</strong>, and more.</p>
<p>88% of WordPress installs are running PHP 5.4 or higher. This gives you short array syntax, traits, function-array dereferencing, guaranteed <strong>&lt;?=</strong> echo syntax availability, <strong>$this</strong> access in closures, and more.</p>
<p>You get even more things with PHP 5.5 and 5.6 (64% of installs are running 5.6 or higher), but a lot of the syntactic goodness came in 5.3 and 5.4, with very few people running versions less than 5.4. So stop typing <strong>array()</strong>, stop writing named function handlers for simple <strong>array_map()</strong> uses, and start using namespaces to organize and simplify your code.</p>
<p>Okay, so&#8230; how?</p>
<p>I recommend that your main plugin file just be a simple bootstrapper, where you define your autoloader, do a few checks, and then call a method that initializes your plugin code. I also recommend that this main plugin file be PHP 5.2 compatible. This should be easy to do (just be careful not to use <strong>__DIR__</strong>).</p>
<p>In this file, you should check the minimum PHP and WordPress versions that you are going to support. And if the minimums are not reached, have the plugin:</p>
<ol>
<li>Not initialize (you don&#8217;t want syntax errors).</li>
<li>Display an admin notice saying which minimum version was not met.</li>
<li>Deactivate itself (optional).</li>
</ol>
<p>Do not <strong>die()</strong> or <strong>wp_die()</strong>. That&#8217;s &#8220;rude&#8221;, and a bad user experience. Your goal here is for them to update WordPress or ask their host to move them off an ancient version of PHP, so be kind.</p>
<p>Here is what I use:</p>
<p><a href=\"https://gist.github.com/markjaquith/a08623974b37c2cf0207ee2b120b54da\">View code on GitHub</a></p>
<p></p>
<p><a href=\"https://twitter.com/markjaquith/status/965605448408813569\">Reach out on Twitter</a> and let me know what methods you use to manage PHP and WordPress versions in your plugin!</p>
<hr />
<p><b>Do you need <a href=\"https://coveredwebservices.com/\">WordPress services?</a></b></p>
<p>Mark runs <a href=\"https://coveredwebservices.com/\">Covered Web Services</a> which specializes in custom WordPress solutions with focuses on security, speed optimization, plugin development and customization, and complex migrations.</p>
<p>Please reach out to start a conversation!</p>
[contact-form]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 19 Feb 2018 15:14:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mark Jaquith\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"Post Status: How WebDevStudios is serving different market segments — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=43724\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"https://poststatus.com/webdevstudios-serving-different-market-segments-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2637:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p>In this episode, Lisa Sabin-Wilson shares about the entangled history of WebDevStudios and eWebscapes and how she and team are targeting every level of the market. WebDevStudios focuses heavily on the upper and enterprise market segments, providing a high degree of attention and support to those clients.</p>
<p>Sometime in 2017 Lisa did the math on all the lower-end projects that they were referring away and realized that WDS had a prime opportunity to re-introduce her former web studio, eWebscapes, as a way to serve these smaller-scope projects. This rebirth, so to speak, has positioned them to better target local communities, provide staff with more variety of work, and bring simplified processes alongside those they use for larger projects.</p>
<p></p>
<h3></h3>
<h3>Key take-aways</h3>
<ul>
<li>Lisa observed a market opportunity and did the math first</li>
<li>Relaunching started with a solid content strategy</li>
<li>Simplified processes for managing a project</li>
<li>Utilized talent already on staff</li>
<li>Lots of opportunity to target local communities</li>
<li>Evaluating the success of this strategy after 6 months</li>
</ul>
<h3>Links</h3>
<ul>
<li><a href=\"https://webdevstudios.com/\">WebDevStudios</a></li>
<li><a href=\"https://ewebscapes.com/\">eWebscapes</a></li>
<li><a href=\"https://jenniferbourn.com/profitable-project-plan/\">Profitable Project Plan</a></li>
<li><a href=\"https://twitter.com/@lisasabinwilson\">Lisa Sabin-Wilson on Twitter</a></li>
</ul>
<p><a href=\"https://webdevstudios.com/about/\"><em>Photo Credit</em></a></p>
<h3>Sponsor: Prospress</h3>
<p><a href=\"https://prospress.com/\">Prospress</a> makes the WooCommerce Subscriptions plugin, that enables you to turn your online business into a recurring revenue business. Whether you want to ship a box or setup digital subscriptions like I have on Post Status, Prospress has you covered. Check out <a href=\"https://prospress.com/\">Prospress.com</a> for more, and thanks to Prospress for being a Post Status partner.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 16 Feb 2018 22:38:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Matt: No Office Workstyle\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47949\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://ma.tt/2018/02/no-office-workstyle/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3938:\"<p>Reed Albergotti has a great article titled <a href=\"https://www.theinformation.com/articles/latest-amenity-for-startups-no-office\">Latest Amenity for Startups: No Office</a>. You can put in your email to read I believe but it&#x27;s behind a paywall otherwise. <a href=\"https://www.theinformation.com/\">The Information</a> is a pretty excellent site that alongside (former Automattician) <a href=\"https://stratechery.com/\">Ben Thompson&#x27;s Stratechery</a> I recommend subscribing to. Here are some quotes from the parts of the article that quote me or talk about <a href=\"https://automattic.com/\">Automattic</a>:</p>

<blockquote class=\"wp-block-quote\">
    <p>So it’s no coincidence that one of the first companies to operate with a distributed workforce has roots in the open source movement. Automattic, the company behind open source software tools like WordPress, was founded in 2005 and has always allowed its employees to work from anywhere. The company’s 680 employees are based in 63 countries and speak 79 languages. Last year, it closed its San Francisco office, a converted warehouse — because so few employees were using it. It still has a few coworking spaces scattered around the globe.</p>
    <p>Matt Mullenweg, Automattic’s founder and CEO, said that when the company first started, its employees communicated via IRC, an early form of instant messaging. Now it uses a whole host of software that’s tailor-made for remote work, and as the technology evolves, Automattic adopts what they need.</p>
    <p>Mr. Mullenweg said Automattic only started having regular meetings, for instance, after it started using Zoom, a video conferencing tool that works even on slow internet connections.</p>
    <p>He’s become a proponent of office-less companies and shares what he’s learned with other founders who are attempting it. Mr. Mullenweg said he believes the distributed approach has led to employees who are even more loyal to the company and that his employees especially appreciate that they don’t need to spend a chunk of their day on a commute.</p>
    <p>“Our retention is off the charts,” he said.</p>
</blockquote>

<p>And:</p>

<blockquote class=\"wp-block-quote\">
    <p>“Where it goes wrong is if they don’t have a strong network outside of work—they can become isolated and fall into bad habits,” Mr. Mullenweg said. He said he encourages employees to join groups, play sports and have friends outside of work. That kind of thing wouldn’t be a risk at big tech companies, where employees are encouraged to socialize and spend a lot of time with colleagues.</p>
    <p>But for those who ask him about the negatives, Mr. Mullenweg offers anecdotal proof of a workaround.</p>
    <p>For example, he said he has 14 employees in Seattle who wanted to beat the isolation by meeting up for work once a week. So they found a local bar that didn’t open until 5 p.m., pooled together the $250 per month co-working stipends that Automattic provides and convinced the bar’s owner to let them rent out the place every Friday.</p>
</blockquote>

<p>They didn&#x27;t need to pool all their co-working allowance to get the bar, I recall it was pretty cheap! Finally:</p>

<blockquote class=\"wp-block-quote\">
    <p>For Automattic, flying 700 employees to places like Whistler, British Columbia or Orlando, Florida, has turned into a seven-figure expense.</p>
    <p>“I used to joke that we save it on office space and blow it on travel. But the reality is that in-person is really important. That’s a worthwhile investment,” Mr. Mullenweg said.It might take a while, but some people are convinced that a distributed workforce is the way of the future.</p>
    <p>“Facebook is never going to work like this. Google is never going to work like this. But whatever replaces them will look more like a distributed company than a centralized one,” Mr. Mullenweg said.</p>
</blockquote>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 16 Feb 2018 18:44:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Matt: Kinsey Joins Automattic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47931\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://ma.tt/2018/02/kinsey-joins-automattic/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:229:\"<p>Kinsey Wilson is joining Automattic to run WordPress.com. <a href=\"https://www.poynter.org/news/one-time-npr-and-nyt-digital-chief-new-adventure-wordpress\">Poynter covers the news and has a great interview with Kinsey.</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Feb 2018 18:56:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"WPTavern: WPWeekly Episode 305 – 10up, JavaScript for WordPress Conference, and Jetpack 5.8\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=78136&preview=true&preview_id=78136\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"https://wptavern.com/wpweekly-episode-305-10up-javascript-for-wordpress-conference-and-jetpack-5-8\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1599:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I discuss the news of the week. We also chat about the Winter Olympics, crypto mining in order to access content on the web, and the joys of taking care of a puppy. Last but not least, we talk about Elasticsearch in Jetpack 5.8 and whether or not improving WordPress&#8217; native search functionality through a service is the way to go.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/jetpack-5-8-adds-lazy-loading-for-images-module\">Jetpack 5.8 Adds Lazy Loading for Images Module</a><br />
<a href=\"https://wptavern.com/free-virtual-wordpress-for-javascript-conference-june-29th\">Free Virtual WordPress for JavaScript Conference June 29th</a><br />
<a href=\"https://wptavern.com/10up-turns-seven\">10up Turns Seven</a><br />
<a href=\"https://make.wordpress.org/plugins/2018/02/13/not-updated-in-warning/\">“Not Updated In …” Warning</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, February 21st 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #305:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Feb 2018 02:14:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"WPTavern: 10up Turns Seven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"https://wptavern.com/10up-turns-seven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2986:\"<p><a href=\"https://10up.com/\">10up</a>, a web development agency founded by Jake Goldman in 2011, has turned seven years old. In a <a href=\"https://10up.com/blog/2018/10up-seven-year-anniversary/\">blog post celebrating the occasion</a>, Goldman reviews the previous year and highlights some notable events for the company.</p>
<p>&#8220;We welcomed more than 30 new clients to our portfolio in another record sales year,&#8221; Goldman said. &#8220;We launched new websites along with web and mobile apps for major brands across verticals as diverse as finance, healthcare, academia, high-tech, big media, consumer packaged goods, food and beverage, and fitness… to name a few.&#8221;</p>
<p>He also highlighted the company&#8217;s commitment to open source and giving back to WordPress. Throughout the past year, the company has released a number of WordPress plugins and developer tools including, <a href=\"https://10up.com/blog/2017/distributor-plugin/\">Distributor</a>, <a href=\"https://10up.com/blog/2017/wp-snapshots-share-wordpress-setup/\">WP Snapshots</a>, <a href=\"https://10up.com/blog/2017/wp-docker/\">WP Local Docker</a>, <a href=\"https://10up.com/blog/2018/improving-wordpress-transients/\">Async Transients</a>, and more.</p>
<p>Goldman describes three trends he&#8217;s noticed in the past few years.</p>
<ol>
<li>Integrations with innovation happening in other projects and platforms has become increasingly important as the web matures. You see it in React.js and Vue.js emerging as popular front end standards, in the rise of Elasticsearch and NoSQL platforms, with two factor authentication and Google single sign on, with the rise of modern Asset Management Systems.</li>
<li>For publishers, it’s increasingly becoming about distribution to multiple platforms, more so than<em> just</em> building a website. Google AMP, Facebook Articles, Apple News, Alexa, YouTube channels to name a few.</li>
<li>If you need any more evidence of WordPress dominance, look no further than how highly in demand top-tier engineering talent is. It’s probably &#8211; literally &#8211; around a factor of 1.5x &#8211; 2x what great engineers were earning 3-4 years ago.</li>
</ol>
<p>With seven years of experience under his belt, Goldman offers the following advice for those who are in their first or second year of running an agency or in a leadership position.</p>
<ol>
<li> Don’t be quite so hard on yourself &#8211; when you run a business &#8211; when you’re a lease &#8211; there will always be highs and lows &#8211; don’t dwell on the lows.</li>
<li>Put more emphasis on building systems, routines, and check-ins that offer a better pulse on the collective and individual fulfillment, engagement, and health of the team, rather than relying on transparent upwards communication.</li>
</ol>
<p>Congrats to 10up on seven years in business. To learn more about the company and employment opportunities, visit their <a href=\"https://10up.com/\">official site</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 14 Feb 2018 19:16:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"HeroPress: My WordPress Anniversaries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2452\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:126:\"https://heropress.com/essays/my-wordpress-anniversaries/#utm_source=rss&utm_medium=rss&utm_campaign=my-wordpress-anniversaries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:13243:\"<img width=\"960\" height=\"480\" src=\"https://heropress.com/wp-content/uploads/2018/02/021418-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: I feel that I am responsible to be on stage for all the women who haven’t found the courage yet to share their stories.\" /><p>I never remember dates. I know the birthday of more or less five people. I insist on saying that my son was born on May 11. Incorrect, I was born on May 11, he on May 17. But for some reason, my WordPress dates are permanently etched into my brain. I think it’s because meeting the global WordPress community and helping restart the Italian community are very meaningful moments in my adult life. Please join me in a walk down memory lane <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /></p>
<h3>May 15, 2015</h3>
<p>I started building websites with WordPress in 2010: my first website was my own blog, whose only purpose was to publish photos of my son so all the grandparents could enjoy seeing him grow. I enjoyed tinkering around with it, and to my surprise someone wrote asking me to build something similar for them. And they wanted to pay me for it!</p>
<p>For a few years I worked as an administrative manager during the day and as a web designer at night until I decided to make the jump and become a freelancer.</p>
<p>I never thought about contributing to WordPress because I wasn’t a back end developer and I didn’t think the project needed people that were not code wizards. Heck, I didn’t even know how WordPress was made or how open source worked exactly!</p>
<blockquote><p>And then I went to a Freelancers conference in Italy and on May 15 I gave my first talk ever.</p></blockquote>
<p>Up until that moment I taught small classes, but I never talked in front of more than ten people. I was terrified: in the audience there were more than a hundred people. Some of my friends, but also a lot of seasoned professionals that I respected and admired, and here I was talking about how they should and shouldn’t build a website. I was so nervous, when I grabbed the mic I did such a wide gesture with my arms that the bracelet I was wearing flew through the air to the other side of the room.</p>
<p>After my talk a guy came to compliment my talk, and I realised that he was one of those people that I respected and admired from afar: <a href=\"https://twitter.com/lucasartoni\">Luca Sartoni</a>, an Automattician whose blog I have been following for a while.</p>
<p>For the three days of the event we kept chatting about websites, WordPress, entrepreneurship, open source until he convinced me to start a WordPress meetup in my hometown of Torino, Italy. He put me in contact with other people that he knew wanted to do something similar and in less than a month from that conversation we started a meetup. The group now has more than one thousand members, and in March we will celebrate thirty events.</p>
<h3>November 7, 2015</h3>
<p>Luca didn’t stop his proselytism in Torino <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /> That same year, WordCamp Europe was held in Seville and at the Polyglots table a revolution was started. A small group of Italians, used to travelling abroad to attend WordCamps, met there and decided that it was time to organise the Italian community.</p>
<p>The first step was to revive the blog on the Italian WordPress website: it was dormant for seven years and the first thing we did was publish the dates of meetups that were slowly but surely appearing in the whole country. At the beginning of 2015 there were two meetups in Italy, by August there were eight and their number kept growing.</p>
<p>Now, if you have met Italians, you know we talk a lot. The two Francescos from Apulia, <a href=\"https://twitter.com/franzvitulli\">Franz Vitulli</a> and <a href=\"https://twitter.com/fra83\">Francesco Di Candia</a>, took the second initiative that was crucial to bringing us together: they opened a Slack workspace for the Italians, modeled after the UK workspace. For the whole summer we chatted every single day: about WordPress, about how to grow and manage the community that was forming in front of our eyes, how to communicate, how to contribute.</p>
<p>And then chatting wasn’t enough, we wanted to meet in person. We wanted to put a face and a voice to the avatars. With the help of <a href=\"https://twitter.com/rosso\">Sara Rosso</a> and <a href=\"https://twitter.com/miss_jwo\">Jenny Wong</a> we carried out a bizarre plan, almost unheard of: a <a href=\"https://wordpress.tv/2017/12/10/francesca-marano-standalone-contributor-days-help-make-wordpress-with-your-community/\">stand alone WordPress Contributor Day</a>. We would meet in Milano for a day to get to know each other and to learn how to Contribute to WordPress.</p>
<blockquote><p>I like to think that November 7 2015 is the day we became a community: we were not an abstract idea anymore, we were people, meeting in person to make WordPress in Italy.</p></blockquote>
<p>&nbsp;</p>
<h3>April 10, 2016</h3>
<p>The next few months went by in a blur of activities: the meetup organisers in Torino applied to host the first WordCamp in Italy in three years and I lead the organising team, I applied to attend the Community Summit in Philadelphia and I got accepted, I attended the first WordCamp US, my first WordCamp, and volunteered at it. I met a lot of people that helped me become more active and more focused: as a new contributor it’s easy to get overwhelmed by the abundance of amazing projects and tasks you can be part of, but it’s important to keep your focus to be more effective.</p>
<blockquote><p>After meeting people from all over the world and sharing our experiences I realised the story of the Italian community could be inspiring for other communities and it was worth telling it to a wider audience, so I got completely out of my comfort zone and submitted a talk to WordCamp London.</p></blockquote>
<p>On April 10th 2016 I gave <a href=\"https://wordpress.tv/2016/05/30/francesca-marano-rebirth-italian-community/\">my first talk at a WordCamp</a> and my first talk in English. I think I didn’t sleep for days before and after the event. It was nerve wracking, but I did it without throwing any bracelet in the air this time.</p>
<a href=\"https://heropress.com/wp-content/uploads/2018/02/WCEU2016.jpg\"><img class=\"wp-image-2457 size-large\" src=\"https://heropress.com/wp-content/uploads/2018/02/WCEU2016-1024x684.jpg\" alt=\"\" width=\"960\" height=\"641\" /></a>I gave the same talk at WordCamp Europe in 2016 and realised the story was relatable to many communities. Photographer unknown, sorry <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f641.png\" alt=\"🙁\" class=\"wp-smiley\" />
<h3>September 17, 2017</h3>
<p>Over the following year I kept contributing to WordPress, mostly in the Community team. I participated in the Polyglots activities for a while but then I had to pick and focus my attention. The more I interacted with people from all over the world as a hobby, the more I wanted that to become my job. Although my business as a web designer in Italy was doing good, I felt I wanted to be able to reach more people and find a way to be more involved with the community.<br />
So I started looking for a job. I was hesitant at first: all the insecurities I had about myself came back to haunt me. The voice in my head was telling me: you are too old, you don’t have enough technical expertise, you have been contributing for a very short time, English is not your native language, you are a single mom from Italy for crying out loud, who would want to employ you?</p>
<blockquote><p>Well, it turns out that if you actually look for a job instead of just telling yourself that you really would like a job, chances are you might get one.</p></blockquote>
<p>Last September I started a new chapter in my career as the <a href=\"https://www.siteground.com/blog/francesca-marano/\">WordPress Community Manager</a> at SiteGround and I couldn’t be happier.</p>
<p>The past 33 months have completely changed my life, personally and professionally: along the way I learned a number of lessons that I know will stay with me forever.</p>
<h3>Step Up</h3>
<p>If you want to achieve something, start today. Just start. Start a meetup, leave a comment to encourage someone else, volunteer to take notes of a meeting, participate in the discussion, bring your own ideas to the table. Be a fire starter, for yourself and for the people around you.</p>
<h3>Step Back</h3>
<p>None of the above is about you: the community is bigger than you, you are here to build a path for the future. Once you started something, don’t become too attached, let it go and let other people step up and shine. Mentor them, if they ask and if you can.</p>
<h3>If you want to go faster go alone, if you want to go further go together</h3>
<p>I am not a huge fan of motivational quotes, but this one is very dear to my heart and it’s one I have to remind myself quite often. I am a perfectionist and a quick learner: this is ok when you start your own business (and it’s ok only at the beginning, but this is a topic for another article!), but when you are part of a team, you are part of something bigger. It might move slower, but its impact is immensely more powerful than anything you’ll be able to achieve on your own.</p>
<h3>Representation matters</h3>
<p>I dislike speaking in public. When I say this people tend to laugh it off because I am good on stage. It doesn’t mean that I like it. I am much more at ease when I am behind the scenes, making things happen.</p>
<p><img class=\"aligncenter wp-image-2454 size-full\" src=\"https://heropress.com/wp-content/uploads/2018/02/slack-imgs.jpg\" alt=\"Four women seated on a low wall at a WordPress meetup.\" width=\"600\" height=\"400\" /></p>
<blockquote><p>But representation matters: I feel that I am responsible to be on stage for all the women who haven’t found the courage yet to share their stories.</p></blockquote>
<p>I am responsible for the young ones, so they can see that it’s possible to create a life when you can be both a good, albeit a bit absent mom, and a kick ass professional. I am responsible for the older ones, so they can see that we are represented, that this industry accepts us and recognizes our contributions. I am responsible to show my eleven year old son that women can do whatever they set out to do.</p>
<h3>Make it better, give it back</h3>
<p>I wish I came up with this, because it’s an incredibly powerful sentence. <a href=\"https://heropress.com/essays/make-better-give-back/\">John did</a> and I am grateful every day that I get to share my life with him and his wisdom.</p>
<p>Contributing to open source can be very frustrating: things go slow, sometimes things don’t go at all (there are numerous tickets in the WordPress bug tracker that are five or more years old), sometimes you might disagree with that will be decided, sometimes you might work alongside people that you dislike.</p>
<p>When this happens, remind yourself that you are working on a brilliant piece of software that is helping the lives and the businesses of millions of people.</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: My WordPress Anniversaries\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=My%20WordPress%20Anniversaries&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fmy-wordpress-anniversaries%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: My WordPress Anniversaries\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fmy-wordpress-anniversaries%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fmy-wordpress-anniversaries%2F&title=My+WordPress+Anniversaries\" rel=\"nofollow\" target=\"_blank\" title=\"Share: My WordPress Anniversaries\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/my-wordpress-anniversaries/&media=https://heropress.com/wp-content/uploads/2018/02/021418-150x150.jpg&description=My WordPress Anniversaries\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: My WordPress Anniversaries\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/my-wordpress-anniversaries/\" title=\"My WordPress Anniversaries\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/my-wordpress-anniversaries/\">My WordPress Anniversaries</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 14 Feb 2018 07:00:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Francesca Marano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: Free Virtual WordPress for JavaScript Conference June 29th\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78116\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"https://wptavern.com/free-virtual-wordpress-for-javascript-conference-june-29th\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1714:\"<p>Zac Gordon, who <a href=\"https://wptavern.com/zac-gordon-launches-gutenberg-development-course-includes-more-than-30-videos\">launched his Gutenberg development course</a> earlier this year, is organizing a virtual conference called <a href=\"https://javascriptforwp.com/conference/\">JavaScript for WordPress.</a> The conference will take place June 29th and is free to watch.</p>
<p>&#8220;Making the event free and online was really important for me so we could have as few barriers to entry for folks wanting to learn,&#8221; Gordon said. &#8220;I have a feeling a lot of folks who can&#8217;t tune live will still appreciate having all the talks available on YouTube for free.&#8221;</p>
<p>So far, 15 speakers have been confirmed with more to be announced soon. The speakers include WordPress core developers, theme and plugin developers, agency owners, and educators. Some of the talks will be from designers allowing user experience and usability to be part of the conversation.</p>
<p>Gordon says he&#8217;s been wanting to an in-person event for a while but considering the challenges involved, a virtual conference was the next best thing.</p>
<p>&#8220;I used to run in-person workshops in the Washington DC area, which I miss, and have wanted to do an event for a while,&#8221; he said. &#8220;But doing in-person events is so difficult, so the online format seemed like the best option to go with. I got some good advice from Human Made and WP Campus, who both have experience doing online events, so hopefully everything will go smooth.&#8221;</p>
<p>To reserve a seat and receive updates, visit the <a href=\"https://javascriptforwp.com/conference/\">JavaScript for WordPress conference site</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 13 Feb 2018 01:30:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"Mark Jaquith: Updating plugins using Git and WP-CLI\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://markjaquith.wordpress.com/?p=5552\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"https://markjaquith.wordpress.com/2018/02/12/updating-plugins-using-git-and-wp-cli/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4046:\"<p>Now that you know <a href=\"https://markjaquith.wordpress.com/2018/01/30/simple-wordpress-deploys-using-git/\">how I deploy WordPress sites</a> and <a href=\"https://markjaquith.wordpress.com/2018/02/05/tips-for-configuring-wordpress-environments/\">how I configure WordPress environments</a>, what about the maintenance of keeping a WordPress site&#8217;s plugins up-to-date?</p>
<p>Since I&#8217;m using Git, I cannot use WordPress built-in plugin updater on the live site (and I wouldn&#8217;t want to — if a plugin update goes wrong, my live site could be in trouble!)</p>
<p>The simple way to update all your plugins from a staging or local development site is to use WP-CLI:</p>
<pre class=\"brush: bash; title: ; notranslate\">wp plugin update-all
git commit -am \'update all plugins\' wp-content/plugins</pre>
<p>That works. I used to do that.</p>
<p>I don&#8217;t do that anymore.</p>
<p>Why? <strong>Granularity</strong>.</p>
<p>One of the benefits of using version control like Git is that when things go wrong, you can pinpoint when they went wrong, and identify what code caused the issue.</p>
<p>Git has a great tool called <strong>bisect</strong> that takes a known good state in the past and a current broken state, and then jumps around between revisions, efficiently, asking you to report whether that revision is <strong>good</strong> or <strong>bad</strong>. Then it tells you what revision broke your site.</p>
<p>If you lump all your plugin updates into one commit, you won&#8217;t get that granularity. You&#8217;ll likely get the <strong>git bisect</strong> result of &#8220;great&#8230; one of EIGHTEEN PLUGINS I updated was the issue&#8221;. That doesn&#8217;t help.</p>
<p>Here&#8217;s how you do it with granularity:</p>
<pre class=\"brush: bash; title: ; notranslate\">for plugin in $(wp plugin list --update=available --field=name);
do
    echo \"wp plugin update $plugin\" &amp;&amp;
    echo \"git add -A wp-content/plugins/$plugin\" &amp;&amp;
    echo \"git commit -m \'update $plugin plugin\'\";
done;</pre>
<p>This code loops through plugins with updates available, updates each one, and commits it with a message that references the plugin being updated. Great! Now <strong>git bisect</strong> will be able to tell you <strong>which</strong> plugin update broke your site.</p>
<p>And what if you can only run WP-CLI commands from within a VM, and Git commands from your local machine? For instance, if you&#8217;re using my favorite tool, <a href=\"https://local.getflywheel.com/\">Local by Flywheel</a>, you have to SSH into the site&#8217;s container to issue WP-CLI commands, but from within that container, you might not have Git configured like it is on your host machine.</p>
<p>So what you can do is break the process into two steps.</p>
<p>On the VM, run this:</p>
<pre class=\"brush: bash; title: ; notranslate\">wp plugin list --update=available --field=name &gt; plugins.txt
wp plugin update-all</pre>
<p>That grabs a list of plugins with updates and writes them to a file <strong>plugins.txt</strong>, and then updates all the plugins.</p>
<p>And then on your local machine, run this:</p>
<pre class=\"brush: bash; title: ; notranslate\">while read plugin;
do
    echo \"git add -A wp-content/plugins/$plugin\" &amp;&amp;
    echo \"git commit -m \'update $plugin plugin\'\";
done; &lt; plugins.txt</pre>
<p>That slurps in that list of updated plugins and does a distinct <strong>git add</strong> and <strong>git commit</strong> for each.</p>
<p>When that&#8217;s done, remove <b>plugins.txt</b>.</p>
<p>All your plugins are quickly updated with WP-CLI, but you get nice granular Git commits and messages.</p>
<hr />
<p><b>Do you need <a href=\"https://coveredwebservices.com/\">WordPress services?</a></b></p>
<p>Mark runs <a href=\"https://coveredwebservices.com/\">Covered Web Services</a> which specializes in custom WordPress solutions with focuses on security, speed optimization, plugin development and customization, and complex migrations.</p>
<p>Please reach out to start a conversation!</p>
[contact-form]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 12 Feb 2018 14:42:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mark Jaquith\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"Post Status: WordPress market opportunities: Upmarket edition — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=42360\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"https://poststatus.com/wordpress-market-opportunities-upmarket-edition-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2284:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p>In this episode, Brian and Brian continue their discussion on WordPress market opportunities with a focus on the upper-market and enterprise clients. They take a look at discovery projects, pitching WordPress against competing platforms, and considerations to make before pitching on these high-budget projects. There are plenty of positives and negatives when working on long-term projects that may have a dramatic impact on your company in many ways.</p>
<p>In addition to these market opportunities, the boys also discuss recent news including iThemes acquisition by Liquid Web, a welcome change to the WordPress.org plugin directory, and an unfortunate and far-reaching bug that shipped with the 4.9.3 release last week.</p>
<p></p>
<h3>Links</h3>
<ul>
<li><a href=\"https://poststatus.com/liquid-web-acquired-ithemes/\">Liquid Web acquires iThemes</a></li>
<li><a href=\"https://generatewp.com/new-policy-changes-wordpress-plugin-directory/\">Plugin directory notice changes</a></li>
<li><a href=\"https://make.wordpress.org/core/2018/02/06/wordpress-4-9-4-release-the-technical-details/\">4.9.4 technical details</a></li>
<li><a href=\"https://wpsessions.com/sessions/infusing-websites-brand-voice/\">Infusing Websites with Brand Voice</a><a href=\"https://wpsessions.com/teams\">WPS Team Training</a></li>
</ul>
<h3>Sponsor: WooCommerce</h3>
<p><a href=\"https://woocommerce.com/\">WooCommerce</a> makes the most customizable eCommerce software on the planet, and it’s the most popular too. You can build just about anything with WooCommerce. <a href=\"https://woocommerce.com/\">Try it today</a>, and thanks to the team at WooCommerce being a Post Status partner</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Feb 2018 20:43:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WPTavern: Jetpack 5.8 Adds Lazy Loading for Images Module\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78112\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wptavern.com/jetpack-5-8-adds-lazy-loading-for-images-module\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2079:\"<p>Jetpack 5.8 <a href=\"https://jetpack.com/2018/02/06/jetpack-5-8-release/\">is available</a> for download and includes a handful of new features for Professional, Premium, and Personal plan users. In <a href=\"https://wptavern.com/jetpack-5-4-introduces-beta-version-of-new-search-module-powered-by-elasticsearch-for-professional-plan-users\">October of last year</a>, Jetpack 5.4 began beta testing a new <a href=\"https://jetpack.com/support/search/\">search module</a> based on <a href=\"https://www.elastic.co/\">Elasticsearch</a>. Jetpack 5.8 concludes the beta and the new search service is available to Professional plan customers.</p>
<p>The new search module replaces the native search functionality in WordPress and Jetpack developers claim sites with a large amount of content, images, or products will see significant speed improvements and more relevant results. Developers can fine-tune the user experience by using custom queries and template tags. Users can sort results by categories, tags, month/year, post type, or any taxonomy.</p>
<p>In addition to the Content Delivery Network, users have another method to optimize their sites with a new module named Lazy Load Images. When activated, Jetpack will display a page&#8217;s textual content first. When a user scrolls down the page, Jetpack will request and download images so they appear when that section of the page comes into view. Sites with a large amount of images will benefit most from having this module activated.</p>
<p>Premium plan customers can now perform security scans on their sites at any time, upload an unlimited amount of videos, and access SEO tools that were once restricted to Business plan customers.</p>
<p>Other notable improvements include:</p>
<ul>
<li>Support for timezone and site language settings</li>
<li>Improved display of notices</li>
<li>The GettyImages shortcode now uses the new format required by GettyImages</li>
</ul>
<p>To view all of the additions in this release, check out the <a href=\"https://wordpress.org/plugins/jetpack/#developers\">Jetpack 5.8 changelog</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Feb 2018 07:54:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Matt: The Laity\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47918\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ma.tt/2018/02/the-laity/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:310:\"<blockquote class=\"wp-block-quote\">
    <p>In the last analysis, every profession is a conspiracy against the laity.</p><cite>The Sir Patrick Cullen character in George Bernard Shaw’s play <a href=\"https://en.m.wikipedia.org/wiki/The_Doctor%27s_Dilemma_(play)\">The Doctor’s Dilemma</a></cite></blockquote>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Feb 2018 21:48:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: WPWeekly Episode 304 – DesktopServer, Life, and Health with Marc Benzakein\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=78105&preview=true&preview_id=78105\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"https://wptavern.com/wpweekly-episode-304-desktopserver-life-and-health-with-marc-benzakein\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1931:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I are joined by <a href=\"https://twitter.com/MarcBenzak\">Marc Benzakein</a>, Operations Manager for ServerPress, LLC. We discussed recent updates to DesktopServer and received a progress report on 4.0. Marc also shared some of the struggles the team encountered throughout 2017.</p>
<p>We learned what&#8217;s new with <a href=\"https://wpsitesync.com/\">WP SiteSync</a> and what customers can look forward too later this year. We also talked about <a href=\"https://wordpress.tv/2017/12/08/marc-benzakein-fat-happy-and-fifty/\">Marc&#8217;s journey</a> of becoming a healthier person both physically and mentally. He recalls the issues he had to overcome and shares advice on how others can improve their health.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/woocommerce-3-3-1-released-addresses-template-conflicts\">WooCommerce 3.3.1 Released, Addresses Template Conflicts</a><br />
<a href=\"https://wptavern.com/wordpress-4-9-4-fixes-critical-auto-update-bug-in-4-9-3\">WordPress 4.9.4 Fixes Critical Auto Update Bug in 4.9.3</a><br />
<a href=\"https://thehackernews.com/2018/02/wordpress-dos-exploit.html\">Unpatched DoS Flaw Could Help Anyone Take Down WordPress Websites</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, February 14th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #304:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Feb 2018 01:48:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"HeroPress: Becoming a Better Designer Through WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2441\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:142:\"https://heropress.com/essays/becoming-better-designer-wordpress/#utm_source=rss&utm_medium=rss&utm_campaign=becoming-better-designer-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:19189:\"<img width=\"960\" height=\"480\" src=\"https://heropress.com/wp-content/uploads/2018/02/020718-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: The connections I\'ve made, the skills I\'ve honed, and the mentorship I\'ve received have all contributed to making me the designer I am today.\" /><h3>The early years</h3>
<p>I’ve always been an art kid. One of my first school memories is of drawing a clown and my art teacher being so enamored with it, she hung it up on her door for the whole year.</p>
<p>The first time in my educational life I didn’t take an art class was my first year of college. By the end of the year, my fingers were itching and I was ready to scream — I had to take art. It didn’t take long for me to declare a Studio Art minor, which eventually became an Arts and Technology minor my senior year.</p>
<p>I’ve also always been an internet kid. We received our first internet-connected Windows desktop in 1997. I’ll never forget the sound of dial-up as I signed into AOL, day after day for years to come. When my older brother started working for an ISP, we were able to go beyond just using AOL to connect, and I started spending more time exploring websites (rather than just AOL’s apps and chat rooms). I wanted to be like my older brother and learn how to make sites. I taught myself basic HTML by using View Source on existing sites — even back then, I was benefiting from the open web!</p>
<p>Angelfire was my earliest web canvas. A couple of my friends eventually got into making websites, but I was always a little disdainful of them for using Homestead’s GUI builder, while I was making my sites from scratch. I had a blast making image-rich personal and fan sites with tables and HTML styles. Landing a copy of Photoshop Elements in high school only intensified my enjoyment of web design. I kept that passion up through college, when I found my first design gig.</p>
<p><a href=\"https://heropress.com/wp-content/uploads/2018/02/old_web_site.jpg\"><img class=\"size-large wp-image-2442 aligncenter\" src=\"https://heropress.com/wp-content/uploads/2018/02/old_web_site-1024x479.jpg\" alt=\"Old Website, best viewed on AOL\" width=\"960\" height=\"449\" /></a></p>
<h3>Could this be a career?</h3>
<p>My first year of college got off to a bit of a rough financial start. By the time my financial aid was finalized and I was finally able to pick a work study job, my options were pretty limited. A dance professor needed an assistant to help her with some photocopying and organization tasks, along with helping her build out a print and web portfolio.</p>
<p>I was honestly a terrible assistant, but I did a pretty good job with the design work. I continued to refine my skills working in the computers labs in subsequent years, and in my Junior year of college (ten years ago!) I landed an internship at a local web design agency. That internship turned into a part-time job, which opened up doors to more local web design opportunities, and soon I was graduating college and pretty well situated into the start of my career.</p>
<p><a href=\"https://heropress.com/wp-content/uploads/2018/02/early-site.jpg\"><img class=\"aligncenter size-large wp-image-2443\" src=\"https://heropress.com/wp-content/uploads/2018/02/early-site-1024x666.jpg\" alt=\"Skeumorphic website design that looks like a notepad with pen ink all over it.\" width=\"960\" height=\"624\" /></a></p>
<p>It was at these agencies that I started learning how to build WordPress websites. I’d used WordPress a couple times in college and felt comfortable with it, but now I was focusing a lot more on building my skills as a designer and front-end developer. My girlfriend (who was working at the same web agency) and I managed to convince our boss to start letting us create totally custom websites, rather than customizing existing themes, and that opened up a whole new world of design opportunities.</p>
<h3>My first WordCamp</h3>
<p>It was around then that my girlfriend, who attended WordCamp NYC the previous year, noticed the conference organizers were <a href=\"https://2010.nyc.wordcamp.org/volunteer-designer-needed/\">looking for some volunteer designers</a> to help create some graphics. She passed along the information, and I got in touch.</p>
<p>I collaborated with a few other designers to create the WordCamp branding, which was used across the website, t-shirt, signage, and stickers:</p>
<p><a href=\"https://heropress.com/wp-content/uploads/2018/02/wcnyc.png\"><img class=\"aligncenter size-full wp-image-2444\" src=\"https://heropress.com/wp-content/uploads/2018/02/wcnyc.png\" alt=\"WCNYC Banner\" width=\"429\" height=\"286\" /></a></p>
<p>It was amazing to see it everywhere at the WordCamp. It felt really special. Though I didn’t get “props” for this, I still consider it my first contribution to WordPress.</p>
<p>WordCamp NYC was a ton of fun. I met interesting people, learned a lot about WordPress, and started to get a feel for the community. I left with a desire to get more involved. I browsed through WordPress.org, stumbling upon the “Make” section. I was stoked to see that there was a design group. I couldn’t write much code beyond CSS, but I could contribute my design skills. I joined a couple of the core channels on IRC, including the design channel (#wordpress-ui), and observed for while. I watched how the other designers in the project communicated, what they worked on, where they presented their work, etc. By observing before participating, I could learn the social queues and mores of the community. I didn’t want to embarass myself — I wanted to do things the established way based on community standards.</p>
<p>What I found to be one of the most difficult parts of contributing was adapting to the technology used to build WordPress. I had to learn how to use command line and SVN. Getting set up in SVN and terminal was probably the biggest thing that stopped me from contributing code during my early years.</p>
<p>But most of all, it came down to conquering fear. Fear that my design skills would be unwanted and unwelcome; fear that other contributors would look down on me or ignore me, or that they’d find me irritating; fear that I just wasn’t good enough to contribute. Some of this fear persists today, albeit greatly reduced.</p>
<p>There’s a point at which I managed to conquer a little bit of that fear, stop observing, and really start to pitch in. Slowly, I started chiming in and volunteering for design tasks in IRC and the Make Design p2. I ended up doing a lot of small projects on the community side (rather than the core side) at first — some new landing pages and redesigns of sections on WordPress.org, graphics, and design for my own local meetups. I started feeling more and more confident with my contributions.</p>
<h3>Core Props</h3>
<p>By this point, I had done some wireframes and mockups for the core WordPress software — I’d even spoken at a WordCamp! — but I hadn’t actually gotten any code committed. Which meant, at this point in time, I didn’t have any “core props.” I was still really intimidated by Trac and SVN. I was a designer, and most design conversations happened in explicitly design space. But I really wanted to get some code committed into core, so I needed to find a CSS bug I felt qualified to fix.</p>
<p>At WordCamp Philly in 2012, I finally got a chance. Sunday was devoted to contributing to WordPress. There were experienced core contributors present who could teach people how to make a patch, how to submit a ticket, and suggest tickets for people to work on.</p>
<p>Aaron Jorbin, a core contributor and fellow speaker (and, now a friend), found a CSS issue I could work on: bringing the alternate “blue” color scheme into sync with the default “grey” scheme. He helped me get set up, helped me through saving my changes as a patch, and then helped me submit that patch to Trac. Andy Nacin, another core contributor (and future friend!) subsequently committed that patch, and I received my first core props.</p>
<p><a href=\"https://heropress.com/wp-content/uploads/2018/02/first-props2.png\"><img class=\"aligncenter size-large wp-image-2445\" src=\"https://heropress.com/wp-content/uploads/2018/02/first-props2-1024x370.png\" alt=\"Screenshot of ticket giving Mel props\" width=\"960\" height=\"347\" /></a></p>
<p>After creating my first patch, contributing became easier and easier. My confidence grew, and I spent more time participating in IRC, p2s, and Trac discussions. Then, in January of 2013, major design changes started coming to WordPress.</p>
<h3>My WordPress apprenticeship</h3>
<p>It started with icons.</p>
<p>Ben Dunkle, WordPress’s official icon designer, proposed some shiny new icons for the WordPress dashboard. They were “flat” — one color, not a ton of details. The icons were awesome, but they didn’t really fit stylistically with the rest of the admin. The flat styles clashed with WordPress’ heavy use of gradients.</p>
<p>So, I helped imagine what the admin could look like totally flat. We tried out a couple ideas, got them committed, and refined in code. The stark styles looked really fresh after years of gradients!</p>
<p>Unfortunately, flattening the admin unearthed a whole lot of other issues. There wasn’t enough time to flesh out the new design before the next version of WordPress launched, so the flat styles got reverted and tabled for another time.</p>
<p>Pretty soon after, I received an email via my site’s contact form:</p>
<p><em><strong>Name</strong>: Matt</em><br />
<em><strong> Comment</strong>: Add me on Skype when you get a chance.</em></p>
<p>I think my heart stopped when I realized I had been emailed by the co-founder of WordPress, Matt Mullenweg. Matt invited me to come join a group that would take a broader look at redesigning the admin (codenamed “MP6”). It meant a lot for someone as important as Matt to recognize my skills. I spent a lot of my early years as a designer plagued with self-doubt, and suddenly I had someone pointing at me, going “I believe in you!”</p>
<p>I leapt at the chance.</p>
<p>Our group worked together on Skype. We quickly scoped the goal of MP6 to only update CSS and a little bit of JS. I helped Ben make some new vector icons, gave feedback and critiqued design proposals, and made some design proposals of my own. It was an intimate group where we all felt free to safely share and critique each other’s work. The mentorship I received from more experienced WordPress designers was invaluable to my growth. Working with these veterans of WordPress really helped me to grow into my fledgling wings.</p>
<p><a href=\"https://make.wordpress.org/core/2013/10/23/mp6-3-8-proposal/\">WordPress 3.8 shipped with the updated admin interface</a>, and I knew it was time to take my design career to a new level.</p>
<p><a href=\"https://heropress.com/wp-content/uploads/2018/02/4-8-credits-smaller.jpg\"><img class=\"aligncenter size-large wp-image-2446\" src=\"https://heropress.com/wp-content/uploads/2018/02/4-8-credits-smaller-1024x895.jpg\" alt=\"WordPress 4.8 Credits\" width=\"960\" height=\"839\" /></a></p>
<h3>Leaving the nest</h3>
<p>I’d had my eye on Automattic, the makers of WordPress.com, the Jetpack plugin, and many other products, for most of my time contributing to WordPress. A couple of the designers I worked with on MP6 were Automattic designers, and it was an absolute joy to collaborate with them. At this point I’d spent so much of my career as either a lone designer, or in a competitive environment, that having a supportive, collaborative group of people helping me improve my work was a revelation.</p>
<p>I desperately wanted to work at Automattic.</p>
<p>While MP6 was in the works, I participated in a three month long design apprenticeship at a local agency. I worked alongside experienced mentors and fellow apprentices to hone my interface and user experience design skills. It was challenging and thrilling and totally complemented the mentorship I was receiving from WordPress folks. Plus, working in a positive environment reinforced my desire to work somewhere similar.</p>
<p>After the apprenticeship, I finally felt like I had the skills and confidence to apply. I spent a lot of time writing my cover letter, and redesigning my portfolio to use in-depth case studies on a small number of recent projects. I finally sent off my application and crossed my fingers.</p>
<p>A couple weeks later, I received a reply back asking to schedule an interview. I was terrified, but luckily, Automattic conducts interviews via text, so I was able to hide my fear behind my keyboard and hopefully try to project confidence. (Aside: I also show all my emotions on my face, so online communication is the best.)</p>
<p>It must have worked, because I was moved on to the next phase of the application, doing a self-contained trial project, which was a whole ton of fun. I was able to put my recently refined research, interviewing, and user testing skills to use. I loved being given a real challenge to tackle. My trial went well, so I was moved along to the final interview with Matt Mullenweg. We spent a couple hours chatting on Skype, and at the end of our conversation I was given an offer. Welcome to Automattic!</p>
<p>After working so hard on my apprenticeship, and on MP6, joining Automattic felt incredibly validating. The work I put in, the mentorship I received, all of the collaboration, led to this moment. I felt like I had graduated from apprentice and was now embarking on my adventure as a design journeyman. And boy, has it been an adventure!</p>
<h3><a href=\"https://heropress.com/wp-content/uploads/2018/02/automattic-2-smaller.jpg\"><img class=\"aligncenter size-large wp-image-2447\" src=\"https://heropress.com/wp-content/uploads/2018/02/automattic-2-smaller-1024x678.jpg\" alt=\"Automattic Group Photo\" width=\"960\" height=\"636\" /></a></h3>
<h3>Design leadership</h3>
<p>The past four and a half years at Automattic have been fantastic. I have the best coworkers anyone can ask for. I’ve worked with some incredibly talented and empathetic designers, whose guidance and feedback constantly encourage me to improve my skills.</p>
<p>I’ve continued to contribute to WordPress, slowly gaining more responsibility in the project the longer I stuck around. That’s the secret to becoming an open source leader, I discovered — <strong>decisions are made by the people who show up</strong>.</p>
<p>In 2016, I was asked to by the Release Design Lead for <a href=\"https://wordpress.org/news/2016/04/coleman/\">WordPress 4.5 “Coleman.”</a> I worked alongside the other release leads to make design-related decisions that impacted the release. This was the first release we experimented with having a Design Lead. I felt like design finally had a seat at the table.</p>
<p>This continued to be the case last year, when Matt Mullenweg announced core focuses for the year: Editing, Customization, and the API. Both Editing and Customization had designers co-leading their focus. I was named the Customization co-lead. I’d been working on customization and site building on WordPress.com for over a year, so I had relevant experience.</p>
<p>I worked with my developer co-lead, Weston Ruter, on low-hanging fruit, most of which we released in WordPress 4.8. The release was smaller, focused more on improvements than new features. We made a lot of updates to widgets, which had been long neglected.</p>
<p>After that, we turned our sights to some more ambitious projects: drafting and scheduling changes in the Customizer, improvements to code editing in the WordPress admin, even more widget updates, and upgrades around the flow of changing themes and building menus for your site. We took a design-first approach to building out these new features, and I think it really shows in the work that we produced during the 4.9 release cycle, which Weston and I co-led.</p>
<p><a href=\"https://wordpress.org/news/2017/11/tipton/\">WordPress 4.9 “Tipton”</a> launched in November. Since then, I’ve pivoted to work on <a href=\"https://wordpress.org/gutenberg/\">Gutenberg</a>, the new editing experience for WordPress which should be released in 5.0. Once the editing experience wraps up, we’re going to start looking at how we can extend Gutenberg to cover site building and customization. It’s a big, audacious goal that I hope to pursue with caution, humility, and a spirit of adventure.</p>
<p>I owe WordPress a great deal. The connections I’ve made, the skills I’ve honed, and the mentorship I’ve received have all contributed to making me the designer I am today. I hope to give back for years to come!</p>
<p><a href=\"https://heropress.com/wp-content/uploads/2018/02/community-summit-smaller.jpg\"><img class=\"aligncenter size-full wp-image-2448\" src=\"https://heropress.com/wp-content/uploads/2018/02/community-summit-smaller.jpg\" alt=\"Community Summit Group Photo\" width=\"960\" height=\"556\" /></a></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Becoming a Better Designer Through WordPress\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Becoming%20a%20Better%20Designer%20Through%20WordPress&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fbecoming-better-designer-wordpress%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Becoming a Better Designer Through WordPress\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fbecoming-better-designer-wordpress%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fbecoming-better-designer-wordpress%2F&title=Becoming+a+Better+Designer+Through+WordPress\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Becoming a Better Designer Through WordPress\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/becoming-better-designer-wordpress/&media=https://heropress.com/wp-content/uploads/2018/02/020718-150x150.jpg&description=Becoming a Better Designer Through WordPress\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Becoming a Better Designer Through WordPress\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/becoming-better-designer-wordpress/\" title=\"Becoming a Better Designer Through WordPress\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/becoming-better-designer-wordpress/\">Becoming a Better Designer Through WordPress</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 07 Feb 2018 12:00:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Mel Choyce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"WPTavern: WooCommerce 3.3.1 Released, Addresses Template Conflicts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78089\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wptavern.com/woocommerce-3-3-1-released-addresses-template-conflicts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1330:\"<p>WooCommerce 3.3.1 <a href=\"https://woocommerce.wordpress.com/2018/02/06/woocommerce-3-3-1-fix-release-notes/\">is available</a> and fixes template conflicts discovered in a handful of WordPress themes that forced the team to <a href=\"https://wptavern.com/woocommerce-3-3-removed-from-plugin-directory-due-to-theme-conflicts\">revert WooCommerce 3.3</a>. The team reviewed handful of the most common themes running WooCommerce and tested them for compatibility with 3.3.1.</p>
<p><a href=\"https://github.com/woocommerce/woocommerce/wiki/Template-File-Guidelines-for-Devs-and-Theme-Authors#hook-vs-override---when-to-use-what\">WooCommerce developers recommend</a> that theme authors use hooks instead of template overrides to ensure maximum compatibility.</p>
<p>According to Mike Jolley, WooCommerce lead developer, this release highlighted issues with the template system&#8217;s extensibility and a disconnect between theme authors on external marketplaces. &#8220;We hope to find solutions to these problems in the near future,&#8221; Jolley said.</p>
<p>WooCommerce 3.3.1 has at least <a href=\"https://github.com/woocommerce/woocommerce/compare/3.3.0...3.3.1\">90 commits</a>. Users are encouraged to create a full-backup of their sites and then browse to Dashboard &gt; Updates to update WooCommerce from within WordPress.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 07 Feb 2018 09:46:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: WordPress 4.9.4 Fixes Critical Auto Update Bug in 4.9.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78087\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wptavern.com/wordpress-4-9-4-fixes-critical-auto-update-bug-in-4-9-3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1984:\"<p>Hours after <a href=\"https://wptavern.com/wordpress-4-9-3-released-fixes-34-bugs\">WordPress 4.9.3 was released</a>, the WordPress development team followed it up <a href=\"https://make.wordpress.org/core/2018/02/06/wordpress-4-9-4-release-the-technical-details/\">with 4.9.4</a> to fix a critical bug with the auto update process. The bug generates a fatal PHP error when WordPress attempts to update itself.</p>
<p>This error requires WordPress site owners and administrators to manually update to WordPress 4.9.4 by visiting your Dashboard and clicking the Update Now button on the Updates page. Alternatively, you can update by uploading the files via SFTP or by using WP-CLI.</p>
<p>Dion Hulse, WordPress lead developer, says managed hosts that apply updates automatically for their customers will be able to update sites as they normally do. This may explain why some users have reported that sites running 4.9.3 have automatically updated to 4.9.4 without issue.</p>
<p>The bug stems from an attempt to <a href=\"https://core.trac.wordpress.org/ticket/43103\">reduce the number of API calls</a> made when the auto update cron job is run. Unfortunately, the code committed had unintended consequences. &#8220;It triggers a fatal error as not all of the dependencies of <code>find_core_auto_update()</code> are met,&#8221; Hulse said.</p>
<p>A postmortem will be published once the team determines how to prevent this mistake from happening in the future. &#8220;We don’t like bugs in WordPress any more than you do, and we’ll be taking steps to both increase automated coverage of our updates and improve tools to aid in the detection of similar bugs before they become an issue in the future,&#8221; Hulse said.</p>
<p>While WordPress 4.9.3 and 4.9.4 do not include any security fixes, it&#8217;s important to note that in order to receive automatic security updates in the future, sites using the 4.9 branch must be running at least 4.9.4. Older branches are unaffected.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 07 Feb 2018 09:19:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"Dev Blog: WordPress 4.9.4 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5559\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2018/02/wordpress-4-9-4-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1814:\"<p>WordPress 4.9.4 is now available.</p>
<p>This maintenance release fixes a severe bug in 4.9.3, which will cause sites that support automatic background updates to fail to update automatically, and will require action from you (or your host) for it to be updated to 4.9.4.</p>
<p>Four years ago with <a href=\"https://wordpress.org/news/2013/10/basie/\">WordPress 3.7 &#8220;Basie&#8221;</a>, we added the ability for WordPress to self-update, keeping your website secure and bug-free, even when you weren&#8217;t available to do it yourself. For four years it&#8217;s helped keep millions of installs updated with very few issues over that time. Unfortunately <a href=\"https://wordpress.org/news/2018/02/wordpress-4-9-3-maintenance-release/\">yesterdays 4.9.3 release</a> contained a severe bug which was only discovered after release. The bug will cause WordPress to encounter an error when it attempts to update itself to WordPress 4.9.4, and will require an update to be performed through the WordPress dashboard or hosts update tools.</p>
<p>WordPress managed hosting companies who install updates automatically for their customers can install the update as normal, and we&#8217;ll be working with other hosts to ensure that as many customers of theirs who can be automatically updated to WordPress 4.9.4 can be.</p>
<p>For more technical details of the issue, we&#8217;ve <a href=\"https://make.wordpress.org/core/2018/02/06/wordpress-4-9-4-release-the-technical-details/\">posted on our Core Development blog</a>. For a full list of changes, consult the <a href=\"https://core.trac.wordpress.org/query?status=closed&milestone=4.9.4&group=component\">list of tickets</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.9.4</a> or visit Dashboard → Updates and click “Update Now.”</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 06 Feb 2018 16:17:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Dion Hulse\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"WPTavern: WordPress 4.9.3 Released, Fixes 34 Bugs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78081\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wptavern.com/wordpress-4-9-3-released-fixes-34-bugs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:681:\"<p>WordPress 4.9.3 <a href=\"https://wordpress.org/news/2018/02/wordpress-4-9-3-maintenance-release/\">is available</a> and fixes 34 bugs. Customizer changesets, the visual editor, widgets, and compatibility for PHP 7.2 highlight this release. You can view all of the changes via the <a href=\"https://core.trac.wordpress.org/log/branches/4.9?rev=42630&stop_rev=42521\">changelog</a> or <a href=\"https://core.trac.wordpress.org/query?status=closed&milestone=4.9.3&group=component\">trac tickets</a>. Most sites will update automatically. However, if you want to trigger the update ahead of time or manually update, visit your Dashboard, click the Updates link, and click Update Now.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 06 Feb 2018 08:35:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"WPTavern: Liquid Web Acquires iThemes in Multi-Million Dollar Deal\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77907\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://wptavern.com/liquid-web-acquires-ithemes-in-multi-million-dollar-deal\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4149:\"<p>Liquid Web, a managed hosting service founded in 1997, <a href=\"https://www.liquidweb.com/blog/liquid-web-acquires-ithemes/\">has acquired</a> <a href=\"https://ithemes.com/\">iThemes</a>. iThemes recently <a href=\"https://ithemes.com/10-years-in-wordpress/\">celebrated its 10th year</a> in business. <a href=\"https://poststatus.com/liquid-web-acquired-ithemes/\">PostStatus reports</a> that it was an all cash deal and sources confirmed to the Tavern that it was a multi-million dollar acquisition.</p>
<p>iThemes will continue to operate as an independent unit within Liquid Web. Cory Miller will remain as General Manager of iThemes and the company will keep its office and employees in Oklahoma City, OK.</p>
<p>iThemes was founded in 2008 and is part of a group of WordPress focused companies that started <a href=\"https://medium.com/@jasonpatricksc/a-brief-history-of-a-wordpress-theme-business-3847e16fcba4\">around the same time</a>. The group includes WooThemes, Revolution Themes now known as StudioPress, Press75, WPZoom, and others.</p>
<p>WooThemes was <a href=\"https://wptavern.com/automattic-acquires-woocommerce\">acquired by Automattic</a>. StudioPress has branched off into content marketing with CopyBlogger and hosting via StudioPress sites. Press75 was acquired by Westwerk in 2014 and WPZoom continues to operate independently.</p>
<p>iThemes diversified its business a number of times over the years, adding plugins and services to its portfolio. Some of the most notable products include, FlexxTheme, BackupBuddy, Builder, iThemes Sync, and iThemes Security. In 2013, the company branched off into the e-commerce space <a href=\"https://wptavern.com/ithemes-launches-e-commerce-plugin-exchange\">with Exchange</a>. In 2017, <a href=\"https://ithemes.com/2017/07/13/ithemes-exchange-new-home-exchangewpcom/\">Exchange was acquired</a> by AJ Morris allowing the company to focus on iThemes Sales Accelerator, a new product that works exclusively with WooCommerce.</p>
<p>Considering Liquid Web recently launched <a href=\"https://www.liquidweb.com/products/managed-woocommerce-hosting/\">its managed WooCommerce hosting</a>, iThemes Sales Accelerator should pair nicely with its services.</p>
<p>This isn&#8217;t the first time a large webhosting company has acquired a WordPress business. In the last two years, GoDaddy has acquired three companies with a presence in the WordPress ecosystem.</p>
<ul>
<li><strong>April 2013</strong> EIG Acquires MOJO-Themes</li>
<li><strong>September 2016</strong> GoDaddy Acquires ManageWP</li>
<li><strong>December 2016</strong> GoDaddy Acquires WP Curve</li>
<li><strong>March 2017</strong> GoDaddy Acquires Sucuri</li>
</ul>
<h2>After 10 Years, Cory Miller Lets Go</h2>
<p>Miller founded iThemes 10 years ago and helped navigate it through the ups and downs that come with running a business. Although Miller no longer owns the company he founded, he&#8217;s excited about the next chapter and the opportunities it presents to him and his team.</p>
<p>&#8220;One of the keys that has contributed greatly to our success over the last 10 years is being willing to adapt and to innovate and to try new things,&#8221; Miller said. &#8220;For instance, If we’d kept focusing solely on WordPress themes, which was our primary business for the early years, we wouldn’t be around today.</p>
<p>&#8220;As we surveyed the landscape in WordPress, one thing was very obvious to us: hosting is the future. As a bootstrapped company from the beginning, with our DNA as a software company, and seeing where Liquid Web is going, it just made sense for us to join forces.</p>
<p>&#8220;We view this is as another chapter in our story of our willingness to adapt and try new things so we can keep doing what we do best — Make People’s Lives Awesome. So we&#8217;re tremendously excited about our future with Liquid Web, and what we’re going to be able to do for the WordPress community together.&#8221;</p>
<p>Miller says they&#8217;re in the middle of the transition process and are working towards tighter integration between iThemes&#8217; products and Liquid Web&#8217;s managed hosting services.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 06 Feb 2018 00:33:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"Dev Blog: WordPress 4.9.3 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5545\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2018/02/wordpress-4-9-3-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3408:\"<p>WordPress 4.9.3 is now available.</p>
<p>This maintenance release fixes 34 bugs in 4.9, including fixes for Customizer changesets, widgets, visual editor, and PHP 7.2 compatibility. For a full list of changes, consult the <a href=\"https://core.trac.wordpress.org/query?status=closed&milestone=4.9.3&group=component\">list of tickets</a> and the <a href=\"https://core.trac.wordpress.org/log/branches/4.9?rev=42630&stop_rev=42521\">changelog</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.9.3</a> or visit Dashboard → Updates and click “Update Now.” Sites that support automatic background updates are already beginning to update automatically.</p>
<p>Thank you to everyone who contributed to WordPress 4.9.3:</p>
<p><a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/abdullahramzan/\">abdullahramzan</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andreiglingeanu/\">andreiglingeanu</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/bpayton/\">Brandon Payton</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/coleh/\">coleh</a>, <a href=\"https://profiles.wordpress.org/darko-a7/\">Darko A7</a>, <a href=\"https://profiles.wordpress.org/desertsnowman/\">David Cramer</a>, <a href=\"https://profiles.wordpress.org/dlh/\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/flixos90/\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/frank-klein/\">Frank Klein</a>, <a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jbpaul17/\">Jeffrey Paul</a>, <a href=\"https://profiles.wordpress.org/lizkarkoski/\">lizkarkoski</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/mattyrob/\">mattyrob</a>, <a href=\"https://profiles.wordpress.org/monikarao/\">Monika Rao</a>, <a href=\"https://profiles.wordpress.org/munyagu/\">munyagu</a>, <a href=\"https://profiles.wordpress.org/ndavison/\">ndavison</a>, <a href=\"https://profiles.wordpress.org/nickmomrik/\">Nick Momrik</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/rachelbaker/\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/rishishah/\">rishishah</a>, <a href=\"https://profiles.wordpress.org/othellobloke/\">Ryan Paul</a>, <a href=\"https://profiles.wordpress.org/sasiddiqui/\">Sami Ahmed Siddiqui</a>, <a href=\"https://profiles.wordpress.org/sayedwp/\">Sayed Taqui</a>, <a href=\"https://profiles.wordpress.org/seanchayes/\">Sean Hayes</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/shooper/\">Shawn Hooper</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/manikmist09/\">Sultan Nasir Uddin</a>, <a href=\"https://profiles.wordpress.org/tigertech/\">tigertech</a>, and <a href=\"https://profiles.wordpress.org/westonruter/\">Weston Ruter</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Feb 2018 19:47:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Sergey Biryukov\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"Mark Jaquith: Tips for configuring WordPress environments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://markjaquith.wordpress.com/?p=5476\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"https://markjaquith.wordpress.com/2018/02/05/tips-for-configuring-wordpress-environments/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4626:\"<p>Many WordPress hosts will give your site a &#8220;staging&#8221; environment. You can also use tools like <a href=\"https://local.getflywheel.com/\">Local by Flywheel</a>, or <a href=\"https://www.mamp.info/\">MAMP Pro</a> to run a local &#8220;dev&#8221; version of your site. These are great ways of testing code changes, playing with new plugins, or making theme tweaks, without risking breaking your live &#8220;production&#8221; site.</p>
<p>Here is my advice for working with different WordPress environments.</p>
<h2>Handling Credentials</h2>
<p>The live (&#8220;production&#8221;) version of your site should be opt-in. That is, your site&#8217;s Git repo should <strong>not</strong> store production credentials in <strong>wp-config.php</strong>. You don&#8217;t want something to happen like <a href=\"https://www.reddit.com/r/cscareerquestions/comments/6ez8ag/accidentally_destroyed_production_database_on/\">when this developer accidentally connected to the production database</a> and destroyed all the company data on his first day.</p>
<p>Instead of keeping database credentials in <strong>wp-config.php</strong>, have <strong>wp-config.php</strong> look for a <strong>local-config.php</strong> file. Replace the section that defines the database credentials with something like this:</p>
<pre class=\"brush: php; title: ; notranslate\">if ( file_exists( __DIR__ . \'/local-config.php\' ) ) {
    include( __DIR__ . \'/local-config.php\' );
} else {
    die( \'local-config.php not found\' );
}</pre>
<p>Make sure you add <strong>local-config.php</strong> to your <strong>.gitignore</strong> so that no one commits their local version to the repo.</p>
<p>On production, you&#8217;ll create a <strong>local-config.php</strong> with production credentials. On staging or development environments, you&#8217;ll create a <strong>local-config.php</strong> with the credentials for those environments.</p>
<h2>Production is a Choice</h2>
<p>Right after the section that calls out <strong>local-config.php</strong>, put something like this:</p>
<pre class=\"brush: php; title: ; notranslate\">if ( ! defined( \'WP_ENVIRONMENT\' ) ) {
    define( \'WP_ENVIRONMENT\', \'development\' );
}</pre>
<p>The idea here is that there will always be a <strong>WP_ENVIRONMENT</strong> constant available to you that tells you what kind of environment your site is being run in. In production, you will put this in <strong>local-config.php</strong> along with the database credentials:</p>
<pre class=\"brush: php; title: ; notranslate\">define( \'WP_ENVIRONMENT\', \'production\' );</pre>
<p>Now, in your theme, or your custom plugins, or other code, you can do things like this:</p>
<pre class=\"brush: php; title: ; notranslate\">if ( \'production\' === WP_ENVIRONMENT ) {
    add_filter( \'option_gravityformsaddon_gravityformsstripe_settings\', function( $stripe_settings ) {
        $stripe_settings[\'api_mode\'] = \'live\';
        return $stripe_settings;
    });
} else {
    add_filter( \'option_gravityformsaddon_gravityformsstripe_settings\', function( $stripe_settings ) {
        $stripe_settings[\'api_mode\'] = \'test\';
        return $stripe_settings;
    });
}</pre>
<p>This bit of code is for the Easy Digital Downloads Stripe gateway plugin. It makes sure that on the production environment, the payment gateway is always in <strong>live</strong> mode, and the anywhere else, it is always in <strong>test</strong> mode. This protects against two very bad situations: connecting to live services from a test environment (which could result in customers being charged for test transactions) and connecting to test services from a live environment (which could prevent customers from purchasing products on your site).</p>
<p>You can also use this pattern to do things like hide Google Analytics on your test sites, or make sure debug plugins are only active on development sites (more on that, in a future post!)</p>
<p>Don&#8217;t rely on complicated procedures (&#8220;step 34: make sure you go into the Stripe settings and switch the site to test mode on your local test site&#8221;) — make these things explicit in code. Make it impossible to screw it up, and working on your sites will become faster and less stressful.</p>
<hr />
<p><b>Do you need <a href=\"https://coveredwebservices.com/\">WordPress services?</a></b></p>
<p>Mark runs <a href=\"https://coveredwebservices.com/\">Covered Web Services</a> which specializes in custom WordPress solutions with focuses on security, speed optimization, plugin development and customization, and complex migrations.</p>
<p>Please reach out to start a conversation!</p>
[contact-form]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Feb 2018 14:59:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mark Jaquith\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"Matt: National Magazine Award Nomination\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47900\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ma.tt/2018/02/national-magazine-award-nomination/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:761:\"<p>Longreads <a href=\"http://www.magazine.org/asme/about-asme/pressroom/asme-press-releases/ellies-2018-finalists-announced\">was nominated today</a> for its first-ever <a href=\"https://en.wikipedia.org/wiki/National_Magazine_Awards\">National Magazine Award</a>, in the category of columns and commentary, alongside ESPN The Magazine, BuzzFeed News, Pitchfork, and New York magazine. Laurie Penny&#x27;s Longreads columns <a href=\"https://longreads.com/tag/metoo-and-consent/\">explore important questions of consent and female desire</a> that have strongly resonated in our current moment. In addition to this nomination, Penny&#x27;s columns have been translated and republished in Italian and German newspapers, and will be collected in a forthcoming book.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 02 Feb 2018 21:37:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"Dev Blog: The Month in WordPress: January 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5541\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2018/02/the-month-in-wordpress-january-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3839:\"<p>Things got off to a gradual start in 2018 with momentum starting to pick up over the course of the month. There were some notable developments in January, including a new point release and work being done on other important areas of the WordPress project.</p>

<hr class=\"wp-block-separator\" />

<h2>WordPress 4.9.2 Security and Maintenance Release</h2>

<p>On January 16, <a href=\"https://wordpress.org/news/2018/01/wordpress-4-9-2-security-and-maintenance-release/\">WordPress 4.9.2 was released</a> to fix an important security issue with the media player, as well as a number of other smaller bugs. This release goes a long way to smoothing out the 4.9 release cycle with the next point release, v4.9.3, <a href=\"https://make.wordpress.org/core/2018/01/31/wordpress-4-9-3-release-pushed-to-february-5th/\">due in early February</a>.</p>

<p>To get involved in building WordPress Core, jump into the #core channel in the<a href=\"https://make.wordpress.org/chat/\"> Making WordPress Slack group</a>, and follow<a href=\"https://make.wordpress.org/core/\"> the Core team blog</a>.</p>

<h2>Updated Plugin Directory Guidelines</h2>

<p>At the end of 2017, <a href=\"https://developer.wordpress.org/plugins/wordpress-org/detailed-plugin-guidelines/\">the guidelines for the Plugin Directory</a> received a significant update to make them clearer and expanded to address certain situations. This does not necessarily make these guidelines complete, but rather more user-friendly and practical; they govern how developers build plugins for the Plugin Directory, so they need to evolve with the global community that the Directory serves.</p>

<p>If you would like to contribute to these guidelines, you can make a pull request to <a href=\"https://github.com/WordPress/wporg-plugin-guidelines\">the GitHub repository</a> or email <a href=\"mailto:plugins@wordpress.org\">plugins@wordpress.org</a>. You can also jump into the #pluginreview channel in the<a href=\"https://make.wordpress.org/chat/\"> Making WordPress Slack group</a>.</p>

<hr class=\"wp-block-separator\" />

<h2>Further Reading:</h2>

<ul>
    <li>Near the end of last year a lot of work was put into improving the standards in the WordPress core codebase and now <a href=\"https://make.wordpress.org/core/2017/11/30/wordpress-php-now-mostly-conforms-to-wordpress-coding-standards/\">the entire platform is at nearly 100% compliance with the WordPress coding standards</a>.</li>
    <li>Gutenberg, the new editor coming to WordPress core in the next major release, <a href=\"https://make.wordpress.org/core/2018/01/25/whats-new-in-gutenberg-25th-january/\">was updated to v2.1 this month</a> with some great usability and technical improvements.</li>
    <li>The Global Community Team is <a href=\"https://make.wordpress.org/community/2018/01/16/2018-goals-for-the-global-community-team-suggestions-time/\">taking suggestions for the goals of the Community program in 2018</a>.</li>
    <li><a href=\"https://online.wpcampus.org/\">WPCampus Online</a>, a digital conference focused on WordPress in higher education, took place on January 30. The videos of the event sessions will be online soon.</li>
    <li>A WordPress community member <a href=\"https://wptavern.com/new-toolkit-simplifies-the-process-of-creating-gutenberg-blocks\">has released a toolkit</a> to help developers build blocks for Gutenberg.</li>
    <li>The community team that works to improve the WordPress hosting experience is relatively young, but <a href=\"https://make.wordpress.org/hosting/2018/01/25/hosting-meeting-notes-january-10-2018/\">they have been making some great progress recently</a>.</li>
</ul>

<p><em>If you have a story we should consider including in the next “Month in WordPress” post, please <a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\">submit it here</a>.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 02 Feb 2018 08:10:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"WPTavern: WordPress 4.9.3 Rescheduled for February 5th\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78058\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wptavern.com/wordpress-4-9-3-rescheduled-for-february-5th\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1336:\"<p>WordPress 4.9.3 is a maintenance release and was originally scheduled to be available on January 30th. However, due to ongoing tickets and a short time frame to test the <a href=\"https://make.wordpress.org/core/2018/02/01/wordpress-4-9-3-rc/\">release candidate</a>, it has <a href=\"https://make.wordpress.org/core/2018/01/31/wordpress-4-9-3-release-pushed-to-february-5th/\">been pushed back</a> to February 5th.</p>
<p><a href=\"https://make.wordpress.org/core/2018/02/01/wordpress-4-9-3-rc/\">WordPress 4.9.3 RC 1</a> is available for testing. This release <a href=\"https://make.wordpress.org/core/2018/01/24/jshint-removed-from-codemirror-in-4-9-3/\">removes JSHint from the code editors</a> due to conflicts with the GPL License. If your code relies on JSHint from Core, <a href=\"https://core.trac.wordpress.org/ticket/42850\">developers encourage</a> you to update it to use a copy of JSHint.</p>
<p>Other changes in 4.9.3 include, avoiding page scrolling when navigating the media modal, a handful of improvements to the customizer, <a href=\"https://make.wordpress.org/core/2018/01/26/wordpress-4-9-3-beta/\">and more</a>. Please test WordPress 4.9.3 on a staging site and if you encounter any bugs, you can report them on the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta section</a> of the support forums.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 02 Feb 2018 08:09:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"WPTavern: WooCommerce 3.3 Removed From Plugin Directory Due to Theme Conflicts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77962\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"https://wptavern.com/woocommerce-3-3-removed-from-plugin-directory-due-to-theme-conflicts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3081:\"<p>Earlier this week, WooCommerce 3.3 <a href=\"https://wptavern.com/woocommerce-3-3-increases-theme-compatibility-auto-regenerates-thumbnails\">was released</a> and among the features was increased theme compatibility. However, soon after release, users of third-party themes <a href=\"https://wordpress.org/support/topic/wc-3-3-issues-with-categories-displaying-in-shop/\">reported issues</a> with categories displaying improperly.</p>
<p>Despite it being a minor release that should be fully backwards compatible with previous releases up to 3.0, WooCommerce has removed 3.3 from the plugin directory and replaced it with 3.2.6.</p>
<p>According <a href=\"https://woocommerce.wordpress.com/2018/02/01/woocommerce-3-3-1-status-update/\">to a post</a> on the project&#8217;s official blog, WooCommerce 3.3.1 will take the place of 3.3 and will include a fix for the category display issue.</p>
<blockquote class=\"wp-block-quote\"><p>The issue affected themes with template overrides from 3.2.x which hadn’t been made compatible with 3.3. In general, <a href=\"https://github.com/woocommerce/woocommerce/wiki/Template-File-Guidelines-for-Devs-and-Theme-Authors#hook-vs-override---when-to-use-what\">we recommend that themes use hooks instead of template overrides.</a> Themes such as <a href=\"https://en-gb.wordpress.org/themes/storefront/\">Storefront</a> (which does not use template overrides) were compatible at launch.</p>
<p><cite>WooCommerce Blog</cite></p></blockquote>
<p>If you&#8217;ve already updated to WooCommerce 3.3 and your theme is compatible, you don&#8217;t need to make any changes. If your theme is not compatible, WooCommerce recommends checking with your theme&#8217;s author to see if a compatibility fix has been released.</p>
<p>Users can also wait for the release of 3.3.1, update to the <a href=\"https://github.com/woocommerce/woocommerce/releases/tag/3.3.1-rc.1\">pre-release version</a> of 3.3.1, or use the <a href=\"https://wordpress.org/plugins/wp-rollback/\">WP-Rollback plugin</a> and revert back to 3.2.6. WooCommerce developers suggest only going the WP-Rollback route if you&#8217;re not comfortable installing pre-release software.</p>
<p>Coen Jacobs, a former member of the WooCommerce development team, commented on Twitter that this was the first time he can remember that a release was reverted.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Fun fact: As far as I recall, there has never been a release of WooCommerce that has been withdrawn before. During my time on the development team we have pushed fix releases on the same day as a big releases, but never was it reverted like this.</p>
<p>&mdash; Coen Jacobs (@CoenJacobs) <a href=\"https://twitter.com/CoenJacobs/status/958768816808497152?ref_src=twsrc%5Etfw\">January 31, 2018</a></p></blockquote>
<p></p>
<p>The development team has tested 3.3.1 with more than 40 different themes and believe it is stable. However, they are exercising caution and thoroughly testing the fixes with more themes. Users can expect to see 3.3.1 officially released the week of February 5th.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 02 Feb 2018 07:06:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"WPTavern: WPWeekly Episode 303 – Interview With Zac Gordon, Technology Educator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=77901&preview=true&preview_id=77901\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"https://wptavern.com/wpweekly-episode-303-interview-with-zac-gordon-technology-educator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1902:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I are joined by <a href=\"http://zacgordon.com/\">Zac Gordon</a>. We discussed a wide range of topics including, balancing freelance work with educating, an overview of Gutenberg from an educator&#8217;s perspective, and potential brand issues if the Gutenberg name <a href=\"githubhttps://github.com/WordPress/gutenberg/issues/4681\">was deprecated</a>. We also talked about some of the difficulties involved with <a href=\"https://gutenberg.courses/\">creating a course</a> around a feature that&#8217;s not yet part of WordPress core.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://ithemes.com/2018/01/31/ithemes-joining-the-liquid-web-family/\">iThemes Acquired by LiquidWeb</a><br />
<a href=\"https://woocommerce.com/2018/01/whats-new-woocommerce-3-3/\">WooCommerce 3.3 Released</a><br />
<a href=\"https://wptavern.com/updraftplus-acquires-easy-updates-manager-plugin\">Easy Updates Manager Acquired by UpdraftPlus</a></p>
<h2>Picks of the Week:</h2>
<p>John James Jacoby suggested <a href=\"https://www.beamauthentic.com/\">Beam Authentic</a>. Beam Authentic is a wearable, connected, smart button that can be programmed to display different images through an app.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, February 7th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #303:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Feb 2018 02:12:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"WPTavern: Efrain Rivera, A Longtime Community Member, WordCamp Organizer, and Volunteer, Passes Away\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77893\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"https://wptavern.com/efrain-rivera-a-longtime-community-member-wordcamp-organizer-and-volunteer-passes-away\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2776:\"<p>Efrain Rivera, who helped organize and volunteer at numerous WordCamps in Florida has passed away at the age of 47. The news was shared on Facebook by his sister on January 28th.</p>
<img />Efrain Rivera and his wife at WordCamp Miami. Photo courtesy of David Bisset
<p>David Bisset, organizer of WordCamp Miami and a well-known figure in the Florida WordPress community, <a href=\"http://davidbisset.com/efrain-rivera/\">shared his thoughts</a> on Rivera&#8217;s passing.</p>
<blockquote><p>Efrain wasn’t just a fellow organizer, but also a supporter of the local WordPress meetups. There was no ulterior motive in anything that he did. Never once did he ask for anything – he was just happy to be there and help out. He was 100% about giving back to the WordPress community, but even if the community didn’t exist he would find a way to help out folks.</p>
<p>Efrain wasn’t just a supporter and volunteer. He was a good friend to have – someone you could speak frankly too.</p></blockquote>
<p>Rivera is being remembered as a kind, compassionate, and happy person by members of the community.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">I’m so sorry, he was a pleasure volunteering with,  <a href=\"https://twitter.com/EfrainWp?ref_src=twsrc%5Etfw\">@EfrainWp</a> was always happy to help and answer questions.</p>
<p>&mdash; Rian M. Kinney, Esq. (@TheKinneyFirm) <a href=\"https://twitter.com/TheKinneyFirm/status/958855848784252928?ref_src=twsrc%5Etfw\">February 1, 2018</a></p></blockquote>
<p></p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">I remember his kindness David. What a great person and sad loss.</p>
<p>&mdash; Diane Kinney (@dkinney) <a href=\"https://twitter.com/dkinney/status/958858994843611138?ref_src=twsrc%5Etfw\">February 1, 2018</a></p></blockquote>
<p></p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Efrain was one of happiest, smiliest, caring people I’d ever hung out with at any WordPress event. <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f64f.png\" alt=\"🙏\" class=\"wp-smiley\" /> <a href=\"https://t.co/qW7ChUmjX0\">https://t.co/qW7ChUmjX0</a></p>
<p>&mdash; J ³ (@JJJ) <a href=\"https://twitter.com/JJJ/status/958448885030182913?ref_src=twsrc%5Etfw\">January 30, 2018</a></p></blockquote>
<p></p>
<p><a href=\"https://memorials.serenitymemorialchapels.com/efrain-rivera/3417849/obituary.php\">Memorial services are scheduled</a> for Saturday, February 3, 2018 from 4:00 P.M.-9:00 P.M. EST at Serenity Funeral Home and Cremation, 1450 S State Road 7, North Lauderdale, Florida 33068. The service will take place during visitation at 7PM. If you have any memories of meeting or hanging out with Efrain at any of the WordPress events in Florida, please share them in the comments.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Feb 2018 01:13:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"Post Status: Liquid Web has acquired iThemes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=41738\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://poststatus.com/liquid-web-acquired-ithemes/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5096:\"<p><a href=\"https://www.liquidweb.com/\">Liquid Web</a> has acquired <a href=\"https://ithemes.com/\">iThemes</a>, in an all cash deal that includes the entire iThemes team moving over to Liquid Web as an independent unit. Cory Miller &#8212; CEO of iThemes &#8212; will be the Business Manager of the new unit, with iThemes COO Matt Danner as the Director of Technology and Operations for iThemes. The entire team of twenty three people is staying on, and will continue to be headquartered in Oklahoma.</p>
<p>This is not the first or last time we&#8217;ll see longstanding WordPress companies get rolled into large hosting providers. It&#8217;s a trend that is natural in any ecosystem as it matures, and iThemes was a clear and quality candidate for a host to target. Cory said the culture around Liquid Web, including their &#8220;heroic support,&#8221; but also the quality he sees in their management team, was a key motivator for them to go work with Liquid Web.</p>
<p>As hosting companies evolve more and more to provide broader services for customers with managed WordPress offerings, there is less room for utility product creators to fill that gap.</p>
<p>Backups are a fine example: customers may see less need for external backups if they have confidence that their hosting is managing backups properly. Security is another. These have been great products for iThemes, and still are &#8212; but their current markets are more for hosts without a managed experience, and that slice of the pie has been narrowing.</p>
<p>iThemes has had a partnership with Liquid Web for about a year and a half now, which started by licensing iThemes Sync for Liquid Web&#8217;s WordPress hosting offering. They&#8217;ve slowly been integrating more features into the platform, and the acquisition will allow Liquid Web to further integrate iThemes&#8217; offerings, and allow iThemes to improve some of their product offerings with the backing of Liquid&#8217;s Web&#8217;s hosting infrastructure.</p>
<p>I spoke to Cory Miller about the move, which is occurring not long after iThemes&#8217; ten year anniversary in business. He said he looks back every year and sees them as chapters in the iThemes story, and this feels just the same. He&#8217;s excited about what the backing from Liquid Web will allow them to do, and most importantly for him, the ability to keep supporting the team they have built over the years.</p>
<p>Cory tells me he&#8217;s amazed that they&#8217;ve been able to build the company they have built, and neither he nor his business partners would have imagined it ten years ago. All equity holders had their shares purchased by Liquid Web, and Cory and the team will be Liquid Web employees.</p>
<p>iThemes has iterated on the business many times over the years &#8212; as the name implies. Their theme business slowly dwindled in terms of the overall ratio of sales revenue it provided. BackupBuddy has long been a flagship, and they&#8217;ve found great success the past couple of years since they acquired and iterated on the iThemes Security product. He said that it took them experimenting a great deal &#8212; and like Exchange for eCommerce, and others &#8212; it didn&#8217;t always work out the way they hoped. But because they stayed agile and kept working at it, they&#8217;ve consistently been able to grow and diversify their product line.</p>
<p>One practical component Liquid Web will be able to provide, as an example, is their data centers to power BackupBuddy and iThemes Stash storage and processing. iThemes has historically used Amazon, which Cory said really adds up and has started to eat into their own margins. Liquid Web will help them not only improve the offering but also to be able to perform those functions more affordably.</p>
<p>For Liquid Web, this acquisition furthers their goal to integrate WordPress-specific functionality into their suite of WordPress hosting tools. They recently launched WooCommerce hosting on their platform, and the iThemes Sales Accelerator product can now be a core component of that offering. Additionally, the technology iThemes has built with BackupBuddy and Sync will further add to their platform.</p>
<p>Beyond the technology and products, Liquid Web Vice President of Products and Innovation Chris Lema tells me it&#8217;s about the team:</p>
<blockquote><p>This adds so much to what we’re doing with managed WordPress and managed WooCommerce, that it just made a lot of sense — both from a product perspective, and even more from a team perspective.</p></blockquote>
<p>Having spent a lot of time with the management teams for each of these companies, I would agree that the culture fit is a really good one. And for Liquid Web, a company continuing to make its big push into the WordPress market, it is a solid strategic acquisition move that offers product dividends but more importantly adds a great and experienced WordPress team to their company.</p>
<p><a href=\"https://ithemes.com/2018/01/31/ithemes-joining-the-liquid-web-family/\">Cory shares more</a> about the news on the iThemes blog.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 31 Jan 2018 17:12:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"HeroPress: The Journey: Curiosity, Challenge, Transformation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2431\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:158:\"https://heropress.com/essays/journey-curiosity-challenge-transformation/#utm_source=rss&utm_medium=rss&utm_campaign=journey-curiosity-challenge-transformation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9293:\"<img width=\"960\" height=\"480\" src=\"https://heropress.com/wp-content/uploads/2018/01/013118-2-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: My place in the world has transformed.\" /><p>When I look back on the past five years I’ve been working with WordPress, I feel the real weight of the journey I’ve had to get where I am. Much of it has been filled with challenge of both of the difficult and welcome variety. I’m an optimist and problem-solver to the core, but I sometimes wonder how I got through these past years. One thing is for certain, my involvement with WordPress, the opportunities and community around it, has been a force for so much good, motivation, and satisfaction in my life.</p>
<h2>The Beginning</h2>
<p>When I was introduced to WordPress, I was going through one of the most trying times of my adult life. My dad had suddenly passed away just a few years before. We didn’t have the best relationship, but his quirkiness, interest in esoteric things, and passion for food certainly rubbed off on me.</p>
<p>I was living with roommates, but moved back home to be with my mom. Not too long after, she developed debilitating osteoarthritis in both of her hips. From a physically healthy yet grieving 52-year-old woman to eventually becoming handicap and walker-bound, needless to say, impacted our lives greatly. I became her caretaker, and I also worked retail part-time for the flexible schedule.</p>
<blockquote><p>I felt emotionally exhausted, uninspired and quite lost with what my next steps would be.</p></blockquote>
<p>I grew up using the internet fervently as a youth and in my college years. I met new friends, learned new skills, and traveled to new places thanks the endless source of information it provided for my active mind. So when a friend, now my mentor, John Bolyard, approached me to help him in his web marketing and development consultancy using “WordPress” I just said “yes.” It was mysterious, being unknown to me, and intriguing, which is usually a green light in my book!</p>
<p>I started doing administrative work on a website he helped develop for a national guild. Like many situations, he had finished their website and they would circle back to him for minor updates. I took on the minor updates, started tinkering on my own, and fell in love in the process.</p>
<p>The accessibility with which one could make changes and produce content dynamically was just mind blowing to me. It was my gateway to web development and now I could make web content with the ability to work with code, if I so chose. It seemed an endless source of learning and knowledge- it was a great fit.</p>
<h2>Levelling Up</h2>
<p>That went well and he brought me on a larger project to help the artist, Dorothy Braudy, create her website archive. I was able to blend my affinity for the technical and handy visual memory to help an all around amazing person (she&#8217;s still one of closest people in my life) tell her story through her art. I was thrilled to have the challenge and the privilege to bring her vibrant and prolific work (hundreds of pieces) to the web.</p>
<p>I also started assisting John with teaching WordPress classes at SCORE, a government organization that helps people develop and sustain small businesses.</p>
<blockquote><p>We volunteered our time teaching business owners WordPress to help them build their own websites.</p></blockquote>
<p>It was challenging yet rewarding to see them feel empowered that they could take a hands-on role in making their web presence.</p>
<p>Nevertheless, I ended up with several clients and that’s how my freelancing career began :). I also started going to meetups. John brought me to my first one in the San Fernando Valley. I was like wait&#8230;this software is cool and people gather to talk about it? I can also learn stuff too?! Get outta town!</p>
<p>Well, I started attending fairly frequently. Particularly, the meetup in the West Valley lead by Andrew Behla (then at the Topanga Canyon Library). I soaked up info from presentations given by Roy Sivan, Suzette Franck, and Lucy Beer (who is now my teammate). Just to name a few ;).</p>
<p>After building a consistent client base, I also started working part-time as a project assistant at a boutique museum exhibit development firm. My first project was for the Huntington Library, Art Collections and Botanical Gardens supporting the development of an educational WordPress website for their Junípero Serra exhibition. What were the chances? My skills in WordPress proved helpful for the project and the firm&#8217;s website.</p>
<h2>Pivoting</h2>
<p>At this point, I had seen my mom through her first hip replacement and recovery, and she was moving on to her next one. I thought about where I saw myself and also where I could build a sustainable future given the circumstances. I thought WordPress, and so I did a trial as a Happiness Engineer at WordPress.com.</p>
<p>While I didn&#8217;t get the position, I met some great people and learned exponentially more in that short time than I had on my own. More so, I learned about the users, WordPress’ strengths and weaknesses, and how to fill that gap in an accessible way. I was sad, but also motivated. I took on more client work and just did the thing.</p>
<p>After three years, it was time to leave the exhibit development firm. It was fascinating, it provided me a design, development and project management vocabulary I had never encountered before. However, I needed a firmer career path and I still thought WordPress. My mom was recovered, I had also just recovered from some health issues, and I knew it was time for a change.</p>
<p>While doing client work for several months, I also explored options on how I could &#8220;level up.&#8221; Maybe it was my time to dig into web development: should I learn on my own, go to a school?</p>
<blockquote><p>In my gut, I knew I had to find work that supported my endeavors, so I started applying in the WordPress and tech ecosystem.</p></blockquote>
<p>I networked, attended workshops, and met some awesome folks in the local tech and WordPress communities. I was also approached about joining the organizer team for WordCamp Los Angeles (WCLAX). I said “yes” (that magic word) and last year we had a great event.</p>
<p>When we started planning, I had also heard from WP Media, (the company behind the WP Rocket and Imagify plugins), that I was hired for their Customer Support position. We’re a remote crew spread across 8 countries. However, I’ve been lucky enough to spend time with them at WordCamp Europe, WordCamp US, and our annual retreat last year.</p>
<h2>Transformation</h2>
<p>My place in the world has transformed. I&#8217;ve traveled to places once out of reach, work every day with some of the most brilliant and kind people in the WordPress space, and grow day by day with new challenges and opportunities. I&#8217;m happy, mom is healthy, and the journey continues…</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: The Journey: Curiosity, Challenge, Transformation\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=The%20Journey%3A%20Curiosity%2C%20Challenge%2C%20Transformation&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fjourney-curiosity-challenge-transformation%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: The Journey: Curiosity, Challenge, Transformation\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fjourney-curiosity-challenge-transformation%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fjourney-curiosity-challenge-transformation%2F&title=The+Journey%3A+Curiosity%2C+Challenge%2C+Transformation\" rel=\"nofollow\" target=\"_blank\" title=\"Share: The Journey: Curiosity, Challenge, Transformation\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/journey-curiosity-challenge-transformation/&media=https://heropress.com/wp-content/uploads/2018/01/013118-2-150x150.jpg&description=The Journey: Curiosity, Challenge, Transformation\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: The Journey: Curiosity, Challenge, Transformation\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/journey-curiosity-challenge-transformation/\" title=\"The Journey: Curiosity, Challenge, Transformation\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/journey-curiosity-challenge-transformation/\">The Journey: Curiosity, Challenge, Transformation</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 31 Jan 2018 11:00:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Renee Johnson\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: WooCommerce 3.3 Increases Theme Compatibility, Auto Regenerates Thumbnails\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77795\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"https://wptavern.com/woocommerce-3-3-increases-theme-compatibility-auto-regenerates-thumbnails\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3108:\"<p>WooCommerce 3.3 <a href=\"https://woocommerce.com/2018/01/whats-new-woocommerce-3-3/\">is available</a> and is considered a minor release. Based on the project’s <a href=\"https://github.com/woocommerce/woocommerce/wiki/Roadmap-and-release-process\">new release process</a>, it should be fully backwards compatible with previous releases up to 3.0.</p>
<p>The orders screen has been redesigned with large buttons that indicate an order’s status. You can also view an order’s details from the order screen without having to edit the order.</p>
<img class=\"aligncenter\" src=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2018/01/WC33OrdersScreen.png?w=627&ssl=1\" alt=\"\" width=\"627\" height=\"261\" />WooCommerce 3.3 Orders Screen
<p>For products that are on backorder and have stock management enabled, WooCommerce 3.3 will automatically transition from ‘In stock’ to ‘On backorder’ or ‘Out of stock’ as the inventory decreases. Once inventory is added, the status will switch back to ‘In Stock’.</p>
<img class=\"aligncenter\" src=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2018/01/WC33OrderStatus.png?w=627&ssl=1\" alt=\"\" width=\"627\" height=\"328\" />WooCommerce 3.3 Order Status Screen
<p>For full compatibility, users generally needed to use a WordPress theme that specifically supported WooCommerce. In 3.3, improvements have been made so that WooCommerce renders on themes that don’t fully support it, making it compatible with nearly every WordPress theme.</p>
<p>Users can now set the number of columns and rows for shops with the ability to preview the results live via the Customizer. The columns will resize to fill the entire width of the area and is available on all themes.</p>
<p>In earlier versions of WooCommerce, shop owners needed to use the <a href=\"https://wordpress.org/plugins/regenerate-thumbnails/\">Regenerate Thumbnails</a> after updating a product’s image as WordPress did not automatically resize the image and generate new thumbnails. WooCommerce 3.3 adds on-the-fly thumbnail regeneration and background thumbnail resizing.</p>
<p>In addition, users can customize the aspect ratios of product images. The choices are classic square images, custom cropped images, or uncropped images</p>
<img class=\"aligncenter\" src=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2018/01/WC33ImageAspectRatio.png?w=627&ssl=1\" alt=\"\" width=\"627\" height=\"402\" />WooCommerce 3.3 Image Aspect Ratio Options
<p>Shop owners can now view logs of product downloads with a couple of built-in filters including, by order, by product, by customer, and by file. You can also search for extensions now from the Extensions administration screen.</p>
<p>WooCommerce 3.3 includes more features and changes than what’s listed here. For a detailed overview of what’s new in 3.3, <a href=\"https://github.com/woocommerce/woocommerce/blob/release/3.3/readme.txt\">check out the changelog</a>. If you think you’ve discovered a bug, please report it on the <a href=\"https://github.com/woothemes/woocommerce/issues\">project’s GitHub page</a>.</p>
<p><!-- /wp:core/paragraph --></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 30 Jan 2018 22:53:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"Mark Jaquith: Simple WordPress deploys using Git\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://markjaquith.wordpress.com/?p=5422\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"https://markjaquith.wordpress.com/2018/01/30/simple-wordpress-deploys-using-git/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3328:\"<p>A few weeks back, Clifton Griffin asked me a question about deploying WordPress sites:</p>
<div class=\"embed-twitter\">
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\"><a href=\"https://twitter.com/markjaquith?ref_src=twsrc%5Etfw\">@markjaquith</a> Hey Mark, quick question: Do you still use and recommend Capistrano?</p>
<p>&mdash; Clifton Griffin (@clifgriffin) <a href=\"https://twitter.com/clifgriffin/status/948373150680707073?ref_src=twsrc%5Etfw\">January 3, 2018</a></p></blockquote>
<p></div>
<p>I <b>do not</b> use Capistrano for deployments anymore, for one simple reason: it was massive overkill for most of the sites I manage, and maintaining it was not worth the benefit.</p>
<p>My current deployment system for WordPress sites is simple: I use Git.</p>
<p>I&#8217;m already using Git for version control of the site&#8217;s code, so using Git for deployments is not that much more work. There are a few ways to do this, but the simplest way is to just make your site root a Git checkout of your site files.</p>
<p>Then, if your server has read-access to your Git remote, you can run some Git commands to sync everything. Here are your options:</p>
<ol>
<li><strong>git pull</strong> — Simple, but might fail if someone naughty has made code modifications on the server.</li>
<li><strong>git fetch &amp;&amp; git reset &#8211;hard origin/master</strong> — The hard reset method will wipe any local modifications that someone has mistakenly made.</li>
</ol>
<p>But wait. Before you implement this, it is very important that you ensure that your server&#8217;s <strong>.git</strong> directory is not readable, as it might be able to leak sensitive information about your site&#8217;s code. How you do this will depend on what web server you&#8217;re running. In Nginx, I do the following:</p>
<pre class=\"brush: plain; title: ; notranslate\">location ~ /\\.(ht[a-z]+|git|svn) {
deny all;
}</pre>
<p>In Apache, you could put the following in your <strong>.htaccess</strong> file:</p>
<pre class=\"brush: plain; title: ; notranslate\">RedirectMatch 404 /\\.git</pre>
<p>SSHing into your server every time is tedious, so let&#8217;s script that:</p>
<pre class=\"brush: bash; title: ; notranslate\">#!/bin/bash
ssh example.com \'cd /srv/www/example.com &amp;&amp; git pull\'</pre>
<p>Save that to <strong>deploy.sh</strong> in your Git repo, run <strong>chmod +x deploy.sh</strong>, and commit it to the repo. Now when you&#8217;re ready to deploy the site, just type <strong>./deploy.sh</strong> and the public site will pull down the latest changes from your main Git remote.</p>
<p>Bonus points if you make <strong>deploy.sh</strong> take an optional commit hash, so you can also use this tool to roll back to a previous hash, in case a commit goes wrong.</p>
<p>This method has served me well, for years, and has required no maintenance.</p>
<p>What methods are you using for WordPress code deploys?</p>
<hr />
<p><b>Do you need <a href=\"https://coveredwebservices.com/\">WordPress services?</a></b></p>
<p>Mark runs <a href=\"https://coveredwebservices.com/\">Covered Web Services</a> which specializes in custom WordPress solutions with focuses on security, speed optimization, plugin development and customization, and complex migrations.</p>
<p>Please reach out to start a conversation!</p>
[contact-form]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 30 Jan 2018 15:31:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mark Jaquith\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"WPTavern: UpdraftPlus Acquires Easy Updates Manager Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77700\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wptavern.com/updraftplus-acquires-easy-updates-manager-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2048:\"<p><a href=\"https://updraftplus.com/\">UpdraftPlus</a>, a popular WordPress backup plugin actively installed on more than 1 million sites has acquired the <a href=\"https://wordpress.org/plugins/stops-core-theme-and-plugin-updates/\">Easy Updates Manager</a> plugin for an undisclosed amount.</p>
<p>Easy Updates Manager disables core, theme, and plugin updates in WordPress and provides granular control over them. It was created in 2015, is actively installed on more than 100K sites, and is maintained by <a href=\"https://profiles.wordpress.org/kidsguide/\">Matthew Sparrow</a>, <a href=\"https://profiles.wordpress.org/ronalfy/\">Ronald Huereca</a>, <a href=\"https://profiles.wordpress.org/roary86/\">Roary Tubbs</a>, and <a href=\"https://profiles.wordpress.org/bigwing/\">BigWing Interactive</a>.</p>
<img />Easy Updates manager User Interface
<p>Burnout was a contributing factor for selling the plugin. &#8220;Matthew Sparrow and I were both burnt out on the project, so the offer to sell was a no-brainer,&#8221; Huereca said. &#8220;It’s bittersweet letting our baby go, but it’s in good hands.&#8221;</p>
<p>Without proper vetting, selling established plugins to individuals or companies can be harmful to sites and tarnish its reputation. Because UpdraftPlus is a well established company, Huereca didn&#8217;t have to do a lot of research.</p>
<p>&#8220;We were looking for more backend plugins that we understand and it&#8217;s a great plugin, highly rated and growing,&#8221; A company representative said. &#8220;Updates and backups go hand-in-hand as people should really backup before updating.&#8221;</p>
<p>UpdraftPlus will focus its marketing efforts towards <a href=\"https://updraftplus.com/updraftcentral/\">UpdraftCentral</a> later this year. UpdraftCentral provides the ability for users to update, backup, and manage their sites from one dashboard. Easy Updates Manager and UpdraftCentral are complimentary products.</p>
<p>Users can expect to see more updates later this year and continued refinement of the user interface.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 30 Jan 2018 00:30:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"BuddyPress: BuddyPress 2.9.3 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=270325\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://buddypress.org/2018/01/buddypress-2-9-3-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1312:\"<p>BuddyPress 2.9.3 is now available. This is a security and maintenance release. We strongly encourage all BuddyPress sites to upgrade as soon as possible.</p>
<p>The 2.9.3 release addresses two security issues:</p>
<ul>
<li>A dynamic template loading feature could be used in some cases for unauthorized file execution and directory traversal. Reported by <a href=\"https://pritect.net\">James Golovich</a>.</li>
<li>Some permissions checks and path validations in the attachment deletion process were hardened. Reported by <a href=\"https://www.ripstech.com/\">RIPSTech</a> and <a href=\"https://profiles.wordpress.org/slaFFik/\">Slava Abakumov</a> of the BuddyPress security team.</li>
</ul>
<p>These vulnerabilities were reported privately to the BuddyPress team, in accordance with <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">WordPress&#8217;s security policies</a>. Our thanks to all reporters for practicing coordinated disclosure.</p>
<p>In addition, 2.9.3 includes a change that fixes the ability to install legacy bbPress 1.x forums. Please note that legacy forum support will be removed altogether in BuddyPress 3.0; see <a href=\"https://bpdevel.wordpress.com/2017/12/07/legacy-forums-support-will-be/\">the announcement blog post</a> for more details.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 26 Jan 2018 18:11:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Boone Gorges\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"Post Status: WordPress Market Opportunities — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=41485\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://poststatus.com/wordpress-market-opportunities-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2459:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p>In this episode, Brian and Brian discuss market segmentation across the WordPress ecosystem. The focus for this discussion focused entirely on the entry-level segment of site assemblers and their small-business clients as well as the mid-level market of contractors and agencies selling additional levels of service. The duo talked through a few different strategies employed in each segment, including service differentiation, regional focus, building a network of complementary contractors, systemizing processes, delivering quality customer support flow, and selling ongoing service.</p>
<p>In addition to this look at market segmentation, the Brians shared a few useful resources for both Gutenberg and WP-CLI.</p>
<p></p>
<h3>Links</h3>
<ul>
<li>Mike McAlister&#8217;s <a href=\"http://gutenberg.news/\">Gutenberg News</a></li>
<li>Ahmed Awais&#8217;s <a href=\"https://github.com/ahmadawais/create-guten-block\">create-gutenberg-block</a></li>
<li>Delicious Brain&#8217;s <a href=\"https://deliciousbrains.com/wordpress-cli-packages-review/\">WP-CLI packages reviews</a></li>
<li>WordPress Website: <a href=\"https://poststatus.com/wordpress-website-cost/\">How much should it cost?</a></li>
<li><a href=\"https://wpsessions.com/sessions/selling-ongoing-service/\">Selling Ongoing Services with Sara Dunn</a></li>
</ul>
<h3>Sponsor: iThemes</h3>
<p>This episode is sponsored by <a href=\"https://ithemes.com/?utm_source=post_status&utm_medium=banner&utm_campaign=ps_ads\">iThemes</a>. The team at iThemes offers WordPress plugins, themes and training to help take the guesswork out of building, maintaining and securing WordPress websites. For more information, check out their <a href=\"https://ithemes.com/?utm_source=post_status&utm_medium=banner&utm_campaign=ps_ads\">website</a> and thank you to iThemes for being a Post Status partner.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 26 Jan 2018 16:50:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: WPWeekly Episode 302 – Brian Gardner, Founder of StudioPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=77689&preview=true&preview_id=77689\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://wptavern.com/wpweekly-episode-302-brian-gardner-founder-of-studiopress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1338:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I are joined by <a href=\"https://briangardner.com/\">Brian Gardner</a>, founder of <a href=\"https://www.studiopress.com/\">StudioPress</a>. We talk about the past, present, and future of the company including various milestones such as the Genesis framework and merger with CopyBlogger Media in 2010. We also discuss the community surrounding StudioPress&#8217; products and the role it plays in the company&#8217;s continued success.</p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://wptavern.com/new-toolkit-simplifies-the-process-of-creating-gutenberg-blocks\">Ahmad Awais Create Guten Block toolkit</a>.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, January 31st 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #302:</strong> </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 26 Jan 2018 04:15:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"WPTavern: WordPress Turns 15 Years Old\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77652\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://wptavern.com/wordpress-turns-15-years-old\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1120:\"<p><!-- wp:core/paragraph --><br />
WordPress, the free open source project, <a href=\"https://ma.tt/2003/01/the-blogging-software-dilemma/\">turns 15 years</a> old today. Here is the comment that started it all.<br />
<!-- /wp:core/paragraph --></p>
<p><!-- wp:core/image {\"id\":51095} --></p>
<img src=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2016/01/MikeLittleForkB2Comment.png?w=627&ssl=1\" alt=\"Mike Little&#x27;s Comment\" />Mike Little&#x27;s Comment
<p><!-- /wp:core/image --></p>
<p><!-- wp:core/paragraph --><br />
In addition to celebrating 15 years as a successful software project, it&#x27;s also a good opportunity to reflect on the number of people across the world who are making a great living and <a href=\"http://heropress.com/\">turning dreams into reality</a> thanks to the project.<br />
<!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --><br />
Thank you Matt Mullenweg and Mike Little for creating WordPress, its contributors for keeping the ball rolling all these years, and providing opportunities for so many people. Happy birthday WordPress!<br />
<!-- /wp:core/paragraph --></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 26 Jan 2018 03:41:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: WordCamp Miami Celebrates Its 10th Consecutive Year March 16-18\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77595\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wptavern.com/wordcamp-miami-celebrates-its-10th-consecutive-year-march-16-18\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3689:\"<p><!-- wp:core/paragraph --></p>
<p><a href=\"https://2018.miami.wordcamp.org/\">WordCamp Miami</a> is celebrating its 10th anniversary on March 16-18th. This year&#x27;s event is organized by twelve people and organizers expect more than 800 people to attend. Speakers will arrive from Italy, Germany, London, Brazil, and other international locations to share their knowledge.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>In addition to a <a href=\"https://2018.miami.wordcamp.org/kids/\">two-day Kids Camp</a> with a Kids Panel, WordCamp Miami will feature two new workshops. The first is developer focused and will prepare developers for <a href=\"https://2018.miami.wordcamp.org/2017/12/19/developer-workshop-announcement-future-of-wordpress/\">the future of WordPress</a>. The second is <a href=\"https://2018.miami.wordcamp.org/2017/12/21/ecommerce-workshop-coming-to-wcmia/\">focused on eCommerce</a>.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>Attendees will receive their own site and be able to apply what they&#x27;ve learned to it. The sites will have pre-installed plugins and access to various tools mentioned by the workshop teachers.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>The &#x27;Learn JavaScript Deeply&#x27; track is returning this year, featuring local and international JavaScript developers. This is the third time WordCamp Miami has had this track and according to David Bisset, one of the organizers, the focus will be on JavaScript basics, React, plus using JavaScript to create &#x27;cool and unique&#x27; projects with or without WordPress.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>Joshua Strebel, Syed Balkhi, and Christie Chirinos will highlight Saturday&#x27;s business track. </p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>For the first time in recent years, WordCamp Miami will have a closing keynote on Saturday, March 17th by John James Jacoby. Jacoby was one of the founders of WordCamp Miami a decade ago, and his talk will cover both nostalgic moments and what the future of WordPress holds for users.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>Finally, WordCamp Miami will be doing a &#x27;game show hour&#x27; before the official after party. \"We wanted to do something fun and interactive for everyone &#8211; and we think we found a great way to segue people from the talks to unwinding at the after party,\" Bisset explained. </p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>\"We are even planning on having our sponsors form teams in a trivia contest battle. There will be provisions at the party for those who want to network or just relax in a quiet setting.\"</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>Bisset praised volunteers and organizers for helping make 10 years of WordCamp Miami a reality.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>\"Each and every one of our organizers and speakers deserve a huge amount of thanks and praise for their hard work.\" He said. \"We couldn&#x27;t have done ten years without the support of the WordPress community.\"</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>Tickets are <a href=\"https://2018.miami.wordcamp.org/tickets/\">on sale</a> with a number of purchasing options. Workshops cost $15 each and general admission tickets are $40 each. General admission tickets provide access to Saturday and Sunday sessions, lunch, swag, and the after party. </p>
<p><!-- /wp:core/paragraph --></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 25 Jan 2018 01:56:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"HeroPress: Believe In Yourself\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2420\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:112:\"https://heropress.com/essays/believe-in-yourself/#utm_source=rss&utm_medium=rss&utm_campaign=believe-in-yourself\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:10510:\"<img width=\"960\" height=\"480\" src=\"https://heropress.com/wp-content/uploads/2018/01/012418-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: Working in WordPress has allowed my curiosity to run wild.\" /><p>You ever have a moment where you blink your eyes and you wonder how you’ve gotten to where you are today? I’m having one of those moments right now as I sit here to share my story with you. It’s bizarre to think of how far I’ve come because I truly thought that I was not good enough to be where I am today. Let’s get into it.</p>
<h3>The Beginning</h3>
<p>As a child, I was always around technology. My dad was a computer scientist and considered it a great idea to get each of his four children their own computer so they would stay away from his. So as the years went by with system administrative tasks being “one of the hard-knocks of life”, I went off to Drexel University in 2005 to pursue a degree in Computer Science. I remember when I walked into my first class and instantly saw how different I was. Everyone was white. Everyone was male. And I was not. In fact, I couldn’t even check off one of those boxes. I was opposite. I was female and I was black.</p>
<p>The first year pursuing my degree actually went really well and finished off the year, completing my C++ final project to create a matching cards game using objects and classes. All was swell. I found that I was doing just as well as everyone else. And I found that was struggling in certain areas just like everyone else.</p>
<h3>Leaning In</h3>
<p>Next semester came and that’s when the more difficult course load began. There was one class in particular called “Data Algorithms &amp; Theories” that was incredibly and frustratingly difficult. As someone who always wanted to do well and is inclined to beat herself up for not being “perfect”, it was an incredibly stressful time for me. But once again, I was not the only one who was struggling because the class was difficult for all of my classmates. But as the class progressed, I decided to step out of my comfort zone and ask for help. This was the first time I would actually utilize the teaching assistant (TA) that was often present during this class. So our scheduled meeting comes around and it doesn’t go as I’d hoped. It wasn’t at all a welcoming atmosphere.</p>
<blockquote><p>The demeanor of the TA made it clear that he didn’t want to be there but my happy-go-lucky personality brushed it aside.</p></blockquote>
<p>To make things worse, I wasn’t understanding the “simple” concepts that he was explaining and was subject to the TA’s dismissive glances of judgement and shame. I remember at one point, my mind shifted into trying to make him like me rather than realize that he was discriminating against me. Then he said to me “You know, maybe this just isn’t for you. I’ve explained this to you multiple times and you’re just not getting.” This was a very upsetting moment in my life because someone who was supposed to be helping me learn was telling me that you’re too stupid to learn. Needless to say, I left that session very upset and I ultimately ended up changing my major to something “easier” because apparently it “wasn’t for me”.</p>
<h3>Accepting A Career</h3>
<p>After I graduated in 2010 with my degree in Information Technology, I moved to DC to pursue an unfulfilling Systems Engineering career in government contracting. Don’t get me wrong. I learned a plethora of valuable skills that I will use for the rest of my life. But I wasn’t doing something that was enriching me. Not only that, I was often made to feel ostracized in the work culture because of the lack of diversity.</p>
<blockquote><p>I’m not sure if anyone’s told you&#8230;but it’s extremely hard being a minority and working with people who don’t look like you and who can’t relate to you.</p></blockquote>
<p>If someone said something racially insensitive or offensive (and there have been multiple instances), that was always a battle I had to fight on my own. And to be honest, sometimes I didn’t fight because I knew no one would give a damn and the person would get away with it with a slap on the wrist.</p>
<h3>Remembering Joy</h3>
<p>So in the mist of all of this, no matter how upset, beaten-up and angry I felt after a work day, I could always come back to my love for the metal music genre. I would spend so much time listening to new metal music after work that co-workers nicknamed me “the DJ”. Which isn’t completely untrue. In college, one of my extracurriculars was to host a weekly metal radio show on the college radio station. But I didn’t have that anymore so I essentially felt a bit lost.</p>
<p>That’s when I decided to get it back! Not in the form of an actual radio show. But in the form of a metal music blog. Outside of having played around with making marque-filled pages on GeoCities and changing the backgrounds of my MySpace and Xanga profiles to be neon-colored or highly pixelated images, I didn’t have any experience making a website. So I GOOGLED it! And in that research I learned how hosting providers work and the best blogging platform for me to use for my blog. And that platform was WordPress. So in 2015, I launched my first website ever on WordPress: metalandcoffee.com. And this point I didn’t really know anything super WordPress-nerdy outside of being able to select a theme and add/organize content on the navigation bar. But I finally had my own voice live and anyone can see it!</p>
<h3>Looking Deep</h3>
<p>Now &#8211; the year was 2017 and words cannot describe how miserable I am in my current work position. I thought transferring to a position within the company that brought me back to Philadelphia would help my pain and suffering but it only numbed it for a couple months. I still didn’t like the environment, I didn’t like what I was doing, and although I was able to look at the occasional code snippet that would give me a spark of confidence when I understood what the code was doing, I wasn’t given an opportunity to be on the other side. This is what lit a fire under me to finally do everything in my power to move towards a developer career. I felt like that was where I was supposed to be. Sure, I was told that I wasn’t smart enough to be anywhere near code but why did it excite me to see it and recognize it? Why was I able to troubleshoot errors even though I wasn’t a developer? Why was I excelling at quality assuring software by being able to understand the code’s logic thus thinking of scenarios that were unaccounted for?</p>
<h3>Breaking Through</h3>
<p>So I signed up for a couple online courses focused on web development and eventually found myself having been accepted to <a href=\"http://www.interactivemechanics.com/fellowship\">a front-end developer fellowship program</a> that provided me with an amazing mentor and a final project to work towards. For my final project, I chose to learn how to create a custom WordPress theme for my Metal &amp; Coffee website because the current one that I was using did not fully suite my needs.</p>
<blockquote><p>And there you have it &#8211; throughout the next 9 months, the doubt and shame instilled in me since college kept coming up and I kept having to find ways to break through it whether it’d be a pep talk from my mentor, talking to developers who look like me (black women) or using meditation to help me through the anxiety.</p></blockquote>
<p>And by the end of that, not only did I finish my final project (<a href=\"http://metalandcoffee.github.io\">http://metalandcoffee.github.io</a>) and come to really love WordPress theming, I got a job offer from Tracy Levesque and Mia Levesque to work at their WordPress web agency, <a href=\"https://www.yikesinc.com/\">Yikes Inc.</a></p>
<h3>Finding My Place</h3>
<p>Now, I’m a full-time WordPress developer and I couldn’t be more satisfied. Working at Yikes has sent my developer skills soaring over mountains and valleys. My curiosity is allowed to run wild and I’ve actually been diving into the plugin world, completely re-coding an internal plugin from the ground up and learning essential web programming practices in the process.</p>
<p>My next goal in the WordPress community is to see more WordPress developers who look like me. And one step I’ve taken towards that goal is to co-teach a Intro to WordPress workshop at Codeland 2018 which I’m very excited (and nervous) for. And I’ll continue to be as visible and outspoken as possible to encourage diversity in this community.</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Believe In Yourself\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Believe%20In%20Yourself&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fbelieve-in-yourself%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Believe In Yourself\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fbelieve-in-yourself%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fbelieve-in-yourself%2F&title=Believe+In+Yourself\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Believe In Yourself\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/believe-in-yourself/&media=https://heropress.com/wp-content/uploads/2018/01/012418-150x150.jpg&description=Believe In Yourself\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Believe In Yourself\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/believe-in-yourself/\" title=\"Believe In Yourself\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/believe-in-yourself/\">Believe In Yourself</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 24 Jan 2018 13:00:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Ebonie Butler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: New Toolkit Simplifies the Process of Creating Gutenberg Blocks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77521\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wptavern.com/new-toolkit-simplifies-the-process-of-creating-gutenberg-blocks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5470:\"<p><!-- wp:core/paragraph --></p>
<p><a href=\"https://ahmadawais.com/\">Ahmad Awais</a>, who <a href=\"https://wptavern.com/gutenberg-boilerplate-demonstrates-how-to-build-custom-blocks\">created the Gutenberg Boilerplate</a> last year, has <a href=\"https://ahmadawais.com/create-guten-block-toolkit/\">released</a> a <a href=\"https://github.com/ahmadawais/create-guten-block\">Guten Block Toolkit</a>. The toolkit substantially simplifies the creation of Gutenberg Blocks by providing no configuration, one dependency, and no lock-in.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>Awais created the toolkit after receiving feedback that configuring things like Webpack, React, ES 6/7/8/Next, ESLint, Babel and keeping up with their development was too difficult.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>\"Developers told me that they built Gutenberg blocks with ES5 because the amount of time required to configure, set up, and learn tools like Babel, Webpack, ESLint, Prettier, etc. wasn’t worth it,\" Awais said.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>\"So, yes! I went ahead and built a solution — a zero-config-js #0CJS WordPress developers’ toolkit called create-guten-block!\"</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>Creating blocks using the toolkit is a three-step process. </p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>Developers begin by installing Node version 8 or higher on a local server. The next step is to run the create-guten-block command and provide a name for the plugin that will be created. This command also creates the folder structure necessary to maintain the project. The last step is to run the NPM start command which runs the plugin in development mode.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>Once these steps are completed, the WordPress plugin will be compatible with Gutenberg and have React.js, ES 6/7/8/Next, and Babel, which also has ESLint configurations for code editors to detect and use automatically. </p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>The Guten Block Toolkit comes with the following:</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/list --></p>
<ul>
<li>React, JSX, and ES6 syntax support. </li>
<li>Webpack dev/production build process behind the scene. </li>
<li>Language extras beyond ES6 like the object spread operator. </li>
<li>Auto-prefixed CSS, so you don’t need -webkit or other prefixes. </li>
<li>A build script to bundle JS, CSS, and images for production with source-maps. </li>
<li>Hassle-free updates for the above tools with a single dependency cgb-scripts.</li>
</ul>
<p><!-- /wp:core/list --></p>
<p><!-- wp:core/paragraph --></p>
<p>The project has received positive feedback, including from members of Gutenberg&#x27;s development team.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/embed {\"url\":\"https://twitter.com/GaryPendergast/status/954559771910193152\"} --></p>

<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Mad props to <a href=\"https://twitter.com/MrAhmadAwais?ref_src=twsrc%5Etfw\">@MrAhmadAwais</a> for making a super useful Gutenberg tool that I\'ve been really looking forward to! 🎉</p>
<p>I\'m excited about the possibilities for this, and I love how it\'s embraced WordPress\' \"decisions, not options\" philosophy, doing all of the hard work for you. 💪💯 <a href=\"https://t.co/hUAQVDL7S1\">https://t.co/hUAQVDL7S1</a></p>
<p>&mdash; Gary (@GaryPendergast) <a href=\"https://twitter.com/GaryPendergast/status/954559771910193152?ref_src=twsrc%5Etfw\">January 20, 2018</a></p></blockquote>
<p><br />

<p><!-- /wp:core/embed --></p>
<p><!-- wp:core/embed {\"url\":\"https://twitter.com/igorbenic/status/955539392273281025\"} --></p>

<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Tried the <a href=\"https://t.co/WkvhwSVBh6\">https://t.co/WkvhwSVBh6</a> from <a href=\"https://twitter.com/MrAhmadAwais?ref_src=twsrc%5Etfw\">@MrAhmadAwais</a>, had a block within a minute. Now it\'s time to finish the <a href=\"https://twitter.com/hashtag/Gutenberg?src=hash&ref_src=twsrc%5Etfw\">#Gutenberg</a> course from <a href=\"https://twitter.com/zgordon?ref_src=twsrc%5Etfw\">@zgordon</a> to actually build something useful :D</p>
<p>&mdash; Igor Benić (@igorbenic) <a href=\"https://twitter.com/igorbenic/status/955539392273281025?ref_src=twsrc%5Etfw\">January 22, 2018</a></p></blockquote>
<p><br />

<p><!-- /wp:core/embed --></p>
<p><!-- wp:core/paragraph --></p>
<p>With a stable release now available to the public, Awais is working on <a href=\"https://github.com/ahmadawais/create-guten-block/issues/11\">2.0.0</a>. \"The next step is to get this toolkit tested and mature the entire app to release version 2.0.0 for that not only do I need your <a href=\"https://ahmadawais.com/contact/\">support</a>, I ask that you hop on board and contribute — that’s the only way forward,\" he said.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>Create Guten Block Toolkit is <a href=\"https://github.com/ahmadawais/create-guten-block/blob/master/LICENSE\">MIT licensed</a> and available for free <a href=\"https://github.com/ahmadawais/create-guten-block\">on GitHub</a>. Contributions are welcomed! </p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p><!-- /wp:core/paragraph --></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 24 Jan 2018 03:30:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WPTavern: Free Conference Dedicated to WordPress in Higher Ed Takes Place January 30th at 9AM CST\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77514\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:108:\"https://wptavern.com/free-conference-dedicated-to-wordpress-in-higher-ed-takes-place-january-30th-at-9am-cst\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1380:\"<p>If you&#8217;re interested in learning how WordPress is used in Higher Ed, tune in to <a href=\"https://online.wpcampus.org/\">WPCampus Online</a>, January 30th at 9AM Central Standard Time. WPCampus Online is a virtual conference that people can watch for free, no traveling necessary. The event uses <a href=\"https://www.crowdcast.io/\">Crowdcast</a> allowing viewers to switch between rooms, interact with each other, and ask questions.</p>
<p>Some of the topics that <a href=\"https://online.wpcampus.org/schedule/\">will be presented</a> include, <a href=\"https://online.wpcampus.org/schedule/wordpress-and-real-world-data-with-students/\">WordPress and Real-World Data with Students</a>, <a href=\"https://online.wpcampus.org/schedule/headless-brainless-wordpress/\">Headless and Brainless WordPress</a>, and <a href=\"https://online.wpcampus.org/schedule/using-wordpress-support-run-student-government-elections/\">Using WordPress to Support and Run Student Government Elections</a>. If in-person conferences are more your style, keep an eye out for information on WPCampus 2018 tentatively planned for this Summer.</p>
<p>To learn more about WPCampus and the people behind it, <a href=\"https://wptavern.com/wpweekly-episode-301-wordpress-in-highered-accessibility-and-more-with-rachel-cherry\">listen to our interview</a> with Rachel Cherry on episode 301 of WordPress Weekly.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 22 Jan 2018 22:14:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"Mark Jaquith: How I fixed Yoast SEO sitemaps on a large WordPress site\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://markjaquith.wordpress.com/?p=5392\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"https://markjaquith.wordpress.com/2018/01/22/how-i-fixed-yoast-seo-sitemaps-on-a-large-wordpress-site/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4852:\"<p>One of my Covered Web Services clients recently came to me with a problem: <a href=\"https://yoast.com/wordpress/plugins/seo/\">Yoast SEO</a> sitemaps were broken on their largest, highest-traffic WordPress site. Yoast SEO breaks your sitemap up into chunks. On this site, the individual chunks were loading, but the sitemap index (its &#8220;table of contents&#8221;) would not load, and was giving a timeout error. This prevented search engines from finding the individual sitemap chunks.</p>
<p>Sitemaps are really helpful for providing information to search engines about the content on your site, so fixing this issue was a high priority to the client! They were frustrated, and confused, because this was working just fine on their other sites.</p>
<p>Given that this site has over a decade of content, I figured that Yoast SEO&#8217;s dynamic generation of the sitemap was simply taking too long, and the server was giving up.</p>
<p>So I increased the site&#8217;s various timeout settings to 120 seconds.</p>
<p><strong>No good.</strong></p>
<p>I increased the timeout settings to 300 seconds. Five whole minutes!</p>
<p><strong>Still no good.</strong></p>
<p>This illustrates one of the problems that WordPress sites can face when they accumulate a lot of content: <strong>dynamic processes start to take longer</strong>. A process that takes a reasonable 5 seconds with 5,000 posts might take 100 seconds with 500,000 posts. I could have eventually made the Yoast SEO sitemap index work if I increased the timeout high enough, but that wouldn&#8217;t have been a good solution.</p>
<ol>
<li>It would have meant increasing the timeout settings irresponsibly high, leaving the server potentially open to abuse.</li>
<li>Even though it is search engines, not people, who are requesting the sitemap, it is unreasonable to expect them to wait over 5 minutes for it to load. They&#8217;re likely to give up. They might even penalize the site in their rankings for being slow.</li>
</ol>
<p>I needed the sitemap to be reliably generated without making the search engines wait.</p>
<p><strong>When something intensive needs to happen reliably on a site, look to the command line.</strong></p>
<h2>The Solution</h2>
<p>Yoast SEO doesn&#8217;t have <a href=\"http://wp-cli.org/\">WP-CLI</a> (WordPress command line interface) commands, but that doesn&#8217;t matter — you can just use <a href=\"https://developer.wordpress.org/cli/commands/eval/\"><b>wp eval</b></a> to run arbitrary WordPress PHP code.</p>
<p>After a little digging through the <a href=\"https://github.com/Yoast/wordpress-seo/blob/46802dbcf8e7d2ac0d6552f4de0923cd0eba2b07/inc/sitemaps/class-sitemaps.php#L345-L364\">Yoast SEO code</a>, I determined that this WP-CLI command would output the index sitemap:</p>
<pre class=\"brush: bash; title: ; notranslate\">wp eval \'
$sm = new WPSEO_Sitemaps;
$sm-&gt;build_root_map();
$sm-&gt;output();
\'</pre>
<p>That took a good while to run on the command line, but that doesn&#8217;t matter, because I just set a <a href=\"https://help.ubuntu.com/community/CronHowto\">cron job</a> to run it once a day and save its output to a static file.</p>
<pre class=\"brush: plain; title: ; notranslate\">0 3 * * * cd /srv/www/example.com &amp;&amp; /usr/local/bin/wp eval \'$sm = new WPSEO_Sitemaps;$sm-&gt;build_root_map();$sm-&gt;output();\' &gt; /srv/www/example.com/wp-content/uploads/sitemap_index.xml</pre>
<p>The final step that was needed was to modify a rewrite in the site&#8217;s Nginx config that would make the <b>/sitemap_index.xml</b> path point to the cron-created static file, instead of resolving to Yoast SEO&#8217;s dynamic generation URL.</p>
<pre class=\"brush: plain; highlight: [4]; title: ; notranslate\">location ~ ([^/]*)sitemap(.*).x(m|s)l$ {
    rewrite ^/sitemap.xml$ /sitemap_index.xml permanent;
    rewrite ^/([a-z]+)?-?sitemap.xsl$ /index.php?xsl=$1 last;
    rewrite ^/sitemap_index.xml$ /wp-content/uploads/sitemap_index.xml last;
    rewrite ^/([^/]+?)-sitemap([0-9]+)?.xml$ /index.php?sitemap=$1&amp;sitemap_n=$2 last;
}</pre>
<p>Now the sitemap index loads instantly (because it&#8217;s a static file), and is kept up-to-date with a reliable background process. The client is happy that they didn&#8217;t have to switch SEO plugins or install a separate sitemap plugin. Everything just works, thanks to a little bit of command line magic.</p>
<p>What other WordPress processes would benefit from this kind of approach?</p>
<hr />
<p><b>Do you need <a href=\"https://coveredwebservices.com/\">WordPress services?</a></b></p>
<p>Mark runs <a href=\"https://coveredwebservices.com/\">Covered Web Services</a> which specializes in custom WordPress solutions with focuses on security, speed optimization, plugin development and customization, and complex migrations.</p>
<p>Please reach out to start a conversation!</p>
[contact-form]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 22 Jan 2018 15:15:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mark Jaquith\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"Post Status: Hosted versus self-hosted eCommerce — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=41084\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://poststatus.com/hosted-versus-self-hosted-ecommerce-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2130:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p>In this episode, Brian and Brian discuss self-hosted vs managed ecommerce and whether or not conferences have outlived their usefulness. Specifically, they look at WooCommerce vs other solutions and explore Shopify and Liquid Web’s Managed WooCommerce hosting as viable done-for-you strategies. On the conference front, they talk about the good and the bad of conferences and ponder how tech conferences of the future may need to change to attract more attendees.</p>
<p></p>
<h3>Links</h3>
<ul>
<li><a href=\"https://marco.org/2018/01/17/end-of-conference-era\">The End of the Conference Era</a></li>
<li><a href=\"https://www.liquidweb.com/blog/liquid-web-announces-the-launch-of-managed-woocommerce-hosting/\">Liquid Web introduces Managed WooCommerce</a></li>
<li><a href=\"https://github.com/liquidweb/woocommerce-order-tables\">Liquid Web&#8217;s WooCommerce Order Tables Plugin</a></li>
<li><a href=\"https://metorik.com/\">Metorik</a></li>
<li><a href=\"https://www.ecommercefuel.com/\">eCommerceFuel</a></li>
</ul>
<h3>Sponsor: Pippin&#8217;s Plugins</h3>
<p>This episode is sponsored by Pippin’s Plugins. <a href=\"http://pippinsplugins.com/\">Pippin’s Plugins</a> creates a suite of plugins that work great alone, or together. Whether you need to restrict content, sell downloads, or start an affiliate program, they’ve got you covered. For more information, check out their <a href=\"http://pippinsplugins.com/\">website</a> and thank you to Pippin’s Plugins for being a Post Status partner.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 19 Jan 2018 20:56:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Matt: R.I.P Dean\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47840\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"https://ma.tt/2018/01/r-i-p-dean/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3483:\"<p>Dean Allen, a web pioneer and good man, has passed away. I&#x27;ve been processing the news for a few days and still don&#x27;t know where to begin. Dean was a writer, who wrote the software he wrote on. His websites were crafted, designed, and typeset so well you would have visited them even if they were filled with Lorem Ipsum, and paired with his writing you were drawn into an impossibly rich world. His blog was called Textism, and among many other things it introduced me to the art of typography.</p>

<p>Later, he created Textpattern, without which WordPress wouldn&#x27;t exist. Later, he created Textdrive with Jason Hoffman, without which WordPress wouldn&#x27;t have found an early business model or had a home on the web. He brought a care and craft to everything he touched that inspires me to this day. As <a href=\"https://daringfireball.net/2018/01/dean_allen\">John Gruber said</a>, \"Dean strove for perfection and often achieved it.\" (Aside: Making typography better on the web led John Gruber to release Smarty Pants, Dean a tool called Textile, and myself something called Texturize all within a few months of each other; John continued his work and created Markdown, I put Texturize into WP, and Dean released Textile in Textpattern.)</p>

<p>Years later, we became friends and shared many trips, walks, drinks, and meals together, often with Hanni and <a href=\"https://om.co/2018/01/18/dean-allen-rest-in-peace/\">Om</a>. (When we overlapped in Vancouver he immediately texted \"I&#x27;ll show you some butt-kicking food and drink.\") His zest for life was matched with an encyclopedic knowledge of culture and voracious reading (and later podcast listening) habits. I learned so much in our time together, a web inspiration who turned for me into a real-life mensch. He was endlessly generous with his time and counsel in design, prose, and fashion. I learned the impossibly clever sentences he wrote, that you assumed were the product of a small writing crew or at least a few revisions, came annoyingly easily to him, an extension of how he actually thought and wrote and the culmination of a lifetime of telling stories and connecting to the human psyche.</p>

<p>Dean, who (of course) was also a great photographer, didn&#x27;t love having his own photo taken but would occasionally tolerate me when I pointed a camera at him <a href=\"https://om.co/2018/01/18/dean-allen-rest-in-peace/\">and Om has a number of the photos on his post</a>. There&#x27;s one that haunts me: before getting BBQ we were at his friend&#x27;s apartment in Vancouver, listening to Mingus and enjoying hand-crafted old fashioneds with <a href=\"https://ma.tt/files/2018/01/IMG_7147.jpg\">antique bitters</a>, and despite the rain we went on the roof to see the art that was visible from there. He obliged to a photo this time though and we took photos of each other individually in front of a sign that said \"EVERYTHING IS GOING TO BE ALRIGHT.\" It wasn&#x27;t, but it&#x27;s what I imagine Dean would say right now if he could.</p>

<div class=\"wp-block-gallery alignnone columns-2 is-cropped\">
    <img src=\"https://i2.wp.com/ma.tt/files/2018/01/IMG_7151.jpg?w=604&ssl=1\" />
    <img src=\"https://i0.wp.com/ma.tt/files/2018/01/IMG_7158.jpg?w=604&ssl=1\" />
</div>

<img src=\"https://i1.wp.com/ma.tt/files/2018/01/104050690_ce98a95092_o.jpg?w=604&ssl=1\" />
    When we first met, in 2006, <a href=\"https://www.flickr.com/photos/textdriveinc/104050690/in/photostream/\">from Jason</a>.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 19 Jan 2018 05:21:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"WPTavern: WPWeekly Episode 301 – WordPress in HigherEd, Accessibility, and More With Rachel Cherry\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=77497&preview=true&preview_id=77497\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"https://wptavern.com/wpweekly-episode-301-wordpress-in-highered-accessibility-and-more-with-rachel-cherry\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2840:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I are joined by <a href=\"https://bamadesigner.com/\">Rachel Cherry</a>, Senior Software Engineer for <a href=\"http://www.disneyinteractive.com/\">Disney Interactive</a> and Director of <a href=\"https://wpcampus.org/\">WPCampus</a>. Cherry describes how she got involved with WordPress, its use in higher education, the inspiration behind WPCampus, and her thoughts on accessibility both in WordPress and across the web. She also assigned everyone the following homework assignment.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Per my interview on <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> Weekly, I’ve assigned everyone <a href=\"https://twitter.com/hashtag/accessibility?src=hash&ref_src=twsrc%5Etfw\">#accessibility</a> homework: open your website and navigate using ONLY THE KEYBOARD. Can you access all content and functionality? Can you open AND close popups? Let me know what you learned.</p>
<p>&mdash; Rachel Cherry (@bamadesigner) <a href=\"https://twitter.com/bamadesigner/status/953742847831818240?ref_src=twsrc%5Etfw\">January 17, 2018</a></p></blockquote>
<p></p>
<p>If you want to learn how WordPress is being used in higher education, tune in to<a href=\"https://online.wpcampus.org/\"> WPCampus Online</a> Tuesday, January 30, 2018. Viewers will be able to watch sessions and interact with the speakers for free. Near the end of the show, Jacoby provides a review of the Nintendo Switch he received for Christmas.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://make.wordpress.org/core/2018/01/12/whats-new-in-gutenberg-12th-january/\">Gutenberg 2.0 Released</a><br />
<a href=\"https://wptavern.com/wordpress-4-9-2-patches-xss-vulnerability\">WordPress 4.9.2 Patches XSS Vulnerability</a><br />
<a href=\"https://wptavern.com/zac-gordon-launches-gutenberg-development-course-includes-more-than-30-videos\">Zac Gordon Launches Gutenberg Development Course, Includes More Than 30 Videos</a></p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://pippinsplugins.com/2017-in-review/\">Pippin Williamson&#8217;s 2017 Year in Review</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, January 24th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #301:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 18 Jan 2018 02:42:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: DesktopServer 3.8.4 Includes A Gift to the Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77259\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wptavern.com/desktopserver-3-8-4-includes-a-gift-to-the-community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2802:\"<p><!-- wp:core/paragraph --></p>
<p>DesktopServer <a href=\"https://serverpress.com/announcing-desktopserver-v3-8-4/\">has released</a> version 3.8.4 of its local development software. This version includes a lot of refactored code, setting the foundation for faster updates in the future along with design-time plugins.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>One of the major changes in 3.8.4 is the use of the .dev.cc top level domain.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/quote --></p>
<blockquote class=\"wp-block-quote\">
<p>Due to the latest changes with the .dev Top Level Domain and the fact that many browsers now force SSL on anything with the .dev extension, DesktopServer will now use .dev.cc as its TLD extension. This is a legitimate top level domain owned by ServerPress, LLC and will ONLY be used for local development purposes.</p>
<p><cite><a href=\"https://serverpress.com/announcing-desktopserver-v3-8-4/\">Release Announcement Post</a></cite></p></blockquote>
<p><!-- /wp:core/quote --></p>
<p><!-- wp:core/paragraph --></p>
<p>Marc Benzakein says the domain will work no matter which local development solution is being used and that it&#x27;s a gift to the community. Other domains such as .test will continue to work as expected. </p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>Other improvements include speed optimizations for Windows installs, a Windows compatibility plugin to fix long filename problems when updating from third-party plugin repositories such as Easy Digital Downloads, and a WordPress 4.9.1 Blueprint.</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/paragraph --></p>
<p>If you use an Apple device with a Retina screen or Hi-DPI in Windows, you&#x27;ll likely appreciate the user-interface changes that are vastly improved on high resolution screens. Josh Eby does!</p>
<p><!-- /wp:core/paragraph --></p>
<p><!-- wp:core/embed {\"url\":\"https://twitter.com/josheby/status/953089139439751168\"} --></p>

<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Love the new scaling fix on <a href=\"https://twitter.com/DesktopServer?ref_src=twsrc%5Etfw\">@DesktopServer</a> 3.8.4!  Looks great on my 4K display now. Can\'t wait for 3.9 to get released!</p>
<p>&mdash; Josh Eby (@josheby) <a href=\"https://twitter.com/josheby/status/953089139439751168?ref_src=twsrc%5Etfw\">January 16, 2018</a></p></blockquote>
<p><br />

<p><!-- /wp:core/embed --></p>
<p><!-- wp:core/paragraph --></p>
<p>DesktopServer 3.8.4 also includes a number of enhancements for premium service customers. To view these and other notes related to the release, check out <a href=\"https://serverpress.com/announcing-desktopserver-v3-8-4/\">the announcement post</a>. </p>
<p><!-- /wp:core/paragraph --></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 17 Jan 2018 19:12:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sat, 24 Feb 2018 14:32:14 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Sat, 24 Feb 2018 14:15:27 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20130911010210\";}","no");
INSERT INTO `wp_options` VALUES("743","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1519525937","no");
INSERT INTO `wp_options` VALUES("744","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1519482737","no");
INSERT INTO `wp_options` VALUES("745","_transient_timeout_dash_v2_f69de0bbfe7eaa113146875f40c02000","1519525937","no");
INSERT INTO `wp_options` VALUES("746","_transient_dash_v2_f69de0bbfe7eaa113146875f40c02000","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://ru.wordpress.org/news/2018/02/%D0%B2%D1%8B%D0%BF%D1%83%D1%81%D0%BA-wordpress-4-9-4/\'>Выпуск WordPress 4.9.4 (требуется ручное обновление)</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wptavern.com/wordcamp-orange-county-plugin-a-palooza-first-place-prize-is-3000\'>WPTavern: WordCamp Orange County Plugin-A-Palooza First Place Prize is $3,000</a></li><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2018/02/wordcamp-incubator-2-0/\'>Dev Blog: WordCamp Incubator 2.0</a></li><li><a class=\'rsswidget\' href=\'https://heropress.com/essays/build-company-wordpress/#utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=build-company-wordpress\'>HeroPress: How To Build A Company With WordPress</a></li></ul></div>","no");
INSERT INTO `wp_options` VALUES("747","_transient_timeout_plugin_slugs","1519569442","no");
INSERT INTO `wp_options` VALUES("748","_transient_plugin_slugs","a:5:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:22:\"cyr3lat/cyr-to-lat.php\";i:2;s:21:\"polylang/polylang.php\";i:3;s:31:\"query-monitor/query-monitor.php\";i:4;s:27:\"theme-check/theme-check.php\";}","no");
INSERT INTO `wp_options` VALUES("753","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-4.9.4.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-4.9.4.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.4\";s:7:\"version\";s:5:\"4.9.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1519491178;s:15:\"version_checked\";s:5:\"4.9.4\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("754","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1519491180;s:7:\"checked\";a:5:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.3.2\";s:22:\"cyr3lat/cyr-to-lat.php\";s:3:\"3.5\";s:21:\"polylang/polylang.php\";s:5:\"2.3.1\";s:31:\"query-monitor/query-monitor.php\";s:6:\"2.17.0\";s:27:\"theme-check/theme-check.php\";s:10:\"20160523.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:5:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.3.2\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";s:7:\"default\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1232826\";s:7:\"default\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1232826\";}s:11:\"banners_rtl\";a:0:{}}s:22:\"cyr3lat/cyr-to-lat.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/cyr3lat\";s:4:\"slug\";s:7:\"cyr3lat\";s:6:\"plugin\";s:22:\"cyr3lat/cyr-to-lat.php\";s:11:\"new_version\";s:3:\"3.5\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/cyr3lat/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/cyr3lat.3.5.zip\";s:5:\"icons\";a:0:{}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:21:\"polylang/polylang.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/polylang\";s:4:\"slug\";s:8:\"polylang\";s:6:\"plugin\";s:21:\"polylang/polylang.php\";s:11:\"new_version\";s:5:\"2.3.1\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/polylang/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/polylang.2.3.1.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:61:\"https://ps.w.org/polylang/assets/icon-128x128.png?rev=1331499\";s:2:\"2x\";s:61:\"https://ps.w.org/polylang/assets/icon-256x256.png?rev=1331499\";s:7:\"default\";s:61:\"https://ps.w.org/polylang/assets/icon-256x256.png?rev=1331499\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:64:\"https://ps.w.org/polylang/assets/banner-1544x500.png?rev=1405299\";s:2:\"1x\";s:63:\"https://ps.w.org/polylang/assets/banner-772x250.png?rev=1405299\";s:7:\"default\";s:64:\"https://ps.w.org/polylang/assets/banner-1544x500.png?rev=1405299\";}s:11:\"banners_rtl\";a:0:{}}s:31:\"query-monitor/query-monitor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/query-monitor\";s:4:\"slug\";s:13:\"query-monitor\";s:6:\"plugin\";s:31:\"query-monitor/query-monitor.php\";s:11:\"new_version\";s:6:\"2.17.0\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/query-monitor/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/query-monitor.2.17.0.zip\";s:5:\"icons\";a:0:{}s:7:\"banners\";a:3:{s:2:\"2x\";s:69:\"https://ps.w.org/query-monitor/assets/banner-1544x500.png?rev=1629576\";s:2:\"1x\";s:68:\"https://ps.w.org/query-monitor/assets/banner-772x250.png?rev=1731469\";s:7:\"default\";s:69:\"https://ps.w.org/query-monitor/assets/banner-1544x500.png?rev=1629576\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"theme-check/theme-check.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/theme-check\";s:4:\"slug\";s:11:\"theme-check\";s:6:\"plugin\";s:27:\"theme-check/theme-check.php\";s:11:\"new_version\";s:10:\"20160523.1\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/theme-check/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/theme-check.20160523.1.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:63:\"https://ps.w.org/theme-check/assets/icon-128x128.png?rev=972579\";s:7:\"default\";s:63:\"https://ps.w.org/theme-check/assets/icon-128x128.png?rev=972579\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/theme-check/assets/banner-1544x500.png?rev=904294\";s:2:\"1x\";s:65:\"https://ps.w.org/theme-check/assets/banner-772x250.png?rev=904294\";s:7:\"default\";s:66:\"https://ps.w.org/theme-check/assets/banner-1544x500.png?rev=904294\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `wp_options` VALUES("755","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1519491180;s:7:\"checked\";a:4:{s:8:\"Golubika\";s:3:\"1.0\";s:13:\"twentyfifteen\";s:3:\"1.9\";s:15:\"twentyseventeen\";s:3:\"1.4\";s:13:\"twentysixteen\";s:3:\"1.4\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("762","_transient_timeout_external_ip_address_127.0.0.1","1520087796","no");
INSERT INTO `wp_options` VALUES("763","_transient_external_ip_address_127.0.0.1","159.224.201.251","no");
INSERT INTO `wp_options` VALUES("783","category_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("786","_site_transient_timeout_theme_roots","1519492979","no");
INSERT INTO `wp_options` VALUES("787","_site_transient_theme_roots","a:4:{s:8:\"Golubika\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}","no");
INSERT INTO `wp_options` VALUES("789","_transient_timeout_users_online","1519503373","no");
INSERT INTO `wp_options` VALUES("790","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";d:1519508773;s:10:\"ip_address\";s:9:\"127.0.0.1\";}}","no");
INSERT INTO `wp_options` VALUES("792","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1519507002","no");
INSERT INTO `wp_options` VALUES("793","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4430;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:2595;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2538;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2406;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1858;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1632;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1625;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1446;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1382;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1378;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1372;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1299;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1281;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1183;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1084;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1056;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1013;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:992;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:863;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:857;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:822;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:796;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:789;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:691;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:688;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:682;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:674;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:667;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:654;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:651;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:639;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:631;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:630;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:608;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:605;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:598;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:596;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:584;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:584;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:584;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:556;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:541;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:535;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:527;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:517;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:511;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:510;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:502;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:489;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:485;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:485;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:479;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:476;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:465;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:463;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:463;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:453;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:449;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:433;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:423;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:423;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:417;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:416;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:415;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:411;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:410;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:401;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:394;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:389;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:383;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:367;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:360;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:355;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:353;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:342;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:342;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:339;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:337;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:336;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:334;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:333;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:333;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:332;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:329;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:328;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:321;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:314;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:309;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:304;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:302;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:301;}s:3:\"tag\";a:3:{s:4:\"name\";s:3:\"tag\";s:4:\"slug\";s:3:\"tag\";s:5:\"count\";i:300;}s:7:\"adsense\";a:3:{s:4:\"name\";s:7:\"adsense\";s:4:\"slug\";s:7:\"adsense\";s:5:\"count\";i:295;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:291;}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";i:291;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:288;}s:6:\"author\";a:3:{s:4:\"name\";s:6:\"author\";s:4:\"slug\";s:6:\"author\";s:5:\"count\";i:288;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:286;}s:8:\"lightbox\";a:3:{s:4:\"name\";s:8:\"lightbox\";s:4:\"slug\";s:8:\"lightbox\";s:5:\"count\";i:283;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:283;}}","no");
INSERT INTO `wp_options` VALUES("795","_site_transient_timeout_available_translations","1519511908","no");
INSERT INTO `wp_options` VALUES("796","_site_transient_available_translations","a:112:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-06 13:56:09\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-23 21:25:10\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-25 21:29:53\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.4/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-05 09:38:10\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.8.5\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.5/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-14 03:59:30\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-04 20:20:28\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-04 11:05:21\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-16 14:25:50\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-05 12:14:04\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-02 17:36:02\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-18 10:57:23\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-12 10:10:36\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-22 15:43:53\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.9.2/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-18 10:57:34\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.4/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-21 11:11:12\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-23 13:14:32\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-24 19:13:22\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 09:54:30\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-01 00:57:34\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-05 22:38:45\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-30 15:37:42\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-31 07:06:12\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-23 18:34:33\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 23:17:08\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 15:03:42\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.8.5\";s:7:\"updated\";s:19:\"2017-07-31 15:12:02\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.5/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-10-01 17:54:52\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.3/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-28 20:09:49\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-19 08:44:26\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-19 14:11:29\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-12-09 21:12:23\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-21 08:16:29\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-12 17:00:17\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-06 06:52:56\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-31 11:16:06\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-13 21:04:28\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.5\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.5/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-06 21:50:33\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-14 06:16:04\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-12 09:39:31\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-08 13:07:19\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-23 13:37:29\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-29 19:54:36\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-12-21 02:45:34\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-04-13 13:55:54\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-23 12:24:32\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-24 06:17:29\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-14 11:47:57\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Nerusaké\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-08 06:01:48\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-19 20:58:18\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.4/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-07 02:07:59\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-10 14:12:15\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:25\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 19:40:23\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-03-17 20:40:40\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.7/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"4.8.5\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.5/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-12-09 00:51:20\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-06 10:00:35\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.8.5\";s:7:\"updated\";s:19:\"2017-10-05 06:45:20\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.5/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-24 14:29:17\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-12 10:02:28\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-12 10:05:39\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.4/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-26 14:30:58\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-21 11:54:40\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-25 21:30:31\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/4.9.4/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-01 00:52:57\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-22 19:29:24\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-16 11:41:34\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-22 17:48:06\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-16 08:25:42\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-31 10:48:26\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-05 20:37:27\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-23 15:16:06\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-06 01:04:10\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-19 20:23:17\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-05 09:23:39\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:9:\"Uyƣurqə\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-11-02 17:05:02\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.3/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-01-25 07:19:58\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-24 17:01:08\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-01 04:49:54\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-06 17:26:08\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-13 02:41:15\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-17 22:20:52\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}}","no");
INSERT INTO `wp_options` VALUES("797","_transient_pll_languages_list","a:2:{i:0;a:26:{s:7:\"term_id\";i:8;s:4:\"name\";s:7:\"English\";s:4:\"slug\";s:2:\"en\";s:10:\"term_group\";i:0;s:16:\"term_taxonomy_id\";i:8;s:8:\"taxonomy\";s:8:\"language\";s:11:\"description\";s:5:\"en_GB\";s:6:\"parent\";i:0;s:5:\"count\";i:2;s:10:\"tl_term_id\";i:9;s:19:\"tl_term_taxonomy_id\";i:9;s:8:\"tl_count\";i:2;s:6:\"locale\";R:9;s:6:\"is_rtl\";i:0;s:3:\"w3c\";s:5:\"en-GB\";s:8:\"facebook\";s:5:\"en_GB\";s:8:\"flag_url\";s:0:\"\";s:4:\"flag\";s:0:\"\";s:8:\"home_url\";s:25:\"http://golubika.local/en/\";s:10:\"search_url\";s:25:\"http://golubika.local/en/\";s:4:\"host\";N;s:5:\"mo_id\";s:2:\"31\";s:13:\"page_on_front\";N;s:14:\"page_for_posts\";N;s:6:\"filter\";s:3:\"raw\";s:9:\"flag_code\";s:0:\"\";}i:1;a:26:{s:7:\"term_id\";i:5;s:4:\"name\";s:20:\"Українська\";s:4:\"slug\";s:2:\"uk\";s:10:\"term_group\";i:1;s:16:\"term_taxonomy_id\";i:5;s:8:\"taxonomy\";s:8:\"language\";s:11:\"description\";s:2:\"uk\";s:6:\"parent\";i:0;s:5:\"count\";i:4;s:10:\"tl_term_id\";i:6;s:19:\"tl_term_taxonomy_id\";i:6;s:8:\"tl_count\";i:4;s:6:\"locale\";R:35;s:6:\"is_rtl\";i:0;s:3:\"w3c\";s:2:\"uk\";s:8:\"facebook\";s:5:\"uk_UA\";s:8:\"flag_url\";s:0:\"\";s:4:\"flag\";s:0:\"\";s:8:\"home_url\";s:22:\"http://golubika.local/\";s:10:\"search_url\";s:22:\"http://golubika.local/\";s:4:\"host\";N;s:5:\"mo_id\";s:2:\"30\";s:13:\"page_on_front\";N;s:14:\"page_for_posts\";N;s:6:\"filter\";s:3:\"raw\";s:9:\"flag_code\";s:0:\"\";}}","yes");
INSERT INTO `wp_options` VALUES("798","_transient_doing_cron","1519555000.3056728839874267578125","yes");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("51","23","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("52","23","_edit_lock","1519058331:1");
INSERT INTO `wp_postmeta` VALUES("62","27","_wp_attached_file","2018/02/story1.jpg");
INSERT INTO `wp_postmeta` VALUES("63","27","_wp_attachment_metadata","a:5:{s:5:\"width\";i:400;s:6:\"height\";i:500;s:4:\"file\";s:18:\"2018/02/story1.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"story1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"story1-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("64","27","_wp_attachment_image_alt","story2");
INSERT INTO `wp_postmeta` VALUES("65","23","_thumbnail_id","27");
INSERT INTO `wp_postmeta` VALUES("70","29","_wp_attached_file","2018/02/custom_order.jpg");
INSERT INTO `wp_postmeta` VALUES("71","29","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:24:\"2018/02/custom_order.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"custom_order-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"custom_order-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"custom_order-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("72","29","_wp_attachment_image_alt","test");
INSERT INTO `wp_postmeta` VALUES("73","30","_pll_strings_translations","a:7:{i:0;a:2:{i:0;s:8:\"Golubika\";i:1;s:8:\"Golubika\";}i:1;a:2:{i:0;s:25:\"Felt bags&amp;accessories\";i:1;s:25:\"Felt bags&amp;accessories\";}i:2;a:2:{i:0;s:5:\"d.m.Y\";i:1;s:5:\"d.m.Y\";}i:3;a:2:{i:0;s:3:\"H:i\";i:1;s:3:\"H:i\";}i:4;a:2:{i:0;s:17:\"Лого меню\";i:1;s:17:\"Лого меню\";}i:5;a:2:{i:0;s:18:\"Лого О НАС\";i:1;s:18:\"Лого О НАС\";}i:6;a:2:{i:0;s:19:\"Лого футер\";i:1;s:19:\"Лого футер\";}}");
INSERT INTO `wp_postmeta` VALUES("74","31","_pll_strings_translations","a:7:{i:0;a:2:{i:0;s:8:\"Golubika\";i:1;s:8:\"Golubika\";}i:1;a:2:{i:0;s:25:\"Felt bags&amp;accessories\";i:1;s:25:\"Felt bags&amp;accessories\";}i:2;a:2:{i:0;s:5:\"d.m.Y\";i:1;s:5:\"d.m.Y\";}i:3;a:2:{i:0;s:3:\"H:i\";i:1;s:3:\"H:i\";}i:4;a:2:{i:0;s:17:\"Лого меню\";i:1;s:9:\"Logo menu\";}i:5;a:2:{i:0;s:18:\"Лого О НАС\";i:1;s:10:\"Logo About\";}i:6;a:2:{i:0;s:19:\"Лого футер\";i:1;s:11:\"Logo Footer\";}}");
INSERT INTO `wp_postmeta` VALUES("76","33","_thumbnail_id","27");
INSERT INTO `wp_postmeta` VALUES("77","33","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("78","33","_edit_lock","1519488441:1");
INSERT INTO `wp_postmeta` VALUES("83","33","_wp_old_slug","%d0%b7%d0%b0%d0%bf%d0%b8%d1%81%d1%8c-%d0%bd%d0%b0-en");
INSERT INTO `wp_postmeta` VALUES("84","37","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("85","37","_edit_lock","1518280069:1");
INSERT INTO `wp_postmeta` VALUES("86","37","_thumbnail_id","27");
INSERT INTO `wp_postmeta` VALUES("91","40","_thumbnail_id","27");
INSERT INTO `wp_postmeta` VALUES("92","40","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("93","40","_edit_lock","1519488471:1");
INSERT INTO `wp_postmeta` VALUES("100","37","_wp_old_slug","%d0%b8%d1%81%d1%82%d0%be%d1%80%d0%b8%d1%8f2");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_posts` VALUES("2","1","2018-01-21 19:51:27","2018-01-21 16:51:27","Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:

<blockquote>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</blockquote>

...или так:

<blockquote>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</blockquote>

Перейдите <a href=\"http://golubika.local/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!","Пример страницы","","publish","closed","open","","sample-page","","","2018-01-21 19:51:27","2018-01-21 16:51:27","","0","http://golubika.local/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("23","1","2018-02-04 20:14:06","2018-02-04 18:14:06","Привіт! Це я все це створила.

Одного разу, десь на початку грудня, ми сиділи з друзями після роботи в одному з модних закладів цього чарівного північного міста. Я була у новому пальто, яке сама собі нещодавно пошила. Мої друзі здивовано та захоплено нахвалювали моє вміння, і хтось з кучерявим волоссям сказав - тобі треба створити своє, будь-що - одяг, аксесуари… А назва? Ну щось із твоїм прізвищем.

Саме там, у тій чудовій компанії друзів народилось ім’я - GOLUBIKA.","Історія1","","publish","open","open","","story_1","","","2018-02-10 18:30:23","2018-02-10 16:30:23","","0","http://golubika.local/?p=23","0","post","","0");
INSERT INTO `wp_posts` VALUES("24","1","2018-02-04 20:14:06","2018-02-04 18:14:06","Привіт! Це я все це створила.

Одного разу, десь на початку грудня, ми сиділи з друзями після роботи в одному з модних закладів цього чарівного північного міста. Я була у новому пальто, яке сама собі нещодавно пошила. Мої друзі здивовано та захоплено нахвалювали моє вміння, і хтось з кучерявим волоссям сказав - тобі треба створити своє, будь-що - одяг, аксесуари… А назва? Ну щось із твоїм прізвищем.

Саме там, у тій чудовій компанії друзів народилось ім’я - GOLUBIKA.","Історія 1","","inherit","closed","closed","","23-revision-v1","","","2018-02-04 20:14:06","2018-02-04 18:14:06","","23","http://golubika.local/2018/02/04/23-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("27","1","2018-02-04 21:09:08","2018-02-04 19:09:08","","story2","","inherit","open","closed","","story1","","","2018-02-10 18:09:29","2018-02-10 16:09:29","","23","http://golubika.local/wp-content/uploads/2018/02/story1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("29","1","2018-02-04 21:22:53","2018-02-04 19:22:53","","custom_order","","inherit","open","closed","","custom_order","","","2018-02-04 21:23:05","2018-02-04 19:23:05","","0","http://golubika.local/wp-content/uploads/2018/02/custom_order.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("30","1","2018-02-10 14:04:06","2018-02-10 12:04:06","","polylang_mo_5","","private","closed","closed","","polylang_mo_5","","","2018-02-10 14:04:06","2018-02-10 12:04:06","","0","http://golubika.local/?post_type=polylang_mo&p=30","0","polylang_mo","","0");
INSERT INTO `wp_posts` VALUES("31","1","2018-02-10 14:05:27","2018-02-10 12:05:27","","polylang_mo_8","","private","closed","closed","","polylang_mo_8","","","2018-02-10 14:05:27","2018-02-10 12:05:27","","0","http://golubika.local/?post_type=polylang_mo&p=31","0","polylang_mo","","0");
INSERT INTO `wp_posts` VALUES("33","1","2018-02-04 20:14:06","2018-02-04 18:14:06","Hi! It’s me who created all this crafts.

Once upon a time, seems like at early December, we were chilling with friends of mine in a nice place of amazing southern city. I had been dressed up in a new coat that I’ve handmaded by myself. My friends were very surprised and praised my skill, and someone with curly hair told me - you should create your own brand, it doesn’t matter what it would be - clothes, accessories, whatever. And what about the name of this brand? Hmm… It should be something that sounds like your last name probably…

At that single moment a brand name Golubika was born - my friends gave it.","Story1","","publish","open","open","","story_1-2","","","2018-02-24 18:09:35","2018-02-24 16:09:35","","0","http://golubika.local/?p=33","0","post","","0");
INSERT INTO `wp_posts` VALUES("34","1","2018-02-10 16:41:48","2018-02-10 14:41:48","Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
proident, sunt in culpa qui officia deserunt mollit anim id est laborum.","запись на en","","inherit","closed","closed","","33-revision-v1","","","2018-02-10 16:41:48","2018-02-10 14:41:48","","33","http://golubika.local/33-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("35","1","2018-02-10 17:57:45","2018-02-10 15:57:45","Hi! It’s me who created all this crafts.

Once upon a time, seems like at early December, we were chilling with friends of mine in a nice place of amazing southern city. I had been dressed up in a new coat that I’ve handmaded by myself. My friends were very surprised and praised my skill, and someone with curly hair told me - you should create your own brand, it doesn’t matter what it would be - clothes, accessories, whatever. And what about the name of this brand? Hmm… It should be something that sounds like your last name probably…

At that single moment a brand name Golubika was born - my friends gave it.","Story1","","inherit","closed","closed","","33-autosave-v1","","","2018-02-10 17:57:45","2018-02-10 15:57:45","","33","http://golubika.local/33-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("36","1","2018-02-10 17:57:49","2018-02-10 15:57:49","Hi! It’s me who created all this crafts.

Once upon a time, seems like at early December, we were chilling with friends of mine in a nice place of amazing southern city. I had been dressed up in a new coat that I’ve handmaded by myself. My friends were very surprised and praised my skill, and someone with curly hair told me - you should create your own brand, it doesn’t matter what it would be - clothes, accessories, whatever. And what about the name of this brand? Hmm… It should be something that sounds like your last name probably…

At that single moment a brand name Golubika was born - my friends gave it.","Story1","","inherit","closed","closed","","33-revision-v1","","","2018-02-10 17:57:49","2018-02-10 15:57:49","","33","http://golubika.local/33-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("37","1","2018-02-10 18:09:38","2018-02-10 16:09:38","Привіт! Це я все це створила.

Одного разу, десь на початку грудня, ми сиділи з друзями після роботи в одному з модних закладів цього чарівного північного міста. Я була у новому пальто, яке сама собі нещодавно пошила. Мої друзі здивовано та захоплено нахвалювали моє вміння, і хтось з кучерявим волоссям сказав – тобі треба створити своє, будь-що – одяг, аксесуари… А назва? Ну щось із твоїм прізвищем.

Саме там, у тій чудовій компанії друзів народилось ім’я – GOLUBIKA.","Історія2","","publish","open","open","","istoriya2","","","2018-02-10 18:30:07","2018-02-10 16:30:07","","0","http://golubika.local/?p=37","0","post","","0");
INSERT INTO `wp_posts` VALUES("38","1","2018-02-10 18:09:38","2018-02-10 16:09:38","Привіт! Це я все це створила.

Одного разу, десь на початку грудня, ми сиділи з друзями після роботи в одному з модних закладів цього чарівного північного міста. Я була у новому пальто, яке сама собі нещодавно пошила. Мої друзі здивовано та захоплено нахвалювали моє вміння, і хтось з кучерявим волоссям сказав – тобі треба створити своє, будь-що – одяг, аксесуари… А назва? Ну щось із твоїм прізвищем.

Саме там, у тій чудовій компанії друзів народилось ім’я – GOLUBIKA.","История2","","inherit","closed","closed","","37-revision-v1","","","2018-02-10 18:09:38","2018-02-10 16:09:38","","37","http://golubika.local/37-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("39","1","2018-02-10 18:10:56","2018-02-10 16:10:56","Привіт! Це я все це створила.

Одного разу, десь на початку грудня, ми сиділи з друзями після роботи в одному з модних закладів цього чарівного північного міста. Я була у новому пальто, яке сама собі нещодавно пошила. Мої друзі здивовано та захоплено нахвалювали моє вміння, і хтось з кучерявим волоссям сказав – тобі треба створити своє, будь-що – одяг, аксесуари… А назва? Ну щось із твоїм прізвищем.

Саме там, у тій чудовій компанії друзів народилось ім’я – GOLUBIKA.","Історія 2","","inherit","closed","closed","","37-revision-v1","","","2018-02-10 18:10:56","2018-02-10 16:10:56","","37","http://golubika.local/37-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("40","1","2018-02-10 18:09:38","2018-02-10 16:09:38","Hi! It’s me who created all this crafts.

Once upon a time, seems like at early December, we were chilling with friends of mine in a nice place of amazing southern city. I had been dressed up in a new coat that I’ve handmaded by myself. My friends were very surprised and praised my skill, and someone with curly hair told me – you should create your own brand, it doesn’t matter what it would be – clothes, accessories, whatever. And what about the name of this brand? Hmm… It should be something that sounds like your last name probably…

At that single moment a brand name Golubika was born – my friends gave it.","Story2","","publish","open","open","","story2","","","2018-02-24 18:10:08","2018-02-24 16:10:08","","0","http://golubika.local/?p=40","0","post","","0");
INSERT INTO `wp_posts` VALUES("41","1","2018-02-10 18:13:21","2018-02-10 16:13:21","Hi! It’s me who created all this crafts.

Once upon a time, seems like at early December, we were chilling with friends of mine in a nice place of amazing southern city. I had been dressed up in a new coat that I’ve handmaded by myself. My friends were very surprised and praised my skill, and someone with curly hair told me – you should create your own brand, it doesn’t matter what it would be – clothes, accessories, whatever. And what about the name of this brand? Hmm… It should be something that sounds like your last name probably…

At that single moment a brand name Golubika was born – my friends gave it.","Story2","","inherit","closed","closed","","40-revision-v1","","","2018-02-10 18:13:21","2018-02-10 16:13:21","","40","http://golubika.local/40-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("43","1","2018-02-10 18:30:07","2018-02-10 16:30:07","Привіт! Це я все це створила.

Одного разу, десь на початку грудня, ми сиділи з друзями після роботи в одному з модних закладів цього чарівного північного міста. Я була у новому пальто, яке сама собі нещодавно пошила. Мої друзі здивовано та захоплено нахвалювали моє вміння, і хтось з кучерявим волоссям сказав – тобі треба створити своє, будь-що – одяг, аксесуари… А назва? Ну щось із твоїм прізвищем.

Саме там, у тій чудовій компанії друзів народилось ім’я – GOLUBIKA.","Історія2","","inherit","closed","closed","","37-revision-v1","","","2018-02-10 18:30:07","2018-02-10 16:30:07","","37","http://golubika.local/37-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("44","1","2018-02-10 18:30:23","2018-02-10 16:30:23","Привіт! Це я все це створила.

Одного разу, десь на початку грудня, ми сиділи з друзями після роботи в одному з модних закладів цього чарівного північного міста. Я була у новому пальто, яке сама собі нещодавно пошила. Мої друзі здивовано та захоплено нахвалювали моє вміння, і хтось з кучерявим волоссям сказав - тобі треба створити своє, будь-що - одяг, аксесуари… А назва? Ну щось із твоїм прізвищем.

Саме там, у тій чудовій компанії друзів народилось ім’я - GOLUBIKA.","Історія1","","inherit","closed","closed","","23-revision-v1","","","2018-02-10 18:30:23","2018-02-10 16:30:23","","23","http://golubika.local/23-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("46","1","2018-02-19 18:31:50","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2018-02-19 18:31:50","0000-00-00 00:00:00","","0","http://golubika.local/?p=46","0","post","","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_relationships` VALUES("1","6","0");
INSERT INTO `wp_term_relationships` VALUES("1","50","0");
INSERT INTO `wp_term_relationships` VALUES("2","5","0");
INSERT INTO `wp_term_relationships` VALUES("4","6","0");
INSERT INTO `wp_term_relationships` VALUES("4","40","0");
INSERT INTO `wp_term_relationships` VALUES("10","6","0");
INSERT INTO `wp_term_relationships` VALUES("10","51","0");
INSERT INTO `wp_term_relationships` VALUES("23","4","0");
INSERT INTO `wp_term_relationships` VALUES("23","5","0");
INSERT INTO `wp_term_relationships` VALUES("23","24","0");
INSERT INTO `wp_term_relationships` VALUES("27","5","0");
INSERT INTO `wp_term_relationships` VALUES("29","5","0");
INSERT INTO `wp_term_relationships` VALUES("33","8","0");
INSERT INTO `wp_term_relationships` VALUES("33","24","0");
INSERT INTO `wp_term_relationships` VALUES("33","45","0");
INSERT INTO `wp_term_relationships` VALUES("37","4","0");
INSERT INTO `wp_term_relationships` VALUES("37","5","0");
INSERT INTO `wp_term_relationships` VALUES("37","25","0");
INSERT INTO `wp_term_relationships` VALUES("40","8","0");
INSERT INTO `wp_term_relationships` VALUES("40","25","0");
INSERT INTO `wp_term_relationships` VALUES("40","45","0");
INSERT INTO `wp_term_relationships` VALUES("45","9","0");
INSERT INTO `wp_term_relationships` VALUES("45","40","0");
INSERT INTO `wp_term_relationships` VALUES("46","5","0");
INSERT INTO `wp_term_relationships` VALUES("47","6","0");
INSERT INTO `wp_term_relationships` VALUES("47","48","0");
INSERT INTO `wp_term_relationships` VALUES("49","9","0");
INSERT INTO `wp_term_relationships` VALUES("49","48","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("4","4","category","","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("5","5","language","a:3:{s:6:\"locale\";s:2:\"uk\";s:3:\"rtl\";i:0;s:9:\"flag_code\";s:0:\"\";}","0","4");
INSERT INTO `wp_term_taxonomy` VALUES("6","6","term_language","","0","4");
INSERT INTO `wp_term_taxonomy` VALUES("7","7","term_translations","a:2:{s:2:\"uk\";i:1;s:2:\"en\";i:10;}","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("8","8","language","a:3:{s:6:\"locale\";s:5:\"en_GB\";s:3:\"rtl\";i:0;s:9:\"flag_code\";s:0:\"\";}","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("9","9","term_language","","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("10","10","category","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("16","16","term_translations","a:2:{s:2:\"uk\";i:4;s:2:\"en\";i:22;}","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("24","24","post_translations","a:2:{s:2:\"en\";i:33;s:2:\"uk\";i:23;}","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("25","25","post_translations","a:2:{s:2:\"en\";i:40;s:2:\"uk\";i:37;}","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("30","30","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("31","31","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("32","32","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("33","33","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("34","34","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("35","35","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("36","36","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("37","37","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("38","38","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("40","40","term_translations","a:2:{s:2:\"uk\";i:4;s:2:\"en\";i:45;}","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("45","45","category","","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("47","47","category","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("48","48","term_translations","a:2:{s:2:\"uk\";i:47;s:2:\"en\";i:49;}","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("49","49","category","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("50","50","term_translations","a:1:{s:2:\"uk\";i:1;}","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("51","51","term_translations","a:1:{s:2:\"uk\";i:10;}","0","1");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_terms` VALUES("1","Без рубрики","bez-rubriki","0");
INSERT INTO `wp_terms` VALUES("4","Наші історії","stories_ua","0");
INSERT INTO `wp_terms` VALUES("5","Українська","uk","1");
INSERT INTO `wp_terms` VALUES("6","Українська","pll_uk","0");
INSERT INTO `wp_terms` VALUES("7","pll_5a7edfb6083fb","pll_5a7edfb6083fb","0");
INSERT INTO `wp_terms` VALUES("8","English","en","0");
INSERT INTO `wp_terms` VALUES("9","English","pll_en","0");
INSERT INTO `wp_terms` VALUES("10","Без рубрики","bez-rubriki-en","0");
INSERT INTO `wp_terms` VALUES("16","pll_5a7efc3aad5c2","pll_5a7efc3aad5c2","0");
INSERT INTO `wp_terms` VALUES("24","pll_5a7f04ac6e744","pll_5a7f04ac6e744","0");
INSERT INTO `wp_terms` VALUES("25","pll_5a7f1a20db60e","pll_5a7f1a20db60e","0");
INSERT INTO `wp_terms` VALUES("30","exclude-from-search","exclude-from-search","0");
INSERT INTO `wp_terms` VALUES("31","exclude-from-catalog","exclude-from-catalog","0");
INSERT INTO `wp_terms` VALUES("32","featured","featured","0");
INSERT INTO `wp_terms` VALUES("33","outofstock","outofstock","0");
INSERT INTO `wp_terms` VALUES("34","rated-1","rated-1","0");
INSERT INTO `wp_terms` VALUES("35","rated-2","rated-2","0");
INSERT INTO `wp_terms` VALUES("36","rated-3","rated-3","0");
INSERT INTO `wp_terms` VALUES("37","rated-4","rated-4","0");
INSERT INTO `wp_terms` VALUES("38","rated-5","rated-5","0");
INSERT INTO `wp_terms` VALUES("40","pll_5a917a8052009","pll_5a917a8052009","0");
INSERT INTO `wp_terms` VALUES("45","Our stories","stories_en","0");
INSERT INTO `wp_terms` VALUES("47","Нова колекція","new_collection_ua","0");
INSERT INTO `wp_terms` VALUES("48","pll_5a918e9f8d847","pll_5a918e9f8d847","0");
INSERT INTO `wp_terms` VALUES("49","New collection","new_collection_en","0");
INSERT INTO `wp_terms` VALUES("50","pll_5a91bf402f65d","pll_5a91bf402f65d","0");
INSERT INTO `wp_terms` VALUES("51","pll_5a91bf402f721","pll_5a91bf402f721","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","admin");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp_usermeta` VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("14","1","dismissed_wp_pointers","text_widget_paste_html,upcp_admin_pointers_tutorial-one,upcp_admin_pointers_tutorial-two,upcp_admin_pointers_tutorial-three,upcp_admin_pointers_tutorial-four,upcp_admin_pointers_tutorial-five,upcp_admin_pointers_tutorial-six,pll_lgt");
INSERT INTO `wp_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_dashboard_quick_press_last_post_id","46");
INSERT INTO `wp_usermeta` VALUES("18","1","community-events-location","a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}");
INSERT INTO `wp_usermeta` VALUES("19","1","session_tokens","a:3:{s:64:\"5c48862f8eeaf92f04c87bb94fb5b9cd25710e1b186dceb005c7fb3fb1b39ebc\";a:4:{s:10:\"expiration\";i:1519655530;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36\";s:5:\"login\";i:1519482730;}s:64:\"41b789d47e0244ff32f9cc81d2a6fb28369d3076605c2b5d477914190ac641ed\";a:4:{s:10:\"expiration\";i:1519670611;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36\";s:5:\"login\";i:1519497811;}s:64:\"6b86c2b1a46419470d2bf943eabc72b12377e51b3967ea80c0477dacc4785462\";a:4:{s:10:\"expiration\";i:1519670611;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36\";s:5:\"login\";i:1519497811;}}");
INSERT INTO `wp_usermeta` VALUES("20","1","wp_user-settings","editor=html&mfold=o&libraryContent=browse");
INSERT INTO `wp_usermeta` VALUES("21","1","wp_user-settings-time","1518278266");
INSERT INTO `wp_usermeta` VALUES("22","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `wp_usermeta` VALUES("23","1","metaboxhidden_nav-menus","a:1:{i:0;s:12:\"add-post_tag\";}");
INSERT INTO `wp_usermeta` VALUES("24","1","nav_menu_recently_edited","15");
INSERT INTO `wp_usermeta` VALUES("25","1","pll_filter_content","");
INSERT INTO `wp_usermeta` VALUES("26","1","_woocommerce_persistent_cart_1","a:1:{s:4:\"cart\";a:0:{}}");
INSERT INTO `wp_usermeta` VALUES("27","1","last_login_time","2018-02-24 20:43:31");
INSERT INTO `wp_usermeta` VALUES("28","1","dismissed_install_notice","1");
INSERT INTO `wp_usermeta` VALUES("29","1","manageedit-categorycolumnshidden","a:0:{}");
INSERT INTO `wp_usermeta` VALUES("30","1","edit_category_per_page","20");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_users` VALUES("1","admin","$P$BZKdy6mYvrIHRBYyCrPfaksI5zRJBY/","admin","serg.didyk@gmail.com","","2018-01-21 16:51:26","","0","admin");


DROP TABLE IF EXISTS `wp_wc_download_log`;

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_wc_webhooks`;

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_log`;

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



